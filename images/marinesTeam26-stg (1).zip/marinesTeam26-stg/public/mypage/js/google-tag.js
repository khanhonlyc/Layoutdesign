window.dataLayer = window.dataLayer || [];

function gtag() {
	dataLayer.push(arguments);
}
gtag('js', new Date());

gtag('config', 'UA-199559925-1');

(function(w, d, s, l, i) {
	w[l] = w[l] || [];
	w[l].push({
		'gtm.start': new Date().getTime(),
		event: 'gtm.js'
	});
	var f = d.getElementsByTagName(s)[0],
		j = d.createElement(s),
		dl = l != 'dataLayer' ? '&l=' + l : '';
	j.async = true;
	j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
	f.parentNode.insertBefore(j, f);
})(window, document, 'script', 'dataLayer', 'GTM-MQR7HQC');

(function() {
	var didInit = false;

	function initMunchkin() {
		if (didInit === false) {
			didInit = true;
			Munchkin.init(market);
		}
	}
	var s = document.createElement('script');
	s.type = 'text/javascript';
	s.async = true;
	s.src = '//munchkin.marketo.net/munchkin.js';
	s.onreadystatechange = function() {
		if (this.readyState == 'complete' || this.readyState == 'loaded') {
			initMunchkin();
		}
	};
	s.onload = initMunchkin;
	document.getElementsByTagName('head')[0].appendChild(s);
})();