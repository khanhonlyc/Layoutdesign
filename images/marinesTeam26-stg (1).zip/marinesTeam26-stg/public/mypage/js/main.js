$('.slick-notification').not('.slick-initialized').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  fade: false,
  dots:false,
  autoplay: true,
  autoplaySpeed: 3000,
  speed: 2000,
});
$('.slick-banner').not('.slick-initialized').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: true,
  fade: true,
  dots:false,
  autoplay: true,
  autoplaySpeed: 3000,
  speed: 500,
});
$('.slick-album').not('.slick-initialized').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: true,
  fade: false,
  dots:true,
  autoplay: true,
  autoplaySpeed: 3000,
  speed: 500,
  responsive: [
    {
      breakpoint: 480,
      settings: {
        arrows: false,
      }
    }
  ]
});
$('.slick-good-pc').not('.slick-initialized').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: true,
  fade: false,
  dots:true,
  autoplay: true,
  autoplaySpeed: 3000,
  speed: 500,
  responsive: [
    {
      breakpoint: 480,
      settings: {
        arrows: false,
      }
    }
  ]
});
$('.slick-goods').not('.slick-initialized').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: true,
  fade: false,
  dots:true,
  autoplay: true,
  autoplaySpeed: 3000,
  speed: 500,
  responsive: [
    {
      breakpoint: 480,
      settings: {
        arrows: false,
      }
    }
  ]
});
$('.slick-album1').not('.slick-initialized').slick({
  slidesToShow: 2,
  slidesToScroll: 1,
  arrows: true,
  fade: false,
  dots:true,
  autoplay: true,
  autoplaySpeed: 3000,
  speed: 500,
  responsive: [
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 1,
        arrows:false,
      }
    }
  ]
});

$('.slick-tt1').not('.slick-initialized').slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: true,
  fade: false,
  dots:true,
  autoplay: true,
  autoplaySpeed: 3000,
  speed: 500,
  responsive: [
    {
      breakpoint: 480,
      settings: {
        arrows: false,
      }
    }
  ]
});
// $('.slick-tt').slick({
//   slidesToShow: 3,
//   slidesToScroll: 1,
//   arrows: true,
//   fade: false,
//   dots:true,
//   autoplay: true,
//   autoplaySpeed: 3000,
//   speed: 500,
//   responsive: [
//     {
//       breakpoint: 480,
//       settings: {
//         slidesToShow: 1,
//         arrows: false,
//       }
//     }
//   ]
// });
var countSlick = $('.slick-web').not('.slick-initialized').children().length;
var initial1 = countSlick > 5 ? 1 : 0;
var initial2 = countSlick > 4 ? 1 : 0;
var initial3 = countSlick > 3 ? 1 : 0;
$('.slick-web').not('.slick-initialized').slick({
  slidesToShow: 5,
  slidesToScroll: 1,
  initialSlide: initial1,
  infinite: false,
  arrows: true,
  fade: false,
  dots:true,
  autoplay: false,
  autoplaySpeed: 3000,
  speed: 500,
  responsive: [
    {
      breakpoint: 1200,
      settings: {
        slidesToShow: 4,
        initialSlide: initial2,
      }
    },
    {
      breakpoint: 1100,
      settings: {
        slidesToShow: 3,
        initialSlide: initial3,
      }
    },
    {
      breakpoint: 480,
      settings: {
        slidesToShow: 3,
        arrows: false,
        slidesToScroll:3,
        initialSlide: initial3,
      }
    }
  ]
});

$('.slick-video-pc').not('.slick-initialized').slick({
  slidesToShow: 4,
  slidesToScroll: 1,
  arrows: false,
  fade: false,
  dots:true,
  autoplay: true,
  autoplaySpeed: 3000,
  speed: 500,
  responsive: [
    {
      breakpoint: 480,
      settings: {
        arrows: false,
      }
    }
  ]
});

// $(function() {
//   $(".js-name").lettering();
// });

$('.js-menu-mb').click(function(){
  $(this).hide();
  $('.header__menu').fadeIn();
  $('body').css('overflow','hidden');
  $('.js-close').show();
  $("main").css("display", 'none');
});

$('.js-close').click(function(){
  $(this).hide();
  $('.header__menu').fadeOut();
  $('body').css('overflow','auto');
  $('.js-menu-mb').show();
  $("main").css("display", 'block');
});
$('.js-out').click(function(){
  $('.header__menu').fadeOut();
  $('body').css('overflow','auto');
  $('.js-close').hide();
  $('.js-menu-mb').show();
});

$('.login-js').click(function(){
  $('.login-pp').addClass('active-pp');
});
$('.js-bg-login').click(function(){
  $('.login-pp').removeClass('active-pp');
});

$('.js-message').click(function(){
  $('.js-pp-mess1').addClass('active-m');
});
$('.js-message2').click(function(){
  $('.js-pp-mess2').addClass('active-m');
});

$('.js-close-mes').click(function(){
  $('.pp-message').removeClass('active-m');
  $('.pp-message').removeClass('active');
});

$('.js-his').click(function(){
  $('.pp-total-d').addClass('active');
});
$('.js-close1,.js-bg').click(function(){
  $('.pp-total-d').removeClass('active');
});

$('.js-close2,.js-bg2').click(function(){
  $('.pp-ads').removeClass('active-ads');
});


$('.js-qa .form-control').each(function(){
  if ($(this).val() != ''){
    $(this).addClass('active');
  }
});

$('.js-dropdown-menu').click(function(){
  if($(this).hasClass('active')){
    $(this).removeClass('active');
    $(this).parents('ul li').find('.sub-menu-pc').slideUp();
  }else{
    $('.sub-menu-pc').slideUp();
    $(this).parents('ul li').find('.sub-menu-pc').slideDown();
    $('.js-dropdown-menu').removeClass('active');
    $(this).addClass('active');
  } 
});


$('.js-oppen').click(function(){
    $(this).hide();
    $(this).parents('.js-menu-page').find('.js-menu-close').show();
    $('.header_menu_page').fadeIn();
});
$('.js-menu-close').click(function(){
    $(this).hide();
    $(this).parents('.js-menu-page').find('.js-oppen').show();
    $('.header_menu_page').fadeOut();
});
$('.js-out-page-menu').click(function(){
    $('.js-oppen').show();
    $('.js-menu-close').hide();
    $('.header_menu_page').fadeOut();
});
