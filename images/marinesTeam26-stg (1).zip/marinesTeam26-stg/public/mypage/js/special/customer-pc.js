function minTwoDigits(n) {
  return (n < 10 ? '0' : '') + n;
}

function checkTime(i) {
  if (i < 10) {
    i = "0" + i
  }; // add zero in front of numbers < 10
  return i;
}

function isFloat(n) {
    return n === +n && n !== (n|0);
}

function formatIndex(i, k) {
  if (i == null || i == 0) {
  	if(k == 2) return "0.00";
    return ".000";
  }
  i = (i * 100 / 100).toFixed(k);
	if(i < 1 && k != 2) i = i.replace('0.', '.');

  return i.toString();
}

function numberWithCommas(x) {
	x = x ? x : 0;
	return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function setCircleTo(percent, pathLen) {
	var path = $('.circular-chart').find('.circle')[0];
	var adjustedLen = percent * 100 / (parseInt(pathLen) + parseInt(percent));
	if (path) {
		path.setAttribute('stroke-dasharray', adjustedLen.toFixed(3) + ', 100');
	}
}

function toASCII(chars) {
	var ascii = '';
	for (var i = 0, l = chars.length; i < l; i++) {
		var c = chars[i].charCodeAt(0);
		// make sure we only convert half-full width char
		if (c >= 0xFF00 && c <= 0xFFEF) {
			c = 0xFF & (c + 0x20);
		}
		ascii += String.fromCharCode(c);
	}
	return ascii;
}
async function preloadFunc() {
	let dataMember = await fetch('/mix/api/FmaMemberPersonalData', {
			method: 'GET',
			credentials: 'include',
		}).then((response) => response.json())
		.then((data) => {
			//redirect url before login
			var redirectUrl = localStorage.getItem("url");
			if(redirectUrl) {
				localStorage.removeItem("url")
				location.href = redirectUrl;
			}
			let day = new Date();
			let y = day.getFullYear();
			if (data.httpStatus == 'OK') {
				$(".pp-loading").css('display', 'none');
				/*
				$.ajax({
						headers: {
							'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
						},
						method: "POST",
						url: "/mypage/create-log",
						data: {
							amcno: data.amcNo,
							referer: '',
							method: ''
						}
					})
					.done(function(resp) {});
					*/
				return data;
			} else {
				localStorage.setItem("url", location.href);
				if (!document.referrer.includes(location.host + '/mypage/') && !document.referrer.includes(location.host + '/mix/')) {
					location.href = "/mix/FmaMemberLogin";
				}
				if (data.responceMessages[0].code == '0057E') {
					location.href = "/mypage/error-api";
				}
			}
		});

}
addEventListener("DOMContentLoaded", function() {
	preloadFunc();
});

function showMess(id, typeMess, flag = false) {
	if (!flag) {
		$('#js-message-' + id).addClass('active-m');
	}
	$.ajax({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			},
			method: "POST",
			url: "/mypage/message/read",
			data: {
				messageid: id,
				amcno: $('#amcno').val()
			}
		})
		.done(function(resp) {
			if (resp.status == 'OK') {
				let numMess = $('.mess-non-read').text();
				let numMessType = $('.' + typeMess).text();
				$('.mess-non-read').text(numMess - 1);
				$('.' + typeMess).text(numMessType - 1);
				$('.mess-' + id).removeClass("active");
				if (Number(numMessType) - 1 == 0) {
					$('.' + typeMess).css('display', 'none');
				}
				if (Number(numMess) - 1 == 0) {
					$('.mess-non-read').css('display', 'none');
				}
				$(".count-notification").text('未読のメッセージが' + (Number(numMess) - 1 + Number(numMessType) - 1) + '件あります');
				if (Number(numMess) - 1 + Number(numMessType) - 1 == 0) {
					$(".count-notification").text('');
				}
			}
		});
}

function closeMess(id) {
	$('#js-message-' + id).removeClass('active-m');
}

function nl2br(str, is_xhtml) {
	if (typeof str === 'undefined' || str === null) {
		return '';
	}
	var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';
	return (str + '').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1' + breakTag + '$2');
}

function setCookie(key, value, expiry) {
	var expires = new Date();
	expires.setTime(expires.getTime() + (expiry * 24 * 60 * 60 * 1000));
	document.cookie = key + '=' + value + ';expires=' + expires.toUTCString();
}

function getCookie(key) {
	var keyValue = document.cookie.match('(^|;) ?' + key + '=([^;]*)(;|$)');
	return keyValue ? keyValue[2] : null;
}

function eraseCookie(name) {
	document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}

function isHTML(str) {
	var a = document.createElement('div');
	a.innerHTML = str;
	for (var c = a.childNodes, i = c.length; i--;) {
		if (c[i].nodeType == 1) return true;
	}
	return false;
}

function convertMess(title, detail) {
	let titleReturn = {
		isNew: false,
		content: title
	}
	let str = detail ? detail.split('href=')[1] : '';
	if (str) {
		titleReturn.isNew = true;
		let href = str.split('"')[1];
		titleReturn.content = '<a ';
		if (href.includes(window.location.hostname + '/mypage')) {
			href = href.split(window.location.hostname)[1];
		} else {
			titleReturn.content += 'target="_blank" ';
		}
		titleReturn.content += 'href="' + href + '" >' + title + '</a>';
	}
	return titleReturn;
}
//[MIX-次期UI取り込み]20190507 KMS mizukoshi start
function doActionLogout() {
	document.forms[0].action.value = 'logout';
	document.forms[0].action = '/mix/FmaMemberLogin';
	document.forms[0].submit();
}

function getMovies(url) {
    $.ajax({
        url : url  
    }).done(function (data) {
        $('.movies').html(data);  
    }).fail(function () {
        alert('動画一覧がロードできません。ご確認ください。');
    });
}

function checkFavorite() {
	if (!$('.player-list').find(":selected").val()) {
		alert('１人目がまだ選択されません。ご確認ください。')
		return false;
	}
	$('#post-favorite').submit();
}

function getTextOfTag(string, tag) {
	let div = document.createElement('div');
	div.innerHTML = string;

	let elements = div.getElementsByTagName(tag);
	return elements[0] ? elements[0].textContent : '';
}

function getTextNotOfTag(string, tag) {
	let div = document.createElement('div');
	div.innerHTML = string;
	let range = document.createRange();
	range.selectNodeContents(div);
	let textNodes = [];
	for (let node of range.commonAncestorContainer.childNodes) {
	  if (node.nodeType === Node.TEXT_NODE || (node.nodeType === Node.ELEMENT_NODE && node.tagName.toLowerCase() !== tag)) {
	    textNodes.push(node.textContent);
	  }
	}
	let text = textNodes.join('');

	return text;
}

$(document).on('click', '.js-dropdown', function () {
	$(this).find('.t1').toggleClass('d-none');
  $(this).find('.t2').toggleClass('d-block');
	if($(this).parents('.items-contai').hasClass('active')){
		$(this).parents('.items-contai').find('.js-content').slideUp();
		$(this).parents('.items-contai').removeClass('active');
	}
	else{
		$('.js-content').slideUp();
		$(this).parents('.items-contai').find('.js-content').slideDown();
		$('.items-contai').removeClass('active');
		$(this).parents('.items-contai').addClass('active');
	}
	$('.t1').parents('.items-contai').not('.active').find('.t1').removeClass('d-none');
  $('.t2').parents('.items-contai').not('.active').find('.t2').removeClass('d-block');
});
     
// $('.js-dropdown').click(function(){
// 	$(this).find('.t1').toggleClass('d-none');
//   $(this).find('.t2').toggleClass('d-block');
// 	if($(this).hasClass('active')){
// 		$(this).parents('.items-contai').removeClass('active');
// 		$(this).parents('.items-contai').find('.js-content').slideUp();
// 	}
// 	else{
// 		$('.js-content').slideUp();
// 		$(this).parents('.items-contai').find('.js-content').slideDown();
// 		$('.items-contai').removeClass('active');
// 		$(this).parents('.items-contai').addClass('active');
// 	}
// });

$(document).on('click', '.js-pp-mis2', function () {
    $('.pp-miss-pp2').addClass('active-miss');
});
$(document).on('click', '.js-close-mis', function () {
    $('.pp-miss-pp2').removeClass('active-miss');
});
$(document).on('click', '.js-pp-mis', function () {
    $('.pp-miss-pp1').addClass('active-miss');
});
$(document).on('click', '.js-close-mis', function () {
    $('.pp-miss-pp1').removeClass('active-miss');
});
