jQuery(document).ready(function($) {
	window.onload = function() {
		if (document.getElementById('js_Name3') != null) {
			new CircleType(document.getElementById('js_Name3')).radius(160);
		}
	};
});