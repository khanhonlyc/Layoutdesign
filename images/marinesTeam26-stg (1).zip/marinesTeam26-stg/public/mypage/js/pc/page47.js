function renderHtml(data) {
	let dataRecComing = fetch('/mix/api/FmaMemberRecBadge?yearSel=' + $('#year').val(), {
		method: 'GET',
		credentials: 'include',
	}).then((response) => response.json())
	.then((data) => {
		let html = '<span>来場特典配布の実績はありません</span>';
		$('.privilege-list').empty();
		if (data.httpStatus == 'OK') {
			data.badgeList = data.badgeList ? data.badgeList : [];
			let badgeList = data.badgeList.filter(i => {
				let dt = new Date(i.gameDate);
				return dt.getFullYear() == $('#year').val();
			});
			if(badgeList.length > 0) {
				html = '';
				badgeList.forEach(item => {
					html += '<div class="items-house">' +
						'<span class="date">' + item.gameDate + '</span>' +
						'<h3>' +
						'<p>' + item.badgeKind + '</p>' +
						'</h3>' +
						'</div>';
				});
			}
		}
		$('.privilege-list').append(html);
	});
}

$('#year').on('change', function() {
	renderHtml();
});
jQuery(document).ready(function($) {
	window.onload = function() {
		renderHtml();
	};
});