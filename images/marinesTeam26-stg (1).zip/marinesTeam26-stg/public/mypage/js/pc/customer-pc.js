const FAN_COLOR = {
	ゴールド: {
		bg: '#f5d465',
		text: '#000'
	},
	レギュラー: {
		bg: '#000',
		text: '#fbfbfb'
	},
	カジュアルレギュラー: {
		bg: '#7b7b7d',
		text: '#fbfbfb'
	},
	ジュニア: {
		bg: '#B0CFD5',
		text: '#000'
	},
	アカデミー: {
		bg: '#B0CFD5',
		text: '#000'
	},
	無料: {
		bg: '#fff',
		text: '#000'
	},
};
const RANK_COLOR = {
	M1: '#01ACEC',
	M2: '#019D41',
	M3: '#fd9a3c',
	M4: '#E84118',
	M5: '#5E3A92',
	M6: '#333',
};

function minTwoDigits(n) {
  return (n < 10 ? '0' : '') + n;
}

function checkTime(i) {
  if (i < 10) {
    i = "0" + i
  }; // add zero in front of numbers < 10
  return i;
}

function isFloat(n) {
    return n === +n && n !== (n|0);
}

function formatIndex(i, k) {
  if (i == null || i == 0) {
  	if(k == 2) return "0.00";
    return ".000";
  }
  i = (i * 100 / 100).toFixed(k);
	if(i < 1 && k != 2) i = i.replace('0.', '.');

  return i.toString();
}

function numberWithCommas(x) {
	x = x ? x : 0;
	return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
}

function setCircleTo(percent, pathLen) {
	var path = $('.circular-chart').find('.circle')[0];
	var adjustedLen = percent * 100 / (parseInt(pathLen) + parseInt(percent));
	if (path) {
		path.setAttribute('stroke-dasharray', adjustedLen.toFixed(3) + ', 100');
	}
}

function toASCII(chars) {
	var ascii = '';
	for (var i = 0, l = chars.length; i < l; i++) {
		var c = chars[i].charCodeAt(0);
		// make sure we only convert half-full width char
		if (c >= 0xFF00 && c <= 0xFFEF) {
			c = 0xFF & (c + 0x20);
		}
		ascii += String.fromCharCode(c);
	}
	return ascii;
}
async function preloadFunc() {
	let dataMember = await fetch('/mix/api/FmaMemberPersonalData', {
			method: 'GET',
			credentials: 'include',
		}).then((response) => response.json())
		.then((data) => {
			//redirect url before login
			var redirectUrl = localStorage.getItem("url");
			if(redirectUrl) {
				localStorage.removeItem("url")
				location.href = redirectUrl;
			}
			let day = new Date();
			let y = day.getFullYear();
			if (data.httpStatus == 'OK') {
				$(".pp-loading").css('display', 'none');
				if (document.getElementById("qr-code-menu")) {
					var QR_CODE_MENU = new QRCode("qr-code-menu", {
						text: data.amcNo,
						width: '150',
						height: '150',
						colorDark: "#000000",
						colorLight: "#ffffff",
						correctLevel: QRCode.CorrectLevel.M,
					});
				}
				if (document.getElementById("qr-code-menu-1")) {
					var QR_CODE_MENU = new QRCode("qr-code-menu-1", {
						text: data.amcNo,
						width: '150',
						height: '150',
						colorDark: "#000000",
						colorLight: "#ffffff",
						correctLevel: QRCode.CorrectLevel.M,
					});
				}
				if (document.getElementById("qr-code")) {
					var QR_CODE = new QRCode("qr-code", {
						text: data.amcNo,
						width: '170',
						height: '170',
						colorDark: "#000000",
						colorLight: "#ffffff",
						correctLevel: QRCode.CorrectLevel.M,
					});
				}
				let nextFcRankName = Number(toASCII(data.fcRankName).replace('M', '')) + 1;
				nextFcRankName = nextFcRankName > 6 ? 6 : nextFcRankName;
				nextFcRankName = 'M' + nextFcRankName;
				$(".fan-name").text(data.fanName);
				$(".fc-rank-name").text(toASCII(data.fcRankName));
				$(".fc-rank-color").css('background-color', RANK_COLOR[toASCII(data.fcRankName)]);
				$(".circle-rank-color").css('stroke', RANK_COLOR[toASCII(data.fcRankName)]);
				$(".fan-type-name").text(data.fanTypeName + '会員');
				$(".fan-type-name").css('color', FAN_COLOR[data.fanTypeName].bg);
				$(".fan-type-css").css('background-color', FAN_COLOR[data.fanTypeName].bg);
				$(".fan-type-css").css('color', FAN_COLOR[data.fanTypeName].text);
				if (data.fanTypeName == '無料') {
					$(".member").addClass("member-free");
					$(".member-bg").css('background-image', "url('/mypage/images/bg-member-fr.png')");
					$(".member-bg").css('color', "black");
					$(".fan-type-name").css('color', FAN_COLOR[data.fanTypeName].text);
				}
				if (data.fanTypeName == 'レギュラー' || data.fanTypeName == 'カジュアルレギュラー') {
					$(".fan-type-name").css('color', FAN_COLOR[data.fanTypeName].text);
				}
				if (data.fanTypeName == 'ジュニア') {
					$(".junior-v").css('display', 'block');
				}
				if (data.fanTypeName == 'アカデミー') {
					$(".academy-v").css('display', 'block');
				}
				$(".next-fc-rank-name").text(nextFcRankName);
				$(".next-fc-rank-color").css('background-color', RANK_COLOR[nextFcRankName]);
				$(".next-fc-rank-color").css('stroke', RANK_COLOR[nextFcRankName]);
				$(".saving-point").text(numberWithCommas(data.savingPointList.filter(i => i.occurYear == y).map(i => i.point).reduce((a, b) => a + b, 0)));
				$(".amc-no").text(data.amcNo);
				$(".present-comming").text(data.presentComming);
				let imgNum;
				if (data.presentComming >= 10) imgNum = 10;
				if (data.presentComming >= 20) imgNum = 20;
				if (data.presentComming >= 30) imgNum = 30;
				if (data.presentComming >= 40) imgNum = 40;
				if (data.presentComming >= 50) imgNum = 50;
				if (data.presentComming >= 60) imgNum = 60;
				if (data.presentComming >= 70) imgNum = 70;
				if (data.presentComming >= 80) imgNum = 80;
				if (imgNum) {
					$(".present-comming-img").html('<img src="/mypage/images/Icon/icon_' + imgNum + '.png" alt="">');
				}
				$("#amcno").val(data.amcNo);
				$("input[name='amcno']").val(data.amcNo);
				$(".necessary-point").text(numberWithCommas(data.necessaryPoint));
				let findRankEn = arrayRankEn.find(i => i.fantypecode == data.fanTypeCode);
				$(".rank-name-eng").html('<strong>' + data.savingPointList[0].occurYear + ' ' + (findRankEn ? findRankEn.fantypenameen : '') + ' MEMBER</strong>');
				$(".member").addClass(findRankEn ? findRankEn.fantypenameen.toLowerCase() : '');
				let sumPointM = 0,
					sumPointStage = 0;
				data.savingPointList.forEach(item => {
					if (item.pointTypeName == 'ステージポイント') {
						sumPointStage += Number(item.point);
						$('.stage-point-' + item.occurYear).text(numberWithCommas(item.point));
						$('.stage-date-' + item.occurYear).text(item.validDate);
					}
					if (item.pointTypeName == 'Ｍポイント') {
						sumPointM += Number(item.point);
						$('.m-point-' + item.occurYear).text(numberWithCommas(item.point));
						$('.m-date-' + item.occurYear).text(item.validDate);
					}
				});
				$('.sum-point-m').text(numberWithCommas(sumPointM));
				$('.sum-point-stage').text(numberWithCommas(sumPointStage));
				if (toASCII(data.fcRankName) == 'M6') {
					$('.check-rank').css('display', 'none');
					let path1 = $('.circular-chart').find('.circle')[0];
					if (path1) {
						path1.setAttribute('stroke-dasharray', '100, 100');
					}
				} else {
					setCircleTo(sumPointM, data.necessaryPoint);
				}
				setCookie('Mpoint', sumPointM, 5);
				fetch('/mypage/get-uniform?amcNo=' + data.amcNo)
					.then(response => response.json())
					.then(dataResp => {
						let find = dataResp.data;
						if (dataResp.data.length == 0) {
							find = {
								name: 'TEAM',
								uniformnum: '26'
							}
						}
						if (flagRequestUni) {
							$("#number-uni").val(find.uniformnum);
							$("#name-uni").val(find.name);
						}
						$("#js_Name").text(find.name);
						$("#js_Number").text(find.uniformnum);
						setCookie('UniName', find.name, 1);
						setCookie('UniNum', find.uniformnum, 1);
					});

				if (!getCookie('showAds')) {
					if ( $(".banner-modal").length > 0 ) {
						$(".pp-ads").addClass("active-ads");
					}
					setCookie('showAds', 1, 0.04);
				}
				$.ajax({
						headers: {
							'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
						},
						method: "POST",
						url: "/mypage/create-log",
						data: {
							amcno: data.amcNo,
							referer: httpReferer,
							method: httpRequestMethod
						}
					})
					.done(function(resp) {});
				// $('.banner-fantype :not(.fan-type-code-'+data.fanTypeCode+')').remove();
				$('.banner-fantype').each(function() {
					if (!$(this).hasClass('.fan-type-code-' + data.fanTypeCode)) $(this).addClass('not-fan-type');
				});
				$('.items-banner').each(function() {
					if (!$(this).hasClass('fan-type-code-' + data.fanTypeCode)) {
						$(this).remove();
					}
				});
				if($('.top-banner').length == 0) $('.site-banner-pc').addClass('d-none');
				let checkGoods = 0;
				$('.goods-banner').each(function() {
					if ($(this).hasClass('fan-type-code-' + data.fanTypeCode)) {
						checkGoods = 1;
					}
				});
				if (checkGoods == 0) {
					$(".site-good").empty();
				}
				let checkContent = 0;
				$('.content-banner').each(function() {
					if ($(this).hasClass('fan-type-code-' + data.fanTypeCode)) {
						checkContent = 1;
					}
				});
				if (checkContent == 0) {
					$(".site-album2").empty();
          $(".site-album2").css("display","none");
				}
				let checkFooter = 0;
				$('.footer-banner').each(function() {
					if ($(this).hasClass('fan-type-code-' + data.fanTypeCode)) {
						checkFooter = 1;
					}
				});
				if (checkFooter == 0) {
					$(".banner-footer-pc").empty();
				}
				$('.fan-type-code-' + data.fanTypeCode).css('display', 'block');
				if (isGuidebookPage) {
					let rankCode = '01';
					if (data.fanTypeName == '無料') rankCode = '09';
					$.ajax({
							headers: {
								'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
							},
							method: "POST",
							url: "/mypage/get-guidebook",
							data: {
								type_member: rankCode
							}
						})
						.done(function(resp) {
							$('#guidebook-html').html(resp);
						});
				}

		    	if (isMovieListPage) {
				    $('body').on('click', '.pages a', function(e) {
				        e.preventDefault();
				        var url = $(this).attr('href');
				        if(url) getMovies(url);
				        // window.history.pushState("", "", url);
				    });
			    	let queryMv = location.search;
			    	if (!location.search) queryMv = '?';
			    	queryMv += '&ft=' + data.fanTypeCode;
			    	getMovies(location.pathname + queryMv);   		
		    	}

		    	if (isTopPage && $('#live-html').length) {
					$.ajax({
							headers: {
								'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
							},
							method: "GET",
							url: "/mypage/get-html-movie?page=index&type=live&ft=" + data.fanTypeCode,
						})
						.done(function(resp) {
							$('#live-html').html(resp);
						});
            /*
					$.ajax({
							headers: {
								'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
							},
							method: "GET",
							url: "/mypage/get-html-movie?page=index&type=video&ft=" + data.fanTypeCode,
						})
						.done(function(resp) {
							$('#video-html').html(resp);
							$('#video-html').slick({
							  slidesToShow: 3,
							  slidesToScroll: 1,
							  arrows: true,
							  fade: false,
							  dots:true,
							  autoplay: true,
							  autoplaySpeed: 3000,
							  speed: 500,
							  responsive: [
							    {
							      breakpoint: 480,
							      settings: {
							        slidesToShow: 1,
							        arrows: false,
							      }
							    }
							  ]
							});
						});
              */
		    	}
		    	if (isMoviePage) {
					$.ajax({
							headers: {
								'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
							},
							method: "GET",
							url: "/mypage/get-html-movie?page=movie&type=live&ft=" + data.fanTypeCode,
						})
						.done(function(resp) {
							$('#live-html').html(resp);
						});
					$.ajax({
							headers: {
								'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
							},
							method: "GET",
							url: "/mypage/get-html-movie?page=movie&type=video&ft=" + data.fanTypeCode,
						})
						.done(function(resp) {
							$('#video-html').html(resp);
							$('#video-html').slick({
							  slidesToShow: 4,
							  slidesToScroll: 1,
							  arrows: false,
							  fade: false,
							  dots:true,
							  autoplay: true,
							  autoplaySpeed: 3000,
							  speed: 500,
							  responsive: [
							    {
							      breakpoint: 480,
							      settings: {
							        arrows: false,
							      }
							    }
							  ]
							});
						});
		    	}

				return data;
			} else {
      	localStorage.setItem("url", location.href);
        if (!document.referrer.includes(location.host + '/mypage/') && !document.referrer.includes(location.host + '/mix/')) {
          location.href = "/mix/FmaMemberLogin";          
        }
				if (data.responceMessages[0].code == '0057E') {
          location.href = "/mypage/error-api";
				}
			}
		});
	let dataMess = await fetch('/mix/api/FmaMemberMessage', {
			method: 'GET',
			credentials: 'include',
		}).then((response) => response.json())
		.then((data) => {
			let numMess = 0;
			let numMessPersonal = 0;
			$(".line-notification").empty();
			$(".personal-message-list").empty();
			$(".message-list").empty();
			if (data.httpStatus == 'OK') {
				$(".one-time-password-message").css("display", "none");
				if (data.oneTimePasswordMessage) {
					$(".one-time-password-message").css("display", "block");
				}
				$('.mess-number').css('display', 'none');
				$('.personal-mess-number').css('display', 'none');
				$.ajax({
						headers: {
							'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
						},
						method: "GET",
						url: "/mypage/message/list",
						data: {
							amcno: $('#amcno').val()
						}
					})
					.done(function(resp) {
						if (resp.status == "OK") {
							data.messageList.forEach(item => {
								let active = '';
								if (!resp.data.includes(item.messageId)) {
									active = 'active';
									numMess += 1;
								}
								let stTime = item.startTime.split(' ');
								let titleCheck = convertMess(item.title, item.detail);
								let newTitle = titleCheck.isNew ? titleCheck.content : item.title
								let flagHtml = isHTML(newTitle);
								let htmMessItem = `<li class="${active} mess-${item.messageId}" onclick="showMess(${item.messageId},'mess-number',${flagHtml})"><p>${item.title}</p><span>${stTime[0]}</span></li>`;
								if(item.detail != null && item.detail != '' && !isHTML(item.title)) {
									let alertMess = '<section class="pp-message" id="js-message-' + item.messageId + '">' +
										'<div class="js-bg-mes" onclick="closeMess(' + item.messageId + ')"></div>' +
										'<div class="content">' +
										'<div class="title" style="background-color: #EFEFEF; color:#000;">' +
										'<h3>' + item.title + '</h3>' +
										'</div>' +
										'<div class="text">' +
										nl2br(item.detail) +
										'</div>' +
										'<div class="js-close-mes" onclick="closeMess(' + item.messageId + ')">' +
										'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">' +
										'<path d="M175 175C184.4 165.7 199.6 165.7 208.1 175L255.1 222.1L303 175C312.4 165.7 327.6 165.7 336.1 175C346.3 184.4 346.3 199.6 336.1 208.1L289.9 255.1L336.1 303C346.3 312.4 346.3 327.6 336.1 336.1C327.6 346.3 312.4 346.3 303 336.1L255.1 289.9L208.1 336.1C199.6 346.3 184.4 346.3 175 336.1C165.7 327.6 165.7 312.4 175 303L222.1 255.1L175 208.1C165.7 199.6 165.7 184.4 175 175V175zM512 256C512 397.4 397.4 512 256 512C114.6 512 0 397.4 0 256C0 114.6 114.6 0 256 0C397.4 0 512 114.6 512 256zM256 48C141.1 48 48 141.1 48 256C48 370.9 141.1 464 256 464C370.9 464 464 370.9 464 256C464 141.1 370.9 48 256 48z" /></svg>' +
										'<span>閉じる</span>' +
										'</div>' +
										'</div>' +
										'</section>';
									$("main").append(alertMess);
								}
								$(".message-list").append(htmMessItem);
								$(".container-mess").css('display', 'block');
							});
							data.personalMessageList.forEach(item => {
								let active = '';
								if (!resp.data.includes(item.messageId)) {
									active = 'active';
									numMessPersonal += 1;
								}
								let stTime = item.startTime.split(' ');
								let titleCheck = convertMess(item.title, item.detail);
								let newTitle = titleCheck.isNew ? titleCheck.content : item.title
								let flagHtml = isHTML(newTitle);
								let htmMessItem = `<li class="${active} mess-${item.messageId}" onclick="showMess(${item.messageId},'personal-mess-number',${flagHtml})"><p>${item.title}</p><span>${stTime[0]}</span></li>`;
								if(item.detail != null && item.detail != '' && !isHTML(item.title)) {
									let alertMess = '<section class="pp-message" id="js-message-' + item.messageId + '">' +
										'<div class="js-bg-mes" onclick="closeMess(' + item.messageId + ')"></div>' +
										'<div class="content">' +
										'<div class="title" style="background-color: #EFEFEF; color:#000;">' +
										'<h3>' + item.title + '</h3>' +
										'</div>' +
										'<div class="text">' +
										nl2br(item.detail) +
										'</div>' +
										'<div class="js-close-mes" onclick="closeMess(' + item.messageId + ')">' +
										'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">' +
										'<path d="M175 175C184.4 165.7 199.6 165.7 208.1 175L255.1 222.1L303 175C312.4 165.7 327.6 165.7 336.1 175C346.3 184.4 346.3 199.6 336.1 208.1L289.9 255.1L336.1 303C346.3 312.4 346.3 327.6 336.1 336.1C327.6 346.3 312.4 346.3 303 336.1L255.1 289.9L208.1 336.1C199.6 346.3 184.4 346.3 175 336.1C165.7 327.6 165.7 312.4 175 303L222.1 255.1L175 208.1C165.7 199.6 165.7 184.4 175 175V175zM512 256C512 397.4 397.4 512 256 512C114.6 512 0 397.4 0 256C0 114.6 114.6 0 256 0C397.4 0 512 114.6 512 256zM256 48C141.1 48 48 141.1 48 256C48 370.9 141.1 464 256 464C370.9 464 464 370.9 464 256C464 141.1 370.9 48 256 48z" /></svg>' +
										'<span>閉じる</span>' +
										'</div>' +
										'</div>' +
										'</section>';
									$("main").append(alertMess);
								}
								$(".personal-message-list").append(htmMessItem);
								$(".container-personal-mess").css('display', 'block');
							});
							if (numMess > 0) {
								$('.mess-number').css('display', '');
								$('.mess-number').css('display', '');
								$('.box-mess-js').css('display', 'block');
								$('.mess-number').text(numMess);
								$('.loa').css('display', 'block');
							} else {
								if (data.messageList.length == 0) {
									$('.mess-number').css('display', 'none');
								} else {
									$('.box-mess-js').css('display', 'block');
									$('.loa').css('display', 'block');
								}
							}
							if (numMessPersonal > 0) {
								$('.personal-mess-number').css('display', '');
								$('.box-person-mess-js').css('display', 'block');
								$('.personal-mess-number').text(numMessPersonal);
								$('.loa').css('display', 'block');
							} else {
								if (data.personalMessageList.length == 0) {
									$('.personal-mess-number').css('display', 'none');
								} else {
									$('.box-person-mess-js').css('display', 'block');
									$('.loa').css('display', 'block');
								}
							}
							if (numMess + numMessPersonal > 0) {
								$(".count-notification").text('未読のメッセージが' + (numMess + numMessPersonal) + '件あります');
								$(".line-notification").append('<span class="items">' + dataMember.fanName + 'さまへのメッセージ' + (numMess + numMessPersonal) + '件あります。</span>');
								$(".mess-non-read").text(numMess + numMessPersonal);
								$('.mess-non-read').css('display', '');
							}
						}
					});
			}
		});

	if (isTopPage) {
		let dataMission = fetch('/mix/api/FmaMemberMission', {
		  method: 'GET',
		  credentials: 'include',
		}).then((response) => response.json())
		.then((data) => {
			if (data.httpStatus == 'OK') {
				let dateNow = moment().format('YYYYMMDD');
				let html = '';
				let missionMonth = data.missionGroupList.find(i => {
					return i.startDate <= dateNow && dateNow <= i.endDate && i.type == 0; 
				});
				let missionSpecial = data.missionGroupList.filter(i => {
					return i.startDate <= dateNow && dateNow <= i.endDate && i.type == 1; 
				});
				if(missionMonth) {
					let htmlComplete = '<div class="mtp m-0">'+getTextOfTag(missionMonth.detail, 'complete')+'</div>';
					if(missionMonth.isComplete) htmlComplete = '<div class="mtp mission_complete m-0"><p>Mission complete!</p><span><div>全ミッション完了</div><div>Mポイントゲット！</div></div>';
					document.getElementById("detail-miss-month").innerHTML = nl2br(missionMonth.detail);
					let missComplete = missionMonth.missionList.filter(i => i.isComplete);
					let exp = missionMonth.endDate - dateNow;
					let textSpan = `終了まであと${exp}日！`;
					if (exp == 0) textSpan = '本日最終日！'; 
					let htmlMonth = `<div class="mission">
                <div class="container">
                  <div class="row">
                    <div class="col-md-5 pd-right">
                      <div class="mission_content">
                        <h3>月間ミッション ${getTextNotOfTag(missionMonth.detail, 'complete') ? '<span class="js-pp-mis">?</span>' : ''}</h3>
                        ${htmlComplete}
                        <div class="td">
                          <p><span>達成状況${missComplete.length}/${missionMonth.missionList.length}</span><span>　${textSpan}</span></p>
                          <div class="td_nav">
                            <span style="width: ${(missComplete.length * 100) / missionMonth.missionList.length}%;"></span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-md-7 pd-left">`;
          missionMonth.missionList.forEach((item, index) => {
          	let jsDropdown = 'pp-disabled';
          	let cssComp = item.isComplete ? 'css-clear' : '';
          	if(!item.isComplete && item.detail != null) { jsDropdown = 'js-dropdown'; }
          	htmlMonth += `<div class="items-contai ${cssComp}">
                          <div class="items">
                            <div class="d-flex align-items-center">
                              <div class="number">
                                <span class="mi">Mission</span>
                                <span class="so">${minTwoDigits(Number(index) + 1)}</span>
                              </div>
                              <div class="content">
                                <h3>${item.title}</h3>
                              </div>
                            </div>
                            <div class="pp ${jsDropdown}">
                              <span class="t1">${item.isComplete ? 'クリア済み' : 'クリア条件'}</span>
                              <span class="t2">閉じる</span>
                            </div>
                          </div>`;
            if(!item.isComplete) {
            	htmlMonth += `<div class="js-content">
              <p>${nl2br(item.detail)}</p>
              </div>`;
            }
            htmlMonth += `</div>`;
          });
                    
          htmlMonth += `</div></div>
                </div>
              </div>`;
          html += htmlMonth;
				}
				if(missionSpecial.length > 0) {
					// document.getElementById("detail-miss-special").innerHTML = nl2br(missionSpecial.detail);
					let htmlSpecial = `<div class="mission">
                <div class="container">
                  <div class="row">
                    <div class="col-md-5 pd-right">
                      <div class="mission_content h-100">
                        <h3>特別ミッション</h3>
                      </div>
                    </div>
                    <div class="col-md-7 pl-0">`;
          missionSpecial.forEach(item => {
						let jsDropdown = 'pp-disabled';
						let cssComp = item.missionList[0].isComplete ? 'css-clear clear-mission' : '';
						if(!item.missionList[0].isComplete && item.missionList[0].detail != null) { jsDropdown = 'js-dropdown'; }
	          htmlSpecial += `<div class="border-left-custom pd-left mb-3">
	            <div class="text-top">
	              <h4>${item.title} ${getTextNotOfTag(item.detail, 'complete') ? '<span class="js-pp-mis2">?</span>' : ''}</h4>
	              <p>${getTextOfTag(item.detail, 'complete')}</p>
	            </div>
	            <div class="items-contai items-contai-custom ${cssComp}">
	              <div class="items items2 m-0">
	                <div class="d-flex align-items-center">
	                  <div class="number">
	                    <span class="so">SP</span>
	                    <span class="mi">Mission</span>
	                  </div>
	                  <div class="content">
	                    <h3>${item.missionList[0].title}</h3>
	                  </div>
	                </div>
	                <div class="pp ${jsDropdown}">
	                  <span class="t1">${item.missionList[0].isComplete ? 'クリア済み' : 'クリア条件'}</span>
	                  <span class="t2">閉じる</span>
	                </div>
	              </div>`;
	          if(!item.missionList[0].isComplete) {
		          htmlSpecial += `<div class="js-content">
		            <p>${nl2br(item.missionList[0].detail)}</p>
		          </div>`;                       	
	          }
	          htmlSpecial += `<div class="text">
					            開催期間　${moment(item.startDate, 'YYYYMMDD').format('YYYY.MM.DD')}～${moment(item.endDate, 'YYYYMMDD').format('YYYY.MM.DD')}まで
						          </div>
						        </div>
						      </div>`;
          });    
          htmlSpecial += '</div></div></div></div>';      
					html += htmlSpecial;
				}
				if(html) {
					$('#mission-index-html').empty();
					$('#mission-index-html').append(html);
				}
		    return data;
		  }
		});
	}
	var scriptElement = document.createElement('script');
	scriptElement.type = 'text/javascript';
	scriptElement.src = '/mypage/js/main.js';
	document.head.appendChild(scriptElement);

	let dataFavorite = fetch('/mix/api/FmaMemberFavorite', {
			method: 'GET',
			credentials: 'include',
		}).then((response) => response.json())
		.then((data) => {
			if (data.httpStatus == 'OK') {
				if (data.favoriteNow1 || data.favoriteNext1) {
					let favorite1 = data.favoriteNext1 ? data.favoriteNext1 : data.favoriteNow1;
					let f1 = data.playerList.find(i => i.playerCode == favorite1);
					$(".player-uniform-no").text(f1.playerUniformNo);
					$(".player-name").text(f1.playerName);
					$(".player-name-roma").text(f1.playerNameRoma.toUpperCase());
					$(".btn-favorite").text(f1.playerName + '選手のグッズはこちら');
					$(".btn-favorite").removeClass('btn-red');
          $(".btn-favorite").attr("href",'/mix/FmaMemberOutSiteLink?code=14&player='+favorite1);
          $(".btn-favorite").attr({target:"_blank"});
          $(".btn-favorite").addClass('has-favorite');
					$(".no-favorite").css('display', 'none');
					$(".no-favorite").removeClass('d-block');
					$("#bg-favorite").attr("src", "/mypage/images/bg_favorite/"+favorite1+".jpg");
					$(".has-favorite").css('display', '');
					let infoF1 = arrayPit.find(i => i.playerCode == favorite1);
          if(infoF1) {
            let d = new Date(infoF1.updated_at.split('T')[0]);
            let datestring = d.getFullYear() + "/" + minTwoDigits(d.getMonth()+1) + "/" + minTwoDigits(d.getDate());
            $('#index-1').text('防御率　' + formatIndex(infoF1.ERA, 2));
            $('#index-2').text('奪三振　' + (infoF1.SO != null ? infoF1.SO : '0'));
            $('#index-3').text('与四球　' + (infoF1.BB != null ? infoF1.BB : '0'));
            $('#date-update').text( datestring + ' 時点');
          } else {
            infoF1 = arrayBat.find(i => i.playerCode == favorite1);
            if(infoF1) {
	            let d = new Date(infoF1.updated_at.split('T')[0]);
	            let datestring = d.getFullYear() + "/" + minTwoDigits(d.getMonth()+1) + "/" + minTwoDigits(d.getDate());
	            $('#index-1').text('打率　' + formatIndex(infoF1.AVG, 3));
	            $('#index-2').text('出塁率　' + formatIndex(infoF1.OBP, 3));
	            $('#index-3').text('打点　' + (infoF1.RBI != null ? infoF1.RBI : '0'));
	            $('#date-update').text( datestring + ' 時点');
	          }
          } 
				}
			}
		});
}
addEventListener("DOMContentLoaded", function() {
	preloadFunc();
});

function showMess(id, typeMess, flag = false) {
	// if (!flag) {
	$('#js-message-' + id).addClass('active-m');
	// }
	$.ajax({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			},
			method: "POST",
			url: "/mypage/message/read",
			data: {
				messageid: id,
				amcno: $('#amcno').val()
			}
		})
		.done(function(resp) {
			if (resp.status == 'OK') {
				let numMess = $('.mess-non-read').text();
				let numMessType = $('.' + typeMess).text();
				$('.mess-non-read').text(numMess - 1);
				$('.' + typeMess).text(numMessType - 1);
				$('.mess-' + id).removeClass("active");
				if (Number(numMessType) - 1 == 0) {
					$('.' + typeMess).css('display', 'none');
				}
				if (Number(numMess) - 1 == 0) {
					$('.mess-non-read').css('display', 'none');
				}
				$(".count-notification").text('未読のメッセージが' + (Number(numMess) - 1 + Number(numMessType) - 1) + '件あります');
				if (Number(numMess) - 1 + Number(numMessType) - 1 == 0) {
					$(".count-notification").text('');
				}
			}
		});
}

function closeMess(id) {
	$('#js-message-' + id).removeClass('active-m');
}

function nl2br(str, is_xhtml) {
	if (typeof str === 'undefined' || str === null) {
		return '';
	}
	var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';
	return (str + '').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1' + breakTag + '$2');
}

function setCookie(key, value, expiry) {
	var expires = new Date();
	expires.setTime(expires.getTime() + (expiry * 24 * 60 * 60 * 1000));
	document.cookie = key + '=' + value + ';expires=' + expires.toUTCString();
}

function getCookie(key) {
	var keyValue = document.cookie.match('(^|;) ?' + key + '=([^;]*)(;|$)');
	return keyValue ? keyValue[2] : null;
}

function eraseCookie(name) {
	document.cookie = name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}

function isHTML(str) {
	var tagToCheck = 'a';
	var regex = new RegExp('<' + tagToCheck + '[^>]*>[\\s\\S]*?<\\/' + tagToCheck + '>', 'i');
	if (regex.test(str)) {
	  return true;
	} else {
	  return false;
	}
}

function convertMess(title, detail) {
	let titleReturn = {
		isNew: false,
		content: title
	}
	let str = detail ? detail.split('href=')[1] : '';
	if (str) {
		titleReturn.isNew = true;
		let href = str.split('"')[1];
		titleReturn.content = '<a ';
		if (href.includes(window.location.hostname + '/mypage')) {
			href = href.split(window.location.hostname)[1];
		} else {
			titleReturn.content += 'target="_blank" ';
		}
		titleReturn.content += 'href="' + href + '" >' + title + '</a>';
	}
	return titleReturn;
}
//[MIX-次期UI取り込み]20190507 KMS mizukoshi start
function doActionLogout() {
	document.forms[0].action.value = 'logout';
	document.forms[0].action = '/mix/FmaMemberLogin';
	document.forms[0].submit();
}

function getMovies(url) {
    $.ajax({
        url : url  
    }).done(function (data) {
        $('.movies').html(data);  
    }).fail(function () {
        alert('動画一覧がロードできません。ご確認ください。');
    });
}

function checkFavorite() {
	if (!$('.player-list').find(":selected").val()) {
		alert('１人目がまだ選択されません。ご確認ください。')
		return false;
	}
	$('#post-favorite').submit();
}

function getTextOfTag(string, tag) {
	let div = document.createElement('div');
	div.innerHTML = string;

	let elements = div.getElementsByTagName(tag);
	return elements[0] ? elements[0].textContent : '';
}

function getTextNotOfTag(string, tag) {
	let div = document.createElement('div');
	div.innerHTML = string;
	let range = document.createRange();
	range.selectNodeContents(div);
	let textNodes = [];
	for (let node of range.commonAncestorContainer.childNodes) {
	  if (node.nodeType === Node.TEXT_NODE || (node.nodeType === Node.ELEMENT_NODE && node.tagName.toLowerCase() !== tag)) {
	    textNodes.push(node.textContent);
	  }
	}
	let text = textNodes.join('');

	return text;
}

$(document).on('click', '.js-dropdown', function () {
	$(this).find('.t1').toggleClass('d-none');
  $(this).find('.t2').toggleClass('d-block');
	if($(this).parents('.items-contai').hasClass('active')){
		$(this).parents('.items-contai').find('.js-content').slideUp();
		$(this).parents('.items-contai').removeClass('active');
	}
	else{
		$('.js-content').slideUp();
		$(this).parents('.items-contai').find('.js-content').slideDown();
		$('.items-contai').removeClass('active');
		$(this).parents('.items-contai').addClass('active');
	}
	$('.t1').parents('.items-contai').not('.active').find('.t1').removeClass('d-none');
  $('.t2').parents('.items-contai').not('.active').find('.t2').removeClass('d-block');
});
     
// $('.js-dropdown').click(function(){
// 	$(this).find('.t1').toggleClass('d-none');
//   $(this).find('.t2').toggleClass('d-block');
// 	if($(this).hasClass('active')){
// 		$(this).parents('.items-contai').removeClass('active');
// 		$(this).parents('.items-contai').find('.js-content').slideUp();
// 	}
// 	else{
// 		$('.js-content').slideUp();
// 		$(this).parents('.items-contai').find('.js-content').slideDown();
// 		$('.items-contai').removeClass('active');
// 		$(this).parents('.items-contai').addClass('active');
// 	}
// });

$(document).on('click', '.js-pp-mis2', function () {
    $('.pp-miss-pp2').addClass('active-miss');
});
$(document).on('click', '.js-close-mis', function () {
    $('.pp-miss-pp2').removeClass('active-miss');
});
$(document).on('click', '.js-pp-mis', function () {
    $('.pp-miss-pp1').addClass('active-miss');
});
$(document).on('click', '.js-close-mis', function () {
    $('.pp-miss-pp1').removeClass('active-miss');
});