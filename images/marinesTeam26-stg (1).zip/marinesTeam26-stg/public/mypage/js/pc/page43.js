function renderHtml(data) {
	let dataRecComing = fetch('/mix/api/FmaMemberRecComing?yearSel=' + $('#year-rec').val(), {
		method: 'GET',
		credentials: 'include',
	}).then((response) => response.json())
	.then((data) => {
		let html = '<span>来場履歴の実績はありません</span>';
		$('.rec-coming-list').empty();
		if (data.httpStatus == 'OK') {
			data.recComingList = data.recComingList ? data.recComingList : [];
			$('.home-cnt').text(data.homeCnt + '回');
			$('.wonrate').text(data.wonrate);
			$('.year-selected').text($('#year-rec').val());
			let recComingList = data.recComingList.filter(i => {
				let dt = new Date(i.gameDate);
				return dt.getFullYear() == $('#year-rec').val();
			});
			if (recComingList.length > 0) {
				html = '';
				recComingList.forEach(item => {
					html += '<div class="items-house">' +
						'<span class="date">' + item.gameDate + '</span>' +
						'<h3 class="">' +
						'<div>' +
						'<p>' + item.gameName + '</p>' +
						'<span>' + item.stadium + '</span>' +
						'</div>' +
						'</h3>' +
						'<span class="text">' + item.gameResult + '</span>' +
						'<span class="text">' + item.gameScoreNum + '-' + item.gameOScoreNum + '</span>' +
						'</div>';
				});
			}
		}
		$('.rec-coming-list').append(html);
	});

}

$('#year-rec').on('change', function() {
	renderHtml();
});
jQuery(document).ready(function($) {
	window.onload = function() {
		renderHtml();
	};
});