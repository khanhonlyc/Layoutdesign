let dataEvent = fetch('/mix/api/FmaMemberEventList', {
	method: 'GET',
	credentials: 'include',
}).then((response) => response.json())
.then((data) => {
	$('.list-event').empty();
	if (data.httpStatus == 'OK') {
		let html = '';
		data.eventList = data.eventList ? data.eventList.filter(i => i.appKind == '締切り') : [];
		data.eventList.forEach(item => {
			html += `<li>` +
				`<a href="/mypage/event/${item.eventId}"><h3>${item.eventTitle}</h3>` +
				`<p>${item.eventTime}</p>` +
				`</li>`;
		});
		if (html == '') {
			html += `<h3>現在対象イベントはありません。</h3>`;
			$('.infor-event').addClass('none-event');
		}
		$('.list-event').append(html);
		return data;
	}
});