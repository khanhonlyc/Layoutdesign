window.onload = function() {
	if (document.getElementById('js_Name')) {
		new CircleType(document.getElementById('js_Name')).radius(160);
	}
	if (document.getElementById('js_Name1')) {
		new CircleType(document.getElementById('js_Name1')).radius(160);
	}
	if (document.getElementById('js_Name2')) {
		new CircleType(document.getElementById('js_Name2')).radius(160);
	}
	if (document.getElementById('js_Name3')) {
		new CircleType(document.getElementById('js_Name3')).radius(160);
	}
}
