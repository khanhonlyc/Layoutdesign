var m_point = getCookie('Mpoint');
var j_point = getCookie('Jpoint');