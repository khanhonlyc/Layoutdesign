var dataVote;
var csrfToken;
let dataInfoVote = fetch('/mix/api/CrmMemberVoteList', {
		method: 'GET',
		credentials: 'include',
	}).then((response) => response.json())
	.then((data) => {
		if (data.httpStatus == 'OK') {
			csrfToken = data.csrfToken;
			dataVote = data.enqueteList.find(i => i.votePlanId == voteId);
			if (dataVote) {
				$('.vote-plan-title').text(dataVote.votePlanTitle);
				$('.vote-time').text(dataVote.startDate + '～' + dataVote.endDate + 'まで');
				dataVote.questionList.forEach((item, index) => {
					let html = '<div class="form-group"><div class="row">';
					html += '<div class="col-md-2"><div class="label"><div class="label-flex" style=""><label>Q</label> <span class="number">' + (index + 1) + '</span></div>';
					let required = '';
					if (item.requiredFlag == 1) {
						required = 'required';
						html += '<span class="note note-red">必須</span>';
					}
					if (item.voteQuestType == 3) {
						html += ' <span class="note note-gray">複数回答可</span>';
					}
					html += '</div></div>';
					html += '<div class="col-md-10"><p>' + item.webVoteQuestName + '</p>'
					switch (item.voteQuestType) {
						case "1":
							html += '<div class="list-radio">';
							item.optList.forEach(itm => {
								let htmlOption = '<label class="radio"><input type="radio" name="answer_' + item.voteQuestId + '" value="' + itm.value + '" disabled="true" '+ (request["answer_" + item.voteQuestId] == itm.value ? 'checked' : '') +'> <span>' + itm.label + '</span></label>';
								html += htmlOption;
							});
							html += '</div>';
							break;
						case "2":
							html += '<select class="form-control" name="answer_' + item.voteQuestId + '" disabled="true">';
							item.optList.forEach(itm => {
								let htmlOption = '<option value="' + itm.value + '" '+ (request["answer_" + item.voteQuestId] == itm.value ? 'selected' : '') +'>' + itm.label + '</option>';
								html += htmlOption;
							});
							html += '</select>';
							break;
						case "3":
							html += '<div class="list-checkbox" id="checkboxs-'+item.voteQuestId+'">';
							item.optList.forEach(itm => {
								let checked = '';
								if(request["answer_" + item.voteQuestId] != undefined && request["answer_" + item.voteQuestId].includes(itm.value)) {
									checked = ' checked';
								}
								let htmlOption = '<label class="checkbox"><input type="checkbox" name="answer_' + item.voteQuestId + '" value="' + itm.value + '" disabled="true" '+ checked +'><span>' + itm.label + '</span></label>';
								html += htmlOption;
							});
							html += '</div>';
							break;
						case "4":
							html += '<input class="form-control" type="text" value="' + (request["answer_" + item.voteQuestId] ? request["answer_" + item.voteQuestId] : '') + '" name="answer_' + item.voteQuestId + '" maxlength="' + item.limitNum + '" disabled="true">';
							break;
						case "5":
							html += '<textarea class="form-control" name="answer_' + item.voteQuestId + '" maxlength="' + item.limitNum + '" disabled="true">' + (request["answer_" + item.voteQuestId] ? request["answer_" + item.voteQuestId] : '') + '</textarea>';
							break;
						default:
							return;
					}
					html += '</div></div>';
					$('#question-list').append(html);
					$('#question-list').css('color', 'gray');
				});
			}
		}
	});

$('#btn-complete').on('click', function() {
	var formdata = new FormData();
	formdata.append("csrfToken", csrfToken);
	formdata.append("votePlanId", dataVote.votePlanId);
	dataVote.questionList.forEach((item, index) => {
		let answer = '';
		formdata.append('questAnsList['+index+'].voteQuestId', item.voteQuestId);
		switch (item.voteQuestType) {
			case "1":
				answer = $(`input[name=answer_${item.voteQuestId}]:checked`) ? $(`input[name=answer_${item.voteQuestId}]:checked`).val() : "";
				formdata.append('questAnsList['+index+'].answer', answer);
				break;
			case "2":
				answer = $(`select[name=answer_${item.voteQuestId}`) ? $(`select[name=answer_${item.voteQuestId}`).val() : "";
				formdata.append('questAnsList['+index+'].answer', answer);
				break;
			case "3":
				let itemArr = [];
				$(`div#checkboxs-${item.voteQuestId} input[type=checkbox]`).each(function() {
					if ($(this).is(":checked")) {
					   itemArr.push($(this).val());
					}
				});
				answer = itemArr.join();
				formdata.append('questAnsList['+index+'].answers', answer);
				break;
			case "4":
				answer = $(`input[name=answer_${item.voteQuestId}`).val();
				formdata.append('questAnsList['+index+'].answer', answer);
				break;
			case "5":
				answer = $(`textarea[name=answer_${item.voteQuestId}`).val();
				formdata.append('questAnsList['+index+'].answer', answer);
				break;
			default:
				return;
		}
	});
	console.log(formdata);
	fetch('/mix/api/CrmMemberVoteReg', {
		method: 'POST',
		credentials: 'include',
		body: formdata,
	}).then((response) => {
	  if (response.ok) {
	    return response.json();
	  }
	  throw new Error('Something went wrong');
	})
	.then((dataResp) => {
		console.log(dataResp)
		setCookie('VotePlanMsg', dataResp.votePlanMsgEnd, 5);
		location.href = "/mypage/vote/" + voteId + "/complete";
	})
	.catch((error) => {
	  console.log(error)
	});
});