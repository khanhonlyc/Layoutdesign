var field = 'pointTicketCode';
var url = window.location.href;

function doApiPoint(code) {
	let dataInfo = fetch('/mix/api/FmaMemberPointTicketReg', {
		method: 'GET',
		credentials: 'include',
	}).then((response) => response.json())
	.then((data) => {
		if (data.httpStatus == 'OK') {
			let dataPost = {
				csrfToken: data.csrfToken,
				pointTicketCode: code
			}
			let query = new URLSearchParams(dataPost).toString();
			fetch('/mix/api/FmaMemberPointTicketReg?' + query, {
				method: 'POST',
				credentials: 'include',
			}).then((response) => response.json())
			.then((dataResp) => {
				if (dataResp.httpStatus == 'OK') {
					// location.href = urlComplete;
					var url = '/mypage/point/complete';
					var form = $('<form action="' + url + '" method="POST">' +
					  '<input type="text" name="game_date" value="' + dataResp.gameDate + '" />' +
					  '<input type="hidden" name="_token" value="' + $('meta[name="csrf-token"]').attr('content') + '">' +
					  '</form>');
					$('body').append(form);
					form.submit();
				} else {
					let arrMess = dataResp.responceMessages[0].message.split('(e-code=');
					$('.error-message').text(arrMess[0]);
					$('.error-message').css('display', 'block');
				}
			});
		}
	});
}
if(url.indexOf('?' + field + '=') != -1 || url.indexOf('&' + field + '=') != -1) {
	var queryString = window.location.search;
    var urlParams = new URLSearchParams(queryString);
    var paramCode = urlParams.get(field);
    $('#ticket-code').val(paramCode);
    doApiPoint(paramCode);
}

$("#post-ticket-code").click(function() {
	doApiPoint($('#ticket-code').val());
});