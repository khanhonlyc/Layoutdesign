let dataFavorite = fetch('/mix/api/FmaMemberFavorite', {
	method: 'GET',
	credentials: 'include',
}).then((response) => response.json())
.then((data) => {
	if (data.httpStatus == 'OK') {
		let favorite1 = data.favoriteNext1 ? data.favoriteNext1 : data.favoriteNow1;
		let favorite2 = data.favoriteNext2 ? data.favoriteNext2 : data.favoriteNow2;
		let favorite3 = data.favoriteNext3 ? data.favoriteNext3 : data.favoriteNow3;
		if (favorite1) {
			let f1 = data.playerList.find(i => i.playerCode == favorite1);
			$('#favorite-1').empty();
			$('#favorite-1').html('<div class="row m-0 align-items-end">' +
				'<div class="col-md-4 p-0">' +
				'<div class="img">' +
				'<img src="/mypage/images/thumbnail/thumb_'+favorite1+'.jpg" alt="">' +
				'</div>' +
				'</div>' +
				'<div class="col-md-8 p-0">' +
				'<div class="text">' +
				'<span>' + f1.playerUniformNo + '</span>' +
				'<span>' + f1.playerName + '</span>' +
				'</div>' +
				'</div>' +
				'</div>');
		}
		if (favorite2 && favorite2 != '9999998' && favorite2 != '9999999') {
			let f2 = data.playerList.find(i => i.playerCode == favorite2);
			$('#favorite-2').empty();
			$('#favorite-2').html('<div class="row m-0 align-items-end">' +
				'<div class="col-md-4 p-0">' +
				'<div class="img">' +
				'<img src="/mypage/images/thumbnail/thumb_'+favorite2+'.jpg" alt="">' +
				'</div>' +
				'</div>' +
				'<div class="col-md-8 p-0">' +
				'<div class="text">' +
				'<span>' + f2.playerUniformNo + '</span>' +
				'<span>' + f2.playerName + '</span>' +
				'</div>' +
				'</div>' +
				'</div>');
		}
		if (favorite3 && favorite3 != '9999998' && favorite3 != '9999999') {
			let f3 = data.playerList.find(i => i.playerCode == favorite3);
			$('#favorite-3').empty();
			$('#favorite-3').html('<div class="row m-0 align-items-end">' +
				'<div class="col-md-4 p-0">' +
				'<div class="img">' +
				'<img src="/mypage/images/thumbnail/thumb_'+favorite3+'.jpg" alt="">' +
				'</div>' +
				'</div>' +
				'<div class="col-md-8 p-0">' +
				'<div class="text">' +
				'<span>' + f3.playerUniformNo + '</span>' +
				'<span>' + f3.playerName + '</span>' +
				'</div>' +
				'</div>' +
				'</div>');
		}
		let oneTime = [];
		const sorter = (sortBy) => (a, b) => Number(a[sortBy]) > Number(b[sortBy]) ? 1 : -1;
		let newPlayerList = data.playerList.sort(sorter('playerUniformNo'));
		$('.player-list1').append($('<option>', {
			value: 9999998,
			text: '[－－]未選択'
		}));
		$('.player-list2').append($('<option>', {
			value: 9999999,
			text: '[－－]未選択'
		}));		
		newPlayerList.forEach(item => {
			if (item.playerName != "未選択") {
				$('.player-list').append($('<option>', {
					value: item.playerCode,
					text: '['+item.playerUniformNo+']'+item.playerName
				}));
			}
			if (!oneTime.includes(item.playerName) && item.playerName != "未選択") {
				$('.player-list1').append($('<option>', {
					value: item.playerCode,
					text: '['+item.playerUniformNo+']'+item.playerName
				}));
				$('.player-list2').append($('<option>', {
					value: item.playerCode,
					text: '['+item.playerUniformNo+']'+item.playerName
				}));
				oneTime.push(item.playerName);
			}
		});
	}
});

$('.player-list').on('change', function() {
    $('.player-list1 option').css("display", "block");
    $('.player-list2 option').css("display", "block");
    let op1 = $('.player-list1').find(":selected").val();
    let op2 = $('.player-list2').find(":selected").val();
	if($(this).find(":selected").val()){
	    $('.player-list1 option[value="'+$(this).find(":selected").val()+'"]').css("display", "none");
	    $('.player-list2 option[value="'+$(this).find(":selected").val()+'"]').css("display", "none");
	}
	if(op1) $('.player-list2 option[value="'+op1+'"]').css("display", "none");
	if(op2) $('.player-list1 option[value="'+op2+'"]').css("display", "none");
});
$('.player-list1').on('change', function() {
    $('.player-list option').css("display", "block");
    $('.player-list2 option').css("display", "block");
    let op = $('.player-list').find(":selected").val();
    let op2 = $('.player-list2').find(":selected").val();
    if($(this).find(":selected").val()){
	    $('.player-list option[value="'+$(this).find(":selected").val()+'"]').css("display", "none");
	    $('.player-list2 option[value="'+$(this).find(":selected").val()+'"]').css("display", "none");   	
    }
	if(op) $('.player-list2 option[value="'+op+'"]').css("display", "none");
	if(op2) $('.player-list option[value="'+op2+'"]').css("display", "none");
});
$('.player-list2').on('change', function() {
    $('.player-list option').css("display", "block");
    $('.player-list1 option').css("display", "block");
    let op = $('.player-list').find(":selected").val();
    let op1 = $('.player-list1').find(":selected").val();
    if($(this).find(":selected").val()){
	    $('.player-list option[value="'+$(this).find(":selected").val()+'"]').css("display", "none");
	    $('.player-list1 option[value="'+$(this).find(":selected").val()+'"]').css("display", "none");
	}
	if(op) $('.player-list1 option[value="'+op+'"]').css("display", "none");
	if(op1) $('.player-list option[value="'+op1+'"]').css("display", "none");
});
