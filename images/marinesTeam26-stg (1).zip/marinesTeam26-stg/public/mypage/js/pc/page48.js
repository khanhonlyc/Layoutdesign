let dataEvent = fetch('/mix/api/FmaMemberEventList', {
	method: 'GET',
	credentials: 'include',
}).then((response) => response.json())
.then((data) => {
	$('.list-event').empty();
	if (data.httpStatus == 'OK') {
		let html = '';
		let now = new Date();
		data.eventList = data.eventList ? data.eventList.filter(i => {
			let start = new Date(i.startTime);
			let end = new Date(i.endTime);
			return i.appKind == '応募' || i.appKind == '準備中' || (['自由参加', '当日先着順'].includes(i.appKind) && now >= start && now <= end);
		}) : [];
		data.eventList.forEach(item => {
			html += `<li>` +
				`<a href="/mypage/event/${item.eventId}"><h3>${item.eventTitle}</h3>` +
				`<p>${item.eventTime}</p>` +
				`</li>`;
		});
		if (html == '') {
			html += `<h3>現在対象イベントはありません。</h3>`;
			$('.infor-event').addClass('none-event');
		}
		$('.list-event').append(html);
		return data;
	}
});