var dataVote;
var csfrToken;
$('#btn-reset').on('click', function() {
	$('#question-list').trigger("reset");
});
let dataInfoVote = fetch('/mix/api/CrmMemberVoteList', {
		method: 'GET',
		credentials: 'include',
	}).then((response) => response.json())
	.then((data) => {
		if (data.httpStatus == 'OK') {
			csrfToken = data.csrfToken;
			dataVote = data.enqueteList.find(i => i.votePlanId == voteId);
			if (dataVote) {
				$('.vote-plan-title').text(dataVote.votePlanTitle);
				$('.vote-time').text(dataVote.startDate + '～' + dataVote.endDate + 'まで');
				dataVote.questionList.forEach((item, index) => {
					let html = '<div class="form-group"><div class="row">';
					html += '<div class="col-md-2"><div class="label"><div class="label-flex" style=""><label>Q</label> <span class="number">' + (index + 1) + '</span></div>';
					let required = false;
					if (item.requiredFlag == 1) {
						required = true;
						html += '<span class="note note-red">必須</span>';
					}
					if (item.voteQuestType == 3) {
						html += ' <span class="note note-gray">複数回答可</span>';
					}
					html += '</div></div>';
					html += '<div class="col-md-10"><p>' + item.webVoteQuestName + '</p>'
					switch (item.voteQuestType) {
						case "1":
							html += '<div class="list-radio">';
							item.optList.forEach(itm => {
								let htmlOption = '<label class="radio"><input type="radio" name="answer_' + item.voteQuestId + '" value="' + itm.value + '"' + (required ? ' required' : '') + '> <span>' + itm.label + '</span></label>';
								html += htmlOption;
							});
							html += '</div>';
							break;
						case "2":
							html += '<select class="form-control" name="answer_' + item.voteQuestId + '"' + (required ? ' required' : '') + '>';
							item.optList.forEach(itm => {
								let htmlOption = '<option value="' + itm.value + '">' + itm.label + '</option>';
								html += htmlOption;
							});
							html += '</select>';
							break;
						case "3":
							html += '<div class="list-checkbox" id="checkboxs-'+item.voteQuestId+'">';
							item.optList.forEach(itm => {
								let htmlOption = '<label class="checkbox"><input type="checkbox" name="answer_' + item.voteQuestId + '[]" value="' + itm.value + '"' + (required ? ' required' : '') + '><span>' + itm.label + '</span></label>';
								html += htmlOption;
							});
							html += '</div>';
							break;
						case "4":
							html += '<input class="form-control" type="text" value="" name="answer_' + item.voteQuestId + '" maxlength="' + item.limitNum + '"' + (required ? ' required' : '') + '>';
							break;
						case "5":
							html += '<textarea class="form-control" name="answer_' + item.voteQuestId + '" maxlength="' + item.limitNum + '"' + (required ? ' required' : '') + '></textarea>';
							break;
						default:
							return;
					}
					html += '</div></div>';
					$('#question-list').append(html);
				});
			}
		}
	});
$('#btn-confirm').on('click', function() {
	let message = '';
	dataVote.questionList.forEach((item, index) => {
		let itemArr = {};
		switch (item.voteQuestType) {
			case "1":
				itemArr['answer'] = $(`input[name=answer_${item.voteQuestId}]:checked`) ? $(`input[name=answer_${item.voteQuestId}]:checked`).val() : null;
				if (!itemArr['answer'] && item.requiredFlag == 1) {
					message += '問' + (index + 1) + ' は必須です。　ご確認ください。\n';
				}
				break;
			case "2":
				itemArr['answer'] = $(`select[name=answer_${item.voteQuestId}`) ? $(`select[name=answer_${item.voteQuestId}`).val() : null;
				if (!itemArr['answer'] && item.requiredFlag == 1) {
					message += '問' + (index + 1) + ' は必須です。　ご確認ください。\n';
				}
				break;
			case "3":
				itemArr['answers'] = [];
				$(`div#checkboxs-${item.voteQuestId} input[type=checkbox]`).each(function() {
					if ($(this).is(":checked")) {
					   itemArr['answers'].push($(this).val());
					}
				});
				if (!itemArr['answers'].length && item.requiredFlag == 1) {
					message += '問' + (index + 1) + ' は必須です。　ご確認ください。\n';
				}
				if (itemArr['answers'].length > item.limitNum) {
					message += `問${index + 1}は${item.limitNum}個までで選択してください。\n`;
				}
				break;
			case "4":
				itemArr['answer'] = $(`input[name=answer_${item.voteQuestId}`).val();
				if (!itemArr['answer'] && item.requiredFlag == 1) {
					message += '問' + (index + 1) + ' は必須です。　ご確認ください。\n';
				}
				if (itemArr['answer'].length > item.limitNum) {
					message +=`問${index + 1}は${item.limitNum}文字以内で入力してください。\n`;
				}
				break;
			case "5":
				itemArr['answer'] = $(`textarea[name=answer_${item.voteQuestId}`).val();
				if (!itemArr['answer'] && item.requiredFlag == 1) {
					message += '問' + (index + 1) + ' は必須です。　ご確認ください。\n';
				}
				if (itemArr['answer'].length > item.limitNum) {
					message +=`問${index + 1}は${item.limitNum}文字以内で入力してください。\n`;
				}
				break;
			default:
				return;
		}
	});
	if (message != '') {
		alert(message);
		return false;
	}
	$('#question-list').submit();
});
