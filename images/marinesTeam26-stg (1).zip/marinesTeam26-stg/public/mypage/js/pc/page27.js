function toWareki(dateText) {
  if (!dateText) {
    return '';
  }

  if (dateText.indexOf('/') !== -1) {
    dateText = dateText.replace('/', '-');
  }
  if (dateText.indexOf('/') !== -1) {
    dateText = dateText.replace('/', '-');
  }

  var date_split = formatDate(dateText);
  var dates = date_split.split(',');
  var y = parseInt(dates[0]);
  var m = parseInt(dates[1]);
  var d = parseInt(dates[2]);

  //明治５年以降のみ
  if (y < 1873) {
    return false;
  }

  var date = formatDate(dateText, 1);
  var label = '';
  var localYear = '';
  //日付で分割
  // console.log("date", date);
  if (date >= 20190501) {
    label = '令和';
    localYear = y - 2019 + 1; /////
  } else if (date >= 19890108) {
    label = '平成';
    localYear = y - 1988;
  } else if (date >= 19261225) {
    label = '昭和';
    localYear = y - 1925;
  } else if (date >= 19120730) {
    label = '大正';
    localYear = y - 1911;
  } else {
    label = '明治';
    localYear = y - 1868;
  }
  //1年は元年
  if (localYear == 1) {
    wareki = label + '元年';
  } else {
    wareki = label + localYear + '年';
  }

  return wareki + m + '月' + d + '日';
}

function formatDate(date, option, format) {
  // format is '/' or '-'
  var d = new Date(date),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear();

  if (month.length < 2) month = '0' + month;
  if (day.length < 2) day = '0' + day;

  var result;
  if (!option) {
    result = [year, month, day].join(format);
  } else {
    result = [year, month, day].join('');
  }
  return result;
}

let dataInfo = fetch('/mix/api/FmaMemberInfo', {
  method: 'GET',
  credentials: 'include',
}).then((response) => response.json())
.then((data) => {
  if (data.httpStatus == 'OK') {
    $('.amc-no').text(data.amcNo);
    $('.name-kana').text(data.nameKana);
    $('.name').text(data.name);
    $('.sex').text(data.sex == 0 ? '男性' : '女性');
    $('.mailMagazine').text(data.mailMagazine == 1 ? '配信する' : '希望しない');
    $('.birth-day').text(toWareki(data.birthDateYear + '-' + data.birthDateMonth + '-' + data.birthDateDate));
    $('.tel').text(data.telNo1 + '-' + data.telNo2 + '-' + data.telNo3);
    $('.zip-code').text(data.zipCode1 + '-' + data.zipCode2);
    let findAddress1 = data.addressList1.find(i => i.value == data.address1);
    $('.address').text(findAddress1.label + data.address2 + data.address3 + data.address4 + data.address5);
    if (data.amcNo != data.delivFanNo) {
      $('.deliv-fan-no').text(data.delivFanNo);
      $('.deliv-name').text(data.delivLastName + ' ' + data.delivFirstName);
      $('.deliv-tel').text(data.delivTelNo1 + '-' + data.delivTelNo2 + '-' + data.delivTelNo3);
    }
    $('.email-info').text(data.email);
    $('.fan-pass').text(data.fanPassword);

    $('.year1').text(data.year2);
    $('.fan-type1-name').text(data.fanType2Name);
    $('.ship-date-1').text(data.shipDate2);
    $('.goods1-name').html(data.goods2Name);
    $('.deliv-method1-name').text(data.delivMethod2Name);
    $('.deliv-flag1-name').text(data.delivFlag2Name);
    $('.deliv-status1-name').text(data.delivStatus2Name);
    $('.delivCode1').text(data.delivCode2);
    if (data.fanType2 == "09") {
      $(".no-free").empty();
    }
    if (data.fanType2 == "09") {
      $("#group-edit-app").empty();
      $("#group-edit-app").addClass('d-none');
    }
    if (data.yearChk) {
      $('.year2').text(data.year1);
      $('.fan-type-name2').text(data.fanType1Name);
      $('.ship-date2').text(data.shipDate1);
      $('.goods-name2').html(data.goods1Name);
      $('.deliv-method2-name').text(data.delivMethod1Name);
      $('.deliv-flag2-name').text(data.delivFlag1Name);
      $('.deliv-status2-name').text(data.delivStatus1Name);
      $('.delivCode2').text(data.delivCode1);
      if (data.fanType1 == "09") {
        $(".no-free2").empty();
      }
    } else {
      $('.year2-table').css('display', 'none');
    }
    return data;
  }
});
