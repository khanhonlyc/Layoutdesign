function renderHtml(data) {
	let dataRecComing = fetch('/mix/api/FmaMemberRecTicket?yearSel=' + $('#year').val(), {
		method: 'GET',
		credentials: 'include',
	}).then((response) => response.json())
	.then((data) => {
		let html = '<span>チケット購入の実績はありません</span>';
		$('.ticket-list').empty();
		if (data.httpStatus == 'OK') {
			data.recTicketList = data.recTicketList ? data.recTicketList : [];
			let ticketList = data.recTicketList.filter(i => {
				let dt = new Date(i.buyDate);
				if ($('#month').val()) {
					return dt.getFullYear() == $('#year').val() && dt.getMonth() + 1 == $('#month').val();
				}
				return dt.getFullYear() == $('#year').val();
			});
			if (ticketList.length > 0) {
				html = '';
				ticketList.forEach(item => {
					html += '<div class="items-house">' +
						'<span class="date">' + item.buyDate + '</span>' +
						'<h3>' +
						'<p class="date-2">' + item.gameDate + '</p>' +
						'<p>' + item.gameName + '</p>' +
						'<span>' + item.stadium + '</span>' +
						'</h3>' +
						'<p>' + item.seatKind + ' 1枚</p>' +
						'</div>';
				});
			}
		}
		$('.ticket-list').append(html);
	});
}
$('#year').on('change', function() {
	renderHtml();
});
$('#month').on('change', function() {
	renderHtml();
});
jQuery(document).ready(function($) {
	window.onload = function() {
		renderHtml();
	};
});