let dataFavorite = fetch('/mix/api/FmaMemberFavorite', {
	method: 'GET',
	credentials: 'include',
}).then((response) => response.json())
.then((data) => {
	if (data.httpStatus == 'OK') {
		let htmlDefault = '<div class="user"><div class="row m-0 align-items-end"><div class="col-md-4 p-0"><div class="img"><img src="/mypage/images/user-defeaut.png" alt=""></div></div><div class="col-md-8 p-0"><div class="text"><span>未選択</span></div></div></div></div>';
		let favorite1 = data.favoriteNext1 ? data.favoriteNext1 : data.favoriteNow1;
		let favorite2 = data.favoriteNext2 ? data.favoriteNext2 : data.favoriteNow2;
		let favorite3 = data.favoriteNext3 ? data.favoriteNext3 : data.favoriteNow3;
		let f1 = data.playerList.find(i => i.playerCode == favorite1);
		let f1Next = data.playerList.find(i => i.playerCode == rqFavorite1);
		let html1 = '';
		if (f1) {
			html1 += '<div class="user">' +
				'<div class="row m-0 align-items-end">' +
				'<div class="col-md-4 p-0">' +
				'<div class="img">' +
				'<img src="/mypage/images/thumbnail/thumb_'+favorite1+'.jpg" alt="">' +
				'</div>' +
				'</div>' +
				'<div class="col-md-8 p-0">' +
				'<div class="text">' +
				'<span>' + f1.playerUniformNo + '</span>' +
				'<span>' + f1.playerName + '</span>' +
				'</div>' +
				'</div>' +
				'</div>' +
				'</div>';
		} else {
			html1 += htmlDefault;
		}
		if (f1Next) {
			html1 += '<span class="dk-td"><span>登録・変更</span></span>';
			html1 += '<div class="user">' +
				'<div class="row m-0 align-items-end">' +
				'<div class="col-md-4 p-0">' +
				'<div class="img">' +
				'<img src="/mypage/images/thumbnail/thumb_'+rqFavorite1+'.jpg" alt="">' +
				'</div>' +
				'</div>' +
				'<div class="col-md-8 p-0">' +
				'<div class="text">' +
				'<span>' + f1Next.playerUniformNo + '</span>' +
				'<span>' + f1Next.playerName + '</span>' +
				'</div>' +
				'</div>' +
				'</div>' +
				'</div>';
		} else {
			$('input[name=confirm_favorite1]').val(favorite1);
		}
		$('#favorite-1').append(html1);

		let f2 = data.playerList.find(i => i.playerCode == favorite2);
		let f2Next = data.playerList.find(i => i.playerCode == rqFavorite2);
		let html2 = '';
		if (f2 && favorite2 != '9999998' && favorite2 != '9999999') {
			html2 += '<div class="user">' +
				'<div class="row m-0 align-items-end">' +
				'<div class="col-md-4 p-0">' +
				'<div class="img">' +
				'<img src="/mypage/images/thumbnail/thumb_'+favorite2+'.jpg" alt="">' +
				'</div>' +
				'</div>' +
				'<div class="col-md-8 p-0">' +
				'<div class="text">' +
				'<span>' + f2.playerUniformNo + '</span>' +
				'<span>' + f2.playerName + '</span>' +
				'</div>' +
				'</div>' +
				'</div>' +
				'</div>';
		} else {
			html2 += htmlDefault;
		}
		if (f2Next) {
			html2 += '<span class="dk-td"><span>登録・変更</span></span>';
			if (f2Next.playerCode != '9999998' && f2Next.playerCode != '9999999') {
				html2 += '<div class="user">' +
					'<div class="row m-0 align-items-end">' +
					'<div class="col-md-4 p-0">' +
					'<div class="img">' +
					'<img src="/mypage/images/thumbnail/thumb_'+rqFavorite2+'.jpg" alt="">' +
					'</div>' +
					'</div>' +
					'<div class="col-md-8 p-0">' +
					'<div class="text">' +
					'<span>' + f2Next.playerUniformNo + '</span>' +
					'<span>' + f2Next.playerName + '</span>' +
					'</div>' +
					'</div>' +
					'</div>' +
					'</div>';
			} else {
				html2 += htmlDefault;
			}
		} else {
			$('input[name=confirm_favorite2]').val(favorite2);
		}
		$('#favorite-2').append(html2);

		let f3 = data.playerList.find(i => i.playerCode == favorite3);
		let f3Next = data.playerList.find(i => i.playerCode == rqFavorite3);
		let html3 = '';
		if (f3 && favorite3 != '9999998' && favorite3 != '9999999') {
			html3 += '<div class="user">' +
				'<div class="row m-0 align-items-end">' +
				'<div class="col-md-4 p-0">' +
				'<div class="img">' +
				'<img src="/mypage/images/thumbnail/thumb_'+favorite3+'.jpg" alt="">' +
				'</div>' +
				'</div>' +
				'<div class="col-md-8 p-0">' +
				'<div class="text">' +
				'<span>' + f3.playerUniformNo + '</span>' +
				'<span>' + f3.playerName + '</span>' +
				'</div>' +
				'</div>' +
				'</div>' +
				'</div>';
		} else {
			html3 += htmlDefault;
		}
		if (f3Next) {
			html3 += '<span class="dk-td"><span>登録・変更</span></span>';
			if (f3Next.playerCode != '9999998' && f3Next.playerCode != '9999999') {
				html3 += '<div class="user">' +
					'<div class="row m-0 align-items-end">' +
					'<div class="col-md-4 p-0">' +
					'<div class="img">' +
					'<img src="/mypage/images/thumbnail/thumb_'+rqFavorite3+'.jpg" alt="">' +
					'</div>' +
					'</div>' +
					'<div class="col-md-8 p-0">' +
					'<div class="text">' +
					'<span>' + f3Next.playerUniformNo + '</span>' +
					'<span>' + f3Next.playerName + '</span>' +
					'</div>' +
					'</div>' +
					'</div>' +
					'</div>';
			} else {
				html3 += htmlDefault;
			}
		} else {
			$('input[name=confirm_favorite3]').val(favorite3);
		}
		$('#favorite-3').append(html3);

		$("#btn-post-favorite").click(function() {
			let dataFavorite = fetch('/mix/api/FmaMemberFavorite', {
					method: 'GET',
					credentials: 'include',
				}).then((response) => response.json())
				.then((data) => {
					if (data.httpStatus == 'OK') {
						if ($('input[name=confirm_favorite1]').val()) {
							let dataPost = {
								csrfToken: data.csrfToken,
								favorite1: $('input[name=confirm_favorite1]').val(),
								favorite2: $('input[name=confirm_favorite2]').val(),
								favorite3: $('input[name=confirm_favorite3]').val(),
							};
							let query = new URLSearchParams(dataPost).toString();
							fetch('/mix/api/FmaMemberFavorite?' + query, {
									method: 'POST',
									credentials: 'include',
								}).then((response) => response.json())
								.then((dataResp) => {
									location.href = "/mypage/profile/favorite/complete";
								});
						} else {
							alert('１人目がまだ選択されません。ご確認ください。');
						}
					}
				});
		});
	}
});