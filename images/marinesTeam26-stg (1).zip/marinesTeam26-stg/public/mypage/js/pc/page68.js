function renderHtml(data) {
	let html = '<div class="content text-center">'
              +'<p><strong>ミッションはありません。</strong></p>'
          +'</div>';
	$('#mission-month').empty();
	if (data.httpStatus == 'OK') {
		let dateNow = moment().format('YYYYMMDD');
		let dt = moment($('#year').val()+'-'+minTwoDigits($('#month').val())+'-15').format('YYYYMMDD');
		let mission = data.missionGroupList.find(i => {
			return i.startDate <= dt && dt <= i.endDate && i.type == 0;
		});

		if (mission) {
			let missComplete = mission.missionList.filter(i => i.isComplete);
			let exp = mission.endDate - dateNow;
			let textSpan = `終了まであと${exp}日！`;
			if (exp == 0) textSpan = '本日最終日！'; 
			if (exp < 0) textSpan = '開催期間終了'; 
			let htmlComplete = '<div class="mtp m-0">'+getTextOfTag(mission.detail, 'complete')+'</div>';
			if(mission.isComplete) htmlComplete = '<div class="mtp mission_complete m-0"><p>Mission complete!</p>全ミッション完了Mポイントゲット！</div>';
			if(!mission.isComplete && mission.endDate < dateNow) htmlComplete = '<div class="mtp mission_failed m-0"><p>Mission failed!</p>全ミッション完了できませんでした！</div>';
			html = '';
			html += `<div class="mission">
                <div class="row">
                    <div class="col-md-5">
                        <div class="mission_content">
                            ${htmlComplete}
                            <div class="text-mis mt-3">
                                <p>${getTextNotOfTag(mission.detail, 'complete')}</p>
                            </div>
                            <div class="td">
                                <p><span>達成状況 ${missComplete.length}/${mission.missionList.length}</span><span class="${mission.isComplete ? 'text_complete' : ''}">　${textSpan}</span></p>
                                <div class="td_nav">
                                    <span style="width: ${(missComplete.length * 100) / mission.missionList.length}%;"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-7">`;
			mission.missionList.forEach((item, index) => {
				let cssComp = item.isComplete ? 'css-clear' : '';
				let jsDropdown = 'pp-disabled';
				if (mission.endDate < dateNow) { cssComp += ' css-disabled'; }
				if(!item.isComplete && mission.endDate >= dateNow && item.detail != null) { jsDropdown = 'js-dropdown'; }
				html += `<div class="items-contai ${cssComp}">
                                <div class="items">
                                    <div class="d-flex align-items-center">
                                        <div class="number">
                                            <span class="mi">Mission</span>
                                            <span class="so">${minTwoDigits(Number(index) + 1)}</span>
                                        </div>
                                        <div class="content">
                                            <h3>${item.title}</h3>
                                        </div>
                                    </div>
                                    <div class="pp ${jsDropdown}">
                                        <span class="t1">${item.isComplete ? 'クリア済み' : 'クリア条件'}</span>
                                        <span class="t2">閉じる</span>
                                    </div>
                                </div>`;
                if(!item.isComplete && mission.endDate >= dateNow) {
					html += `<div class="js-content">
                        <p>${nl2br(item.detail)}</p>
                    </div>`;
                }
                html += `</div>`;
			});
            html += `</div>
                </div>
            </div>`;
		}
	}

	$('#mission-month').append(html);
}
function renderSelect(data) {
	if (data.httpStatus == 'OK') {
		let arrVal = [];
		let missions = data.missionGroupList.filter(i => {
			return i.type == 0;
		});
		missions.forEach(item => {
			$('#year').empty();
			let year = moment(item.endDate, 'YYYYMMDD').format('YYYY')
			if (!arrVal.includes(year)) {
				arrVal.push(year);
			}
		});
		arrVal.sort(function(a, b){return a-b});
		arrVal.forEach(option => {
			let o = new Option(option + "年", option);
			if (option == moment().format('YYYY')) o.selected=true;
			$("#year").append(o);
		});
	}
}
let dataMission = fetch('/mix/api/FmaMemberMission', {
  method: 'GET',
  credentials: 'include',
}).then((response) => response.json())
.then(async (data) => {
	await renderSelect(data);
	await renderHtml(data);
	$('#year').on('change', function() {
		renderHtml(data);
	});
	$('#month').on('change', function() {
		renderHtml(data);
	});
    return data;
});