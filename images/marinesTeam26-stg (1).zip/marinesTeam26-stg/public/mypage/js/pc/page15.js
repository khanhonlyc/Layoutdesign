function copyToClipboard(element, text) {
	var input = document.createElement('input');
	$('div').removeClass("box-copid");
	input.setAttribute('value', text);
	document.body.appendChild(input);
	input.select();
	var result = document.execCommand('copy');
	document.body.removeChild(input);
	$('.text-code').css('display', 'block');
	$('.text-copied').css('display', 'none');
	$(element).find('.text-code').css('display', 'none');
	$(element).find('.text-copied').css('display', 'block');
	// $(element).removeAttr("onclick");
	$(element).addClass("box-copid");
	return result;
}
let dataExchange = fetch('/mix/api/FmaMemberWebExchange', {
	method: 'GET',
	credentials: 'include',
}).then((response) => response.json())
.then((data) => {
	$(".un-used-exchange-code-list").empty();
	$(".used-exchange-code-list").empty();
	let arrUnUsed = [];
	let arrUsed = [];
	let now = new Date();
	if (data.httpStatus == 'OK') {
		data.unUsedExchangeCodeList.forEach(item => {
			let flag = false;
			let arrBox = item.codeBeanList.map(i => {
				let usedDate = i.usedDate != null ? new Date(i.usedDate) : new Date();
				if(usedDate < now) flag = true;
				let htmlDate = i.boundDate != null ? `<p class="code-date">付与日：${i.boundDate}</p>` : ``;
				let htmlBox = `<div class='box' onclick='copyToClipboard(this, "${i.code}")'>` +
					`<div class='text-code text-center'>` +
					`<p>クーポンコード：<strong>${i.code}</strong></p>` +
					htmlDate +
					`</div>` +
					`<p class="text-copied" style="padding: 8px 0; display: none;">コピーしました</p>` +
					`</div>`;
				return htmlBox;
			});
			if(!flag) {
				let htmlItem = '<div class="row">' +
					'<div class="col-7">' +
					'<div class="text">' +
					'<h3>' + item.name + '</h3>' +
					'</div>' +
					'</div>' +
					'<div class="col-md-5">' +
					'<div class="code">' +
					'<div class="">' +
					arrBox.join('') +
					'</div>' +
					'</div>' +
					'</div>' +
					'</div>';
				arrUnUsed.push(htmlItem);
			}
		});
		if (arrUnUsed.length == 0) {
			$('.un-used-exchange-code-list').css("text-align", "center");
			arrUnUsed.push("<span>使用可能なWEB引換コードはございません。</span>");
		}
		$(".un-used-exchange-code-list").append(arrUnUsed.join('<hr>'));
		data.usedExchangeCodeList.forEach(item => {
			let arrBox = item.codes.map(i => {
				let htmlBox = `<div class='box'>` +
					`<p>クーポンコード <strong>${i}</strong></p>` +
					`</div>`;
				return htmlBox;
			});
			let htmlItem = '<div class="row">' +
				'<div class="col-7">' +
				'<div class="text">' +
				'<h3>' + item.name + '</h3>' +
				'</div>' +
				'</div>' +
				'<div class="col-md-5">' +
				'<div class="code">' +
				arrBox.join('') +
				'</div>' +
				'</div>' +
				'</div>';
			arrUsed.push(htmlItem);
		});
		if (arrUsed.length == 0) {
			$('.used-exchange-code-list').css("text-align", "center");
			arrUsed.push("<span>使用済みWEB引換コードはございません。</span>");
		}
		$(".used-exchange-code-list").append(arrUsed.join('<hr>'));
		if (data.unUsedExchangeCodeList.length + data.usedExchangeCodeList.length == 0) {
			$(".code-container").empty();
			$(".code-use").empty();
			let htmlItem = '<div class="items-code">' +
				'<div class="content un-used-exchange-code-list">' +
				'<div class="row">' +
				'<div class="col-md-12">' +
				'<div class="code" style="text-align:center;margin-bottom:0;">' +
				'<span>チケット引換券コードはございません</span>' +
				'</div>' +
				'</div>' +
				'</div>' +
				'</div>';
			$(".code-container").append(htmlItem);
		}
	}
});