function renderHtml(data) {
  let html = '<div class="content text-center w-100">'
              +'<p><strong>ミッションはありません。</strong></p>'
          +'</div>';
  $('#mission-special').empty();
  if (data.httpStatus == 'OK') {
    let dateNow = moment().format('YYYYMMDD');
    let dt = $('#year').val();
    let missions = data.missionGroupList.filter(i => {
      return i.type == 1 && moment(i.startDate, 'YYYYMMDD').format('YYYY') == dt;
    });
    if(missions.length > 0) {
      html = '';
      let missNow = missions.filter(i => {
        return i.endDate >= dateNow;
      });
      let missBefore = missions.filter(i => {
        return i.endDate < dateNow;
      });
      let htmlNow = `<div class="col-md-6 mission-30">
        <div class="sp-misstion-column">
            <div class="title text-center">開催中ミッション</div>`;
      missNow.forEach(item => {
        let jsDropdown = 'pp-disabled';
        let cssClear = item.isComplete ? 'css-clear clear-mission' : '';
        if(!item.isComplete && item.missionList[0].detail != null) { jsDropdown = 'js-dropdown'; }
        htmlNow += `<div class="items-sp border-left-custom">
            <div class="text-top">
                <h4>${item.title} ${getTextNotOfTag(item.detail, 'complete') ? '<span class="js-pp-mis2">?</span>' : ''}</h4>
                <p>${getTextOfTag(item.detail, 'complete')}</p>
            </div>
            <div class="items-contai items-contai-custom ${cssClear}">
                <div class="items items2 m-0">
                    <div class="d-flex align-items-center">
                        <div class="number">
                            <span class="so">SP</span>
                            <span class="mi">Mission</span>
                        </div>
                        <div class="content">
                            <h3>${item.missionList[0].title}</h3>
                        </div>
                    </div>
                    <div class="pp ${jsDropdown}">
                        <span class="t1">${item.missionList[0].isComplete ? 'クリア済み' : 'クリア条件'}</span>
                        <span class="t2">閉じる</span>
                    </div>
                </div>`;
        if (!item.isComplete) {
          htmlNow += `<div class="js-content">
              <p>${nl2br(item.missionList[0].detail)}</p>
          </div>`;        
        }
        htmlNow += `<div class="text">
            開催期間　${moment(item.startDate, 'YYYYMMDD').format('YYYY.MM.DD')}～${moment(item.endDate, 'YYYYMMDD').format('YYYY.MM.DD')}まで
        </div>`;
        htmlNow += `</div>
        </div>`;
      });
      htmlNow += `</div></div>`;
      html += htmlNow;
      let htmlBefore = `<div class="col-md-6 mission-30">
          <div class="sp-misstion-column sp-misstion-column2 sp-misstion-column2-failed">
          <div class="title">開催終了ミッション</div>`;
      missBefore.forEach(item => {
        let cssClear = item.isComplete ? 'clear-mission' : 'clear-failed';
        htmlBefore +=`<div class="items-sp border-left-custom">
              <div class="text-top">
                  <h4>${item.title}</h4>
                  <p>${getTextOfTag(item.detail, 'complete')}</p>
              </div>
              <div class="items-contai items-contai-custom css-clear ${cssClear}">
                  <div class="items items2 m-0">
                      <div class="d-flex align-items-center">
                          <div class="number">
                              <span class="so">SP</span>
                              <span class="mi">Mission</span>
                          </div>
                          <div class="content">
                              <h3>${item.missionList[0].title}</h3>
                          </div>
                      </div>
                      <div class="pp pp-disabled">
                          <span class="t1">${item.missionList[0].isComplete ? 'クリア済み' : 'クリア条件'}</span>
                      </div>
                  </div>
                  <div class="text">
                      開催期間　${moment(item.startDate, 'YYYYMMDD').format('YYYY.MM.DD')}～${moment(item.endDate, 'YYYYMMDD').format('YYYY.MM.DD')}まで
                  </div>
              </div>
          </div>`;
      });
      htmlBefore += `</div></div>`;
      html += htmlBefore;
    }
  }

  $('#mission-special').append(html);
}
function renderSelect(data) {
  if (data.httpStatus == 'OK') {
    let arrVal = [];
    let missions = data.missionGroupList.filter(i => {
      return i.type == 1;
    });
    missions.forEach(item => {
      $('#year').empty();
      let year = moment(item.endDate, 'YYYYMMDD').format('YYYY')
      if (!arrVal.includes(year)) {
        arrVal.push(year);
      }
    });
    arrVal.sort(function(a, b){return a-b});
    arrVal.forEach(option => {
      let o = new Option(option + "年", option);
      if (option == moment().format('YYYY')) o.selected=true;
      $("#year").append(o);
    });
  }
}
let dataMission = fetch('/mix/api/FmaMemberMission', {
  method: 'GET',
  credentials: 'include',
}).then((response) => response.json())
.then(async (data) => {
  await renderSelect(data);
  await renderHtml(data);
  $('#year').on('change', function() {
    renderHtml(data);
  });
    return data;
});