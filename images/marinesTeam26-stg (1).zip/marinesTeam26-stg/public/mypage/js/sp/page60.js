let dataVote = fetch('/mix/api/CrmMemberVoteList', {
	method: 'GET',
	credentials: 'include',
}).then((response) => response.json())
.then((data) => {
	var d = new Date();
	var datestring = d.getFullYear() + "/" + minTwoDigits(d.getMonth() + 1) + "/" + minTwoDigits(d.getDate());
	if (data.httpStatus == 'OK') {
		let html = '';
		let list = data.enqueteList.filter(i => i.startDate <= datestring && i.endDate >= datestring);
		list.forEach(item => {
			html = `<li>` +
				`<h3><p>${item.votePlanTitle}</p></h3>` +
				`<p>${item.startDate} ～ ${item.endDate}　まで</p>` +
				`<a class="btn-button" href="/mypage/vote/${item.votePlanId}">回答する <i class="fa-solid fa-angle-right"></i></a>` +
				`</li>`;
			$(".list-vote").append(html);
		});
		if (html == '') {
			$('.notifi-data').text('現在受付中のアンケートはありません。');
		}
	}
});