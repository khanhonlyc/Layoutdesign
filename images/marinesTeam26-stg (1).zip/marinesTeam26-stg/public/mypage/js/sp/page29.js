function toWareki(dateText) {
	if (!dateText) {
		return '';
	}

	if (dateText.indexOf('/') !== -1) {
		dateText = dateText.replace('/', '-');
	}
	if (dateText.indexOf('/') !== -1) {
		dateText = dateText.replace('/', '-');
	}

	var date_split = formatDate(dateText);
	var dates = date_split.split(',');
	var y = parseInt(dates[0]);
	var m = parseInt(dates[1]);
	var d = parseInt(dates[2]);

	//明治５年以降のみ
	if (y < 1873) {
		return false;
	}

	var date = formatDate(dateText, 1);
	var label = '';
	var localYear = '';
	//日付で分割
	// console.log("date", date);
	if (date >= 20190501) {
		label = '令和';
		localYear = y - 2019 + 1; /////
	} else if (date >= 19890108) {
		label = '平成';
		localYear = y - 1988;
	} else if (date >= 19261225) {
		label = '昭和';
		localYear = y - 1925;
	} else if (date >= 19120730) {
		label = '大正';
		localYear = y - 1911;
	} else {
		label = '明治';
		localYear = y - 1868;
	}
	//1年は元年
	if (localYear == 1) {
		wareki = label + '元年';
	} else {
		wareki = label + localYear + '年';
	}

	return wareki + m + '月' + d + '日';
}

function formatDate(date, option, format) {
	// format is '/' or '-'
	var d = new Date(date),
		month = '' + (d.getMonth() + 1),
		day = '' + d.getDate(),
		year = d.getFullYear();

	if (month.length < 2) month = '0' + month;
	if (day.length < 2) day = '0' + day;

	var result;
	if (!option) {
		result = [year, month, day].join(format);
	} else {
		result = [year, month, day].join('');
	}
	return result;
}

var flagForced = false;

$("#post-data").click(function() {
	let dataInfo = fetch('/mix/api/FmaMemberInfo', {
			method: 'GET',
			credentials: 'include',
		}).then((response) => response.json())
		.then((data) => {
			if (data.httpStatus == 'OK') {
				let dataPost = {
					csrfToken: data.csrfToken,
					isForcedUpdate: flagForced,
					telNo1: $('input[name=telNo1]').val(),
					telNo2: $('input[name=telNo2]').val(),
					telNo3: $('input[name=telNo3]').val(),
					zipCode1: $('input[name=zipCode1]').val(),
					zipCode2: $('input[name=zipCode2]').val(),
					address1: $('input[name=address1]').val(),
					address2: $('input[name=address2]').val(),
					address3: $('input[name=address3]').val(),
					address4: $('input[name=address4]').val(),
					address5: $('input[name=address5]').val(),
					email: $('input[name=email]').val(),
					emailConf: $('input[name=emailConf]').val(),
					sex: $('input[name=sex]').val(),
					mailMagazinePc: $('input[name=mailMagazine]').val() ? true : false,
					fanPassword: $('input[name=fanPassword]').val(),
					fanPasswordConf: $('input[name=fanPasswordConf]').val(),
					fanPasswordCurrent: $('input[name=fanPasswordCurrent]').val(),
					booksChk: bookChk,
					delivFanNo: $('input[name=delivFanNo]').val(),
					delivLastName: $('input[name=delivLastName]').val(),
					delivFirstName: $('input[name=delivFirstName]').val(),
					delivTelNo1: $('input[name=delivTelNo1]').val(),
					delivTelNo2: $('input[name=delivTelNo2]').val(),
					delivTelNo3: $('input[name=delivTelNo3]').val(),
				};
				console.log(dataPost);
				let query = new URLSearchParams(dataPost).toString();
				fetch('/mix/api/FmaMemberInfo?' + query, {
						method: 'POST',
						credentials: 'include',
					}).then((response) => response.json())
					.then((dataResp) => {
						if (dataResp.httpStatus == 'OK') {
							location.href = "/mypage/profile/customer/complete";
						} else {
							if (dataResp.responceMessages[0].message.includes('e-code=0057E')) {
								fetch('/mypage/error-api')
									.then(response => response.text())
									.then(text => document.documentElement.innerHTML = text);
								return;
							}
							alert(dataResp.responceMessages[0].message);
							if (dataResp.responceMessages[0].message.includes('e-code=W250') || dataResp.responceMessages[0].message.includes('e-code=W249')) {
								flagForced = true;
							} else {
								sessionStorage.setItem('mess_customer', dataResp.responceMessages[0].message);
								sessionStorage.setItem('data_customer', JSON.stringify(requestAll));
								location.href = "/mypage/profile/customer/edit";
							}
						}
					});
			}
		});
});