let dataEvent = fetch('/mix/api/FmaMemberEventList', {
	method: 'GET',
	credentials: 'include',
}).then((response) => response.json())
.then((data) => {
	$('.event-title').text('');
	$('.event-time').text('');
	$('.event-place').text('');
	if (data.httpStatus == 'OK') {
		let html = '';
		data.eventList = data.eventList ? data.eventList : [];
		let eventDetail = data.eventList.find(i => i.eventId == eventId);
		if (eventDetail) {
			$('.event-title').text(eventDetail.eventTitle);
			$('.event-time').text(eventDetail.eventTime);
			$('.event-place').text(eventDetail.place);
			$('.event-point').text(eventDetail.joinPoint + ' Mpt');
			var afterPoint = Number(data.savingPoint) - Number(eventDetail.joinPoint);
			$('#point-calc').html(afterPoint.toString() + '<span> Mpt</span>');
			$('#point-saving').html(data.savingPoint + '<span> Mpt</span>');
			if (Number(eventDetail.joinPoint) == 0) {
				$('.display-point').addClass('d-none');
			}
			if (afterPoint < 0) {
				$("#btn-post-event").addClass("disabled");
				return data;
			}
		}
		$("#btn-post-event").click(function() {
			let dataPost = {
				csrfToken: data.csrfToken,
				eventId: eventId,
			};
			setCookie('Mpoint', afterPoint, 5);
			setCookie('Jpoint', eventDetail.joinPoint, 5);
			let query = new URLSearchParams(dataPost).toString();
			fetch('/mix/api/FmaMemberEventIns?' + query, {
					method: 'POST',
					credentials: 'include',
				}).then((response) => response.json())
				.then((dataResp) => {
					console.log(dataResp)
				});
			location.href = "/mypage/event/" + eventId + "/complete";
		});
		return data;
	}
});