window.addEventListener('load', function() {
	new CircleType(document.getElementById('js_Name1')).radius(160);
});
let dataFavorite = fetch('/mix/api/FmaMemberFavorite', {
	method: 'GET',
	credentials: 'include',
}).then((response) => response.json())
.then((data) => {
	if (data.httpStatus == 'OK') {
		let favorite1 = data.favoriteNext1 ? data.favoriteNext1 : data.favoriteNow1;
		if (favorite1) {
			let f1 = data.playerList.find(i => i.playerCode == favorite1);
			var fDB = listPlayers.find(i => i.playerCode == favorite1);
			$('#favorite').val(f1.playerUniformNo + " " + f1.playerName);
			$('input[name=favorite]').val(f1.playerUniformNo + " " + f1.playerName);
			$('#use-favorite').change(function() {
				if (this.checked && fDB) {
					$('#name-uni').val(fDB.uniformName.toUpperCase());
					$('#number-uni').val(fDB.playerUniformNo);
					$('#js_Number').val(fDB.playerUniformNo);
					$('#js_Name').val(fDB.uniformName.toUpperCase());
				}
			});
		}
	}
});