let dataFavorite = fetch('/mix/api/FmaMemberFavorite', {
	method: 'GET',
	credentials: 'include',
}).then((response) => response.json())
.then((data) => {
	if (data.httpStatus == 'OK') {
		let favorite1 = data.favoriteNext1 ? data.favoriteNext1 : data.favoriteNow1;
		let favorite2 = data.favoriteNext2 ? data.favoriteNext2 : data.favoriteNow2;
		let favorite3 = data.favoriteNext3 ? data.favoriteNext3 : data.favoriteNow3;
		let htmlDefault = '<div class="items-img"><img src="/mypage/images/user-defeaut.png" alt=""><div class="text"><h3 class="">未選択</h3></div></div>';
		if (favorite1) {
			let f1 = data.playerList.find(i => i.playerCode == favorite1);
			$(".player-uniform-no").text(f1.playerUniformNo);
			$(".player-name").text(f1.playerName);
			$(".player-name-roma").text(f1.playerNameRoma);
			$('#favorite-1').append('<div class="items-img">' +
				'<img src="/mypage/images/thumbnail/thumb_'+favorite1+'.jpg" alt="">' +
				'<div class="text">' +
				'<span>' + f1.playerUniformNo + '</span>' +
				'<h3>' + f1.playerName + '</h3>' +
				'</div>' +
				'</div>');
		}
		if (favorite2 && favorite2 != '9999998' && favorite2 != '9999999') {
			let f2 = data.playerList.find(i => i.playerCode == favorite2);
			$('#favorite-2').append('<div class="items-img">' +
				'<img src="/mypage/images/thumbnail/thumb_'+favorite2+'.jpg" alt="">' +
				'<div class="text">' +
				'<span>' + f2.playerUniformNo + '</span>' +
				'<h3>' + f2.playerName + '</h3>' +
				'</div>' +
				'</div>');
		} else {
			$('#favorite-2').append(htmlDefault);
		}
		if (favorite3 && favorite3 != '9999998' && favorite3 != '9999999') {
			let f3 = data.playerList.find(i => i.playerCode == favorite3);
			$('#favorite-3').append('<div class="items-img">' +
				'<img src="/mypage/images/thumbnail/thumb_'+favorite3+'.jpg" alt="">' +
				'<div class="text">' +
				'<span>' + f3.playerUniformNo + '</span>' +
				'<h3>' + f3.playerName + '</h3>' +
				'</div>' +
				'</div>');
		} else {
			$('#favorite-3').append(htmlDefault);
		}
	}
});