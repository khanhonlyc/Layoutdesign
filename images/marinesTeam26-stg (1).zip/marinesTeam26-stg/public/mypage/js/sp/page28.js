if (sessionStorage.getItem('mess_customer')) {
	$('#mess-error').html(sessionStorage.getItem('mess_customer'));
}
function searchZipCode() {
	$('select[name=address1]').val('').change();
	$('input[name=address2]').val('');
	$('input[name=address3]').val('');
	let dataSearch = fetch('/mix/api/FmaMemberInfoAddressSearch?zipCode1=' + $('input[name=zipCode1]').val() + '&zipCode2=' + $('input[name=zipCode2]').val(), {
			method: 'GET',
			credentials: 'include',
		}).then((response) => response.json())
		.then((data) => {
			if (data.httpStatus == 'OK') {
				$('select[name=address1]').val(data.address1).change();
				$('input[name=address2]').val(data.address2);
				$('input[name=address3]').val(data.address3);
			}
		});
}

function toWareki(dateText) {
	if (!dateText) {
		return '';
	}

	if (dateText.indexOf('/') !== -1) {
		dateText = dateText.replace('/', '-');
	}
	if (dateText.indexOf('/') !== -1) {
		dateText = dateText.replace('/', '-');
	}

	var date_split = formatDate(dateText);
	var dates = date_split.split(',');
	var y = parseInt(dates[0]);
	var m = parseInt(dates[1]);
	var d = parseInt(dates[2]);

	//明治５年以降のみ
	if (y < 1873) {
		return false;
	}

	var date = formatDate(dateText, 1);
	var label = '';
	var localYear = '';
	//日付で分割
	// console.log("date", date);
	if (date >= 20190501) {
		label = '令和';
		localYear = y - 2019 + 1; /////
	} else if (date >= 19890108) {
		label = '平成';
		localYear = y - 1988;
	} else if (date >= 19261225) {
		label = '昭和';
		localYear = y - 1925;
	} else if (date >= 19120730) {
		label = '大正';
		localYear = y - 1911;
	} else {
		label = '明治';
		localYear = y - 1868;
	}
	//1年は元年
	if (localYear == 1) {
		wareki = label + '元年';
	} else {
		wareki = label + localYear + '年';
	}

	return wareki + m + '月' + d + '日';
}

function formatDate(date, option, format) {
	// format is '/' or '-'
	var d = new Date(date),
		month = '' + (d.getMonth() + 1),
		day = '' + d.getDate(),
		year = d.getFullYear();

	if (month.length < 2) month = '0' + month;
	if (day.length < 2) day = '0' + day;

	var result;
	if (!option) {
		result = [year, month, day].join(format);
	} else {
		result = [year, month, day].join('');
	}
	return result;
}
if ($("#changeEmail").checked) {
	$("input[name=email]").prop("readonly", false);
	$("input[name=emailConf]").prop("readonly", false);
}
if (this.checked) {
	$("input[name=fanPassword]").prop("readonly", false);
	$("input[name=fanPasswordConf]").prop("readonly", false);
}
$("#changeEmail").change(function() {
	$("input[name=email]").prop("readonly", true);
	$("input[name=emailConf]").prop("readonly", true);
	if (this.checked) {
		$("input[name=email]").prop("readonly", false);
		$("input[name=emailConf]").prop("readonly", false);
	}
});
$("#changePass").change(function() {
	$("input[name=fanPassword]").prop("readonly", true);
	$("input[name=fanPasswordConf]").prop("readonly", true);
	if (this.checked) {
		$("input[name=fanPassword]").prop("readonly", false);
		$("input[name=fanPasswordConf]").prop("readonly", false);
		$("input[name=fanPasswordCurrent]").val('');
	}
});
$("#select-address").change(function() {
	$("#select-address option:selected").each(function() {
		$('input[name=address1_text]').val($(this).text());
	});
});

let dataInfo = fetch('/mix/api/FmaMemberInfo', {
	method: 'GET',
	credentials: 'include',
}).then((response) => response.json())
.then((data) => {
	if (data.httpStatus == 'OK') {
		$('.amc-no').text(data.amcNo);
		$('input[name=amcNo]').val(data.amcNo);
		$('.name-kana').text(data.nameKana);
		$('.name').text(data.name);
		$('.birth-day').text(toWareki(data.birthDateYear + '-' + data.birthDateMonth + '-' + data.birthDateDate));
		$('input[name=birthDay]').val(toWareki(data.birthDateYear + '-' + data.birthDateMonth + '-' + data.birthDateDate));
		$('input[name=name_kana]').val(data.nameKana);
		$('input[name=name]').val(data.name);
		$('input[name=token_api]').val(data.csrfToken);
		$('input[name=book_chk]').val(data.books);
		$('input[name=email_old]').val(data.email);
        if (data.delivFanNo != "" && Number(data.delivFanNo) !== Number(data.amcNo)) {
			data.address1 = "";
		}
		$.each(data.addressList1, function(i, item) {
			if (oldAdress == 0) {
				$('select[name=address1]').append($('<option>', {
					value: item.value,
					text: item.label,
					selected: item.value == data.address1 ? true : false,
				}));
				if (item.value == data.address1) {
					$('input[name=address1_text]').val(item.label);
				}
			} else {
				$('select[name=address1]').append($('<option>', {
					value: item.value,
					text: item.label,
					selected: item.value == oldAdress ? true : false,
				}));
				if (item.value == oldAdress) {
					$('input[name=address1_text]').val(item.label);
				}
			}
		});
		if (oldAmcno == 0) {
			$('.sex').val(data.sex).change();
			if (data.mailMagazine == 1) {
				$('.mailMagazine').prop('checked', true);
			}
			$('input[name=telNo1]').val(data.telNo1);
			$('input[name=telNo2]').val(data.telNo2);
			$('input[name=telNo3]').val(data.telNo3);
			$('input[name=zipCode1]').val(data.zipCode1);
			$('input[name=zipCode2]').val(data.zipCode2);
			$('input[name=address2]').val(data.address2);
			$('input[name=address3]').val(data.address3);
			$('input[name=address4]').val(data.address4);
			$('input[name=address5]').val(data.address5);
			$('input[name=fanPasswordCurrent]').val(data.fanPassword);
			$('input[name=email]').val(data.email);
			if (data.amcNo != data.delivFanNo) {
				$('.deliv-last-name').val(data.delivLastName);
				$('.deliv-first-name').val(data.delivFirstName);
				$('.deliv-tel-no-1').val(data.delivTelNo1);
				$('.deliv-tel-no-2').val(data.delivTelNo2);
				$('.deliv-tel-no-3').val(data.delivTelNo3);
				$('.deliv-fan-no').val(data.delivFanNo);
			}
		}
		if (sessionStorage.getItem('data_customer') != null) {
			let obj = JSON.parse(sessionStorage.data_customer);
			$('input[name=telNo1]').val(obj.telNo1);
			$('input[name=telNo2]').val(obj.telNo2);
			$('input[name=telNo3]').val(obj.telNo3);
			$('input[name=zipCode1]').val(obj.zipCode1);
			$('input[name=zipCode2]').val(obj.zipCode2);
			$('input[name=address2]').val(obj.address2);
			$('input[name=address3]').val(obj.address3);
			$('input[name=address4]').val(obj.address4);
			$('input[name=address5]').val(obj.address5);
			$('.deliv-last-name').val(obj.delivLastName ? obj.delivLastName : '');
			$('.deliv-first-name').val(obj.delivFirstName ? obj.delivFirstName : '');
			$('.deliv-tel-no-1').val(obj.delivTelNo1 ? obj.delivTelNo1 : '');
			$('.deliv-tel-no-2').val(obj.delivTelNo2 ? obj.delivTelNo2 : '');
			$('.deliv-tel-no-3').val(obj.delivTelNo3 ? obj.delivTelNo3 : '');
			$('.deliv-fan-no').val(obj.delivFanNo);
			$('input[name=email]').val(obj.email);
			$('input[name=emailConf]').val(obj.emailConf);
			if (obj.emailChange == 1) {
                $('input[name=emailChange]').prop('checked', true);
                $("input[name=email]").prop("readonly", false);
                $("input[name=emailConf]").prop("readonly", false);
            }
            if (obj.passChange == 1) {
                $('input[name=passChange]').prop('checked', true);
                $("input[name=fanPassword]").prop("readonly", false);
                $("input[name=fanPasswordConf]").prop("readonly", false);
            }
			if (obj.mailMagazine == 1) {
				$('.mailMagazine').prop('checked', true);
			}
			$('#select-address').val(obj.address1).change();
			$('.sex').val(obj.sex).change();
			sessionStorage.clear();
		}
		return data;
	}
});

$(function() {
	// 変数に要素を入れる
	var open = $('.modal-open'),
		close = $('.modal-close'),
		container = $('.modal-container');

	//開くボタンをクリックしたらモーダルを表示する
	open.on('click', function() {
		container.addClass('active');
		return false;
	});

	//閉じるボタンをクリックしたらモーダルを閉じる
	close.on('click', function() {
		container.removeClass('active');
	});

	//モーダルの外側をクリックしたらモーダルを閉じる
	$(document).on('click', function(e) {
		if (!$(e.target).closest('.modal-body').length) {
			container.removeClass('active');
		}
	});
});
