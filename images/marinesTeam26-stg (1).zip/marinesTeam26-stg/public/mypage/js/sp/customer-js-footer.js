const today = new Date();
let h = today.getHours();
let mi = today.getMinutes();
let y = today.getFullYear();
let mo = today.getMonth() + 1;
let d = today.getDate();
h = checkTime(h);
mi = checkTime(mi);
mo = checkTime(mo);
d = checkTime(d);
$('#time-now-js').text(y + "." + mo + "." + d + " " + h + ":" + mi);
window.onload = function() {
	if (document.getElementById('js_Name')) {
		new CircleType(document.getElementById('js_Name')).radius(110);
	}
	if (document.getElementById('js_Name1')) {
		new CircleType(document.getElementById('js_Name1')).radius(160);
	}
	if (document.getElementById('js_Name2')) {
		new CircleType(document.getElementById('js_Name2')).radius(160);
	}
	if (document.getElementById('js_Name3')) {
		new CircleType(document.getElementById('js_Name3')).radius(110);
	}
}