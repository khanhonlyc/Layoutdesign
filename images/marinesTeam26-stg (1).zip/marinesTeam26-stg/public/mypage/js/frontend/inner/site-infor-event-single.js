let dataEvent = fetch('/mix/api/FmaMemberEventList', {
		method: 'GET',
		credentials: 'include',
	}).then((response) => response.json())
	.then((data) => {
		$('.event-title').text('');
		$('.event-time').text('');
		$('.start-time').text('');
		$('.end-time').text('');
		$('.event-place').text('');
		$('.event-detail').empty();
		if (data.httpStatus == 'OK') {
			let html = '';
			data.eventList = data.eventList ? data.eventList : [];
			let eventDetail = data.eventList.find(i => i.eventId == eventId);
			if (eventDetail) {
				if (eventDetail.appKind != '応募') {
					$('.btn-confirm').remove();
				}
				if (eventDetail.appKind == '締切り') {
					$('.note').text('こちらのイベントの申込受付は終了しています');
					$('.note').css('display', 'block');
				}
				if (eventDetail.appKind == '終了') {
					$('.note').text('こちらのイベントはすでに終了しています');
					$('.note').css('display', 'block');
				}
				$('.event-title').text(eventDetail.eventTitle);
				$('.event-time').text(eventDetail.eventTime);
				$('.start-time').text(moment(eventDetail.startTime).format('YYYY/MM/DD HH:mm'));
				$('.end-time').text(moment(eventDetail.endTime).format('YYYY/MM/DD HH:mm'));
				$('.event-place').text(eventDetail.place);
				$('.event-detail').html(nl2br(eventDetail.detail));
				$('.event-point').text(eventDetail.joinPoint + ' Mpt');
				if (eventDetail.joinPoint > 0) {
					$('.display-point').removeClass('d-none');
				}
			}

			return data;
		}
	});