let dataEvent = fetch('/mix/api/FmaMemberEventList', {
		method: 'GET',
		credentials: 'include',
	}).then((response) => response.json())
	.then((data) => {
		$('.list-event').empty();
		if (data.httpStatus == 'OK') {
			let html = '';
			let now = new Date();
			let pages = '受付中';
			let dataList = data.eventList ? data.eventList.filter(i => {
				let start = new Date(i.startTime);
				let end = new Date(i.endTime);
				return i.appKind == '応募' || i.appKind == '準備中' || (['自由参加', '当日先着順'].includes(i.appKind) && now >= start && now <= end);
			}) : [];
			if (isApplied == "1") {
				dataList = data.eventList ? data.eventList.filter(i => i.appKind == '申込済') : [];
				pages = '申込済み';
			}
			if (isClose == "1") {
				dataList = data.eventList ? data.eventList.filter(i => i.appKind == '締切り') : [];
				pages = '申込締切';
			}
			if (isPerformed == "1") {
				dataList = data.eventList ? data.eventList.filter(i => i.appKind == '終了') : [];
				pages = '申込終了';
			}
			dataList.forEach(item => {
				html += `<li>` +
					`<h3><a href="/mypage/event/${item.eventId}">${item.eventTitle}</a></h3>` +
					`<p>${item.eventTime}</p>` +
					`</li>`;
			});
			if (html == '') {
				html += `<h3>現在対象イベントはありません。</h3>`;
				$('.infor-event').addClass('none-event');
			}
			$('.list-event').append(html);
			return data;
		}
	});