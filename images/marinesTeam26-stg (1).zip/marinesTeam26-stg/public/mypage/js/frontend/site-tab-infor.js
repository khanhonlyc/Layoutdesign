jQuery.fn.scrollCenter = function(elem, speed) {
  var active = jQuery(this).find(elem);
  var activeWidth = active.width() / 2;
  var pos = active.position().left + activeWidth;
  var currentscroll = jQuery(this).scrollLeft();
  var divwidth = jQuery(this).width();
  pos = pos + currentscroll - divwidth / 2;
  jQuery(this).animate({
    scrollLeft: pos
  }, speed == undefined ? 1000 : speed);
  return this;
};
$("#scrollcenter li").on("click", function() {
  $("#scrollcenter li").removeClass("active");
  $(this).addClass("active");
  $("#scrollcenter").scrollCenter(".active", 300);
});