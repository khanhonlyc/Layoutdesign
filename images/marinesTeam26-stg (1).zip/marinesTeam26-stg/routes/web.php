<?php
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\File;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\HistoryController;
use App\Http\Controllers\MovieController;
use App\Http\Controllers\MissionController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\VoteController;
use App\Http\Controllers\PointController;
use Jenssegers\Agent\Agent;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', [HomeController::class, 'index'])->name('index');
Route::group(['prefix'=>'mypage', 'as' => 'mypage.'], function () {
  //Render html in public folder
  Route::get('/special/2023/konami', function() {
    return File::get(public_path() . '/mypage/special/2023/konami/index.html');
  });
  //
  Route::get('/error-api', function() {
    return File::get(public_path() . '/error.html');
  });
  Route::group(['prefix'=>'profile/customer', 'as' => 'profile.customer.'],function () {
    Route::get('/', [ProfileController::class, 'customer'])->name('index');
    Route::get('edit', [ProfileController::class, 'customerEdit'])->name('edit');
    Route::post('confirm', [ProfileController::class, 'customerConfirm'])->name('confirm');
    Route::get('confirm', [ProfileController::class, 'customerConfirm'])->name('getConfirm');
    Route::get('complete', [ProfileController::class, 'customerComplete'])->name('complete');
  });
  Route::group(['prefix'=>'profile/favorite', 'as' => 'profile.favorite.'],function () {
    Route::get('/', [ProfileController::class, 'favorite'])->name('index');
    Route::post('confirm', [ProfileController::class, 'favoriteConfirm'])->name('confirm');
    Route::get('confirm', [ProfileController::class, 'favoriteConfirm'])->name('getConfirm');
    Route::get('complete', [ProfileController::class, 'favoriteComplete'])->name('complete');
  });
  Route::group(['prefix'=>'profile/uniform', 'as' => 'profile.uniform.'],function () {
    Route::get('/', [ProfileController::class, 'uniform'])->name('index');
    Route::post('confirm', [ProfileController::class, 'uniformConfirm'])->name('confirm');
    Route::get('confirm', [ProfileController::class, 'uniformConfirm'])->name('getConfirm');
    Route::post('complete', [ProfileController::class, 'uniformComplete'])->name('complete');
    Route::get('complete', [ProfileController::class, 'uniformComplete'])->name('getComplete');
  });
  Route::group(['prefix'=>'history', 'as' => 'history.'],function () {
    Route::get('/visit', [HistoryController::class, 'visit'])->name('visit');
    Route::get('ticket', [HistoryController::class, 'ticket'])->name('ticket');
    Route::get('privilege', [HistoryController::class, 'privilege'])->name('privilege');
    Route::get('point', [HistoryController::class, 'point'])->name('point');
  });
  Route::group(['prefix'=>'event', 'as' => 'event.'],function () {
    Route::get('/', [EventController::class, 'index'])->name('index');
    Route::get("/applied", [EventController::class, 'applied'])->name('applied');
    Route::get("/close", [EventController::class, 'close'])->name('close');
    Route::get("/performed", [EventController::class, 'performed'])->name('performed');
    Route::get("/{eventId}", [EventController::class, 'show'])->name('show');
    Route::get("/{eventId}/confirm", [EventController::class, 'confirm'])->name('confirm');
    Route::get("/{eventId}/complete", [EventController::class, 'complete'])->name('complete');
  });
  Route::group(['prefix'=>'vote', 'as' => 'vote.'],function () {
    Route::get('/', [VoteController::class, 'index'])->name('index');
    Route::get("/{votePlanId}", [VoteController::class, 'show'])->name('show');
    Route::get("/{votePlanId}/confirm", [VoteController::class, 'confirm']);
    Route::post("/{votePlanId}/confirm", [VoteController::class, 'confirm'])->name('confirm');
    Route::get("/{votePlanId}/complete", [VoteController::class, 'complete'])->name('complete');
  });
  Route::group(['prefix'=>'movie', 'as' => 'movie.'],function () {
    Route::get('/', [MovieController::class, 'index'])->name('index');
    Route::get('/list', [MovieController::class, 'list'])->name('list');
    Route::get('/{movieID}', [MovieController::class, 'show'])->name('show');
  });
  Route::group(['prefix'=>'point', 'as' => 'point.'],function () {
    Route::get('/grant', [PointController::class, 'grant'])->name('grant');
    Route::get('/complete', [PointController::class, 'complete'])->name('complete-get');
    Route::post('/complete', [PointController::class, 'complete'])->name('complete-post');
  });
  Route::group(['prefix'=>'mission', 'as' => 'mission.'],function () {
    Route::get('/monthly', [MissionController::class, 'monthly'])->name('monthly');
    Route::get('/special', [MissionController::class, 'special'])->name('special');
  });
  Route::get('/', [HomeController::class, 'index'])->name('index');
  Route::get('/guidebook', [HomeController::class, 'guidebook'])->name('guidebook');
  Route::get('/coupon', [HomeController::class, 'coupon'])->name('coupon');
  Route::get('/marines', [HomeController::class, 'marines'])->name('marines');
  Route::get('/message', [HomeController::class, 'message'])->name('message');
  //
  Route::post('/message/read', [HomeController::class, 'readMessage'])->name('message.read');
  Route::get('/message/list', [HomeController::class, 'getMessage'])->name('message.get');
  Route::post('/create-log', [HomeController::class, 'createLog'])->name('log.create');
  Route::get('/test-api-tickets', [HomeController::class, 'apiTickets'])->name('ticketapi');
  Route::get('/test-api-news', [HomeController::class, 'apiNews'])->name('newapi');
  Route::post('/get-guidebook', [HomeController::class, 'getGuidebook'])->name('get-guidebook');
  Route::get('/get-uniform', [ProfileController::class, 'getUniform']);
  Route::get('/get-html-movie', [MovieController::class, 'getMovieHtml']);
  Route::get('/test-api-pits/{year}', [HomeController::class, 'apiPits'])->name('pitapi');
  Route::get('/test-api-bats/{year}', [HomeController::class, 'apiBats'])->name('batapi');
});
\URL::forceScheme('https');
