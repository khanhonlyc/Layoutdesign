<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Jenssegers\Agent\Agent;
use App\Models\Banner;
use Carbon\Carbon;

class VoteController extends Controller
{
  public function index(Request $request)
  {
    $title = "アンケート一覧";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page60-sp';
    if($agent->isDesktop()) {
      $slug = 'page60-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  }

  public function show($id)
  {
    $title = "アンケート回答";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page62-sp';
    if($agent->isDesktop()) {
      $slug = 'page62-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'id', 'listBanner', 'title'));
  }

  public function confirm(Request $request, $id)
  {
    $title = "アンケート回答確認";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page61-sp';
    if($agent->isDesktop()) {
      $slug = 'page61-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'id', 'listBanner', 'title', 'request'));
  }

  public function complete($id)
  {
    $title = "アンケート回答完了";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page63-sp';
    if($agent->isDesktop()) {
      $slug = 'page63-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'id', 'listBanner', 'title'));
  }
}
