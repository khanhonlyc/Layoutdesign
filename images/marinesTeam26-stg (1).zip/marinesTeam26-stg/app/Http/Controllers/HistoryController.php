<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Jenssegers\Agent\Agent;
use App\Models\Banner;
use Carbon\Carbon;

class HistoryController extends Controller
{
  public function visit(Request $request)
  {
    $title = "会員履歴 | 来場履歴";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page43-sp';
    if($agent->isDesktop()) {
      $slug = 'page43-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  }

  public function ticket(Request $request)
  {
    $title = "会員履歴 | チケット購入履歴";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page45-sp';
    if($agent->isDesktop()) {
      $slug = 'page45-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  }

  public function privilege(Request $request)
  {
    $title = "会員履歴 | 来場特典配布";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page47-sp';
    if($agent->isDesktop()) {
      $slug = 'page47-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  }

  public function point(Request $request)
  {
    $title = "会員履歴 | Ｍポイント実績";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page37-sp';
    if($agent->isDesktop()) {
      $slug = 'page37-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  }
}
