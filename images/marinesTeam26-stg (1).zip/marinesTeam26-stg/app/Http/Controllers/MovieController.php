<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Jenssegers\Agent\Agent;
use App\Models\Movie;
use App\Models\Tag;
use App\Models\Banner;
use App\Models\FanRankName;
use Carbon\Carbon;
use View;

class MovieController extends Controller
{
  public function index(Request $request)
  {
    $title = "動画コンテンツ";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $topicTags = Tag::withCount('tag_movies')->orderByDesc('tag_movies_count')->limit(6)->get();
    $list = Movie::where('status', 1)
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->with(["tag_movies.tag"])
    ->orderBy('publish_start', 'DESC')->get();
    $agent = new Agent();
    $slug = 'page11-sp';
    if($agent->isDesktop()) {
      $slug = 'page11-pc';
    }
    $listLive = $list->filter(function ($item) {
      return $item->movie_type_code == 2;
    });
    $listVideo = $list->filter(function ($item) {
      return $item->movie_type_code == 1;
    });
    return view('pages.home.' . $slug, compact('slug', 'listVideo', 'topicTags', 'listBanner', 'listLive', 'title'));
  }

  public function list(Request $request)
  {
    $title = "動画コンテンツ一覧";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $topicTags = Tag::withCount('tag_movies')->orderByDesc('tag_movies_count')->limit(5)->get();
    $search = $request->input('search');
    $tag = $request->input('tag');
    $tagSearch = null;
    if($tag != '' && $tag != null) {
      $tagSearch = Tag::where('tag_id', $tag)->first();
    }

    $list = [];
    $agent = new Agent();
    $slug = 'page12-sp';
    $limit = 6;
    if($agent->isDesktop()) {
      $slug = 'page12-pc';
      $limit = 6;
    }
    if ($request->ajax() && isset($request->ft)) {
      $findFanType = FanRankName::where('fantypecode', $request->ft)->first();
      if ($findFanType) {
        $list = Movie::where([
          ['status', 1],
          ['movie_type_code', 1],
          ['fan_type_code', 'LIKE', "%".$findFanType->id."%"],
        ])
        ->where(
         function($query) use ($search) {
            if($search) {
             return $query->whereHas('tag_movies.tag', function ($q) use ($search) {
               $q->where('tag_name', 'LIKE', "%".$search."%");
             })->orWhere('title', 'LIKE', "%".$search."%");
            }
          })
        ->where('publish_start', '<=', $date)
        ->where('publish_end', '>=', $date)
        ->where(
         function($query) use ($tag) {
            if($tag) {
             return $query->whereHas('tag_movies.tag', function ($q) use ($tag) {
               $q->where('tag_id', '=', $tag);
             });
            }
          })
        ->with(["tag_movies.tag"])
        ->orderBy('publish_start', 'DESC')
        ->paginate(6);
      }
      if($agent->isDesktop()) {
        return view('parts.movie.list', ['list' => $list])->render(); 
      } 
      return view('parts.movie.list-sp', ['list' => $list])->render(); 
    }
    return view('pages.home.' . $slug, compact('slug', 'list', 'topicTags', 'tagSearch', 'listBanner', 'title'));
  } 

  public function show($id)
  {
    $title = "動画コンテンツ詳細";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $topicTags = Tag::withCount('tag_movies')->orderByDesc('tag_movies_count')->limit(5)->get();
    $info = Movie::where([
      ['id', $id],
    ])
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->with(["tag_movies.tag"])
    ->firstOrFail();
    $agent = new Agent();
    $slug = 'page14-sp';
    if($agent->isDesktop()) {
      $slug = 'page14-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'id', 'info', 'topicTags', 'listBanner', 'title'));
  }  


  public function getMovieHtml(Request $request)
  {
    $list = [];
    $agent = new Agent();
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $findFanType = FanRankName::where('fantypecode', $request->ft)->first();
    if ($findFanType) {
      $list = Movie::where('status', 1)
      ->where('fan_type_code', 'LIKE', "%".$findFanType->id."%")
      ->where('publish_start', '<=', $date)
      ->where('publish_end', '>=', $date)
      ->with(["tag_movies.tag"])->orderBy('publish_start', 'DESC')->get();
    }
    $listLive = $list->filter(function ($item) {
      return $item->movie_type_code == 2;
    });
    $listVideo = $list->filter(function ($item) {
      return $item->movie_type_code == 1;
    });
    $parameters = [
      'listVideo' => $listVideo,
      'listLive' => $listLive,
    ];
    if ($request->type == 'live') {
      $contents = View::make('parts.movie.live-sp')->with($parameters);
    }
    if ($request->type == 'video') {
      $contents = View::make('parts.movie.movie-sp')->with($parameters);
    }
    if($agent->isDesktop()) {
      if ($request->type == 'live' && $request->page == 'index') {
        $contents = View::make('parts.movie.live-index')->with($parameters);
      }
      if ($request->type == 'live' && $request->page == 'movie') {
        $contents = View::make('parts.movie.live')->with($parameters);
      }
      if ($request->type == 'video' && $request->page == 'index') {
        $contents = View::make('parts.movie.movie-index')->with($parameters);
      }
      if ($request->type == 'video' && $request->page == 'movie') {
        $contents = View::make('parts.movie.movie')->with($parameters);
      }
    }
    $response = Response::make($contents, 200);
    $response->header('Content-Type', 'text/plain');
    return $response;
  }  
}
