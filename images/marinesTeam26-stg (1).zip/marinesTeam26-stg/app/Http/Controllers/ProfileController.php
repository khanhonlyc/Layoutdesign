<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Jenssegers\Agent\Agent;
use App\Models\Banner;
use App\Models\UniformRegistration;
use App\Models\PlayerUniform;
use Carbon\Carbon;

class ProfileController extends Controller
{
  public function customer(Request $request)
  {
    $title = "プロフィール設定 | 会員基本情報";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page27-sp';
    if($agent->isDesktop()) {
      $slug = 'page27-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  }

  public function customerEdit(Request $request)
  {
    $title = "プロフィール設定 | 会員基本情報";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page28-sp';
    if($agent->isDesktop()) {
      $slug = 'page28-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));    
  }

  public function customerConfirm(Request $request)
  {
    $title = "プロフィール設定 | 会員基本情報";
    if (!isset($request->delivFanNo)) {
      $request->validate(
        [
          'telNo1' => 'required|numeric|digits_between:1,5',
          'telNo2' => 'required|numeric|digits_between:1,4',
          'telNo3' => 'required|numeric|digits_between:1,4',
          'zipCode1' => 'required|numeric|digits_between:3,3',
          'zipCode2' => 'required|numeric|digits_between:4,4',
          'address1' => 'required',
          'address2' => 'required|regex:/^[^\x01-\x7E\x{FF61}-\x{FF9F}]+$/u|max:10',
          'address3' => 'required|regex:/^[^\x01-\x7E\x{FF61}-\x{FF9F}]+$/u|max:20',
          'address4' => 'required|regex:/^[^\x01-\x7E\x{FF61}-\x{FF9F}]+$/u|max:20',
          'address5' => 'nullable|regex:/^[^\x01-\x7E\x{FF61}-\x{FF9F}]+$/u|max:20',
       ],
        [
         'telNo1.required' => '電話番号が入力されていません。入力してください。',
          'telNo2.required' => '電話番号が入力されていません。入力してください。',
          'telNo3.required' => '電話番号が入力されていません。入力してください。',
          'zipCode1.required' => '郵便番号が入力されていません。入力してください。',
          'zipCode2.required' => '郵便番号が入力されていません。入力してください。',
          'address1.required' => '都道府県が選択されていません。選択してください。',
          'address2.required' => '市区郡が入力されていません。入力してください。',
          'address3.required' => '町名が入力されていません。入力してください。',
          'address4.required' => '番地が入力されていません。入力してください。',
          'address2.regex' => '市区郡は全角で入力してください。',
          'address3.regex' => '町名は全角で入力してください。',
          'address4.regex' => '番地は全角で入力してください。',
          'address5.regex' => 'マンション・アパート名は全角で入力してください。',
          'address2.max' => '市区郡は10文字以内で入力してください。',
          'address3.max' => '町名は20文字以内で入力してください。',
          'address4.max' => '番地は20文字以内で入力してください。',
          'address5.max' => 'マンション・アパート名はは20文字以内で入力してください。',
          'telNo1.numeric' => '半角数字以外の文字が含まれています。',
          'telNo2.numeric' => '半角数字以外の文字が含まれています。',
          'telNo3.numeric' => '半角数字以外の文字が含まれています。',
          'zipCode1.numeric' => '半角数字以外の文字が含まれています。',
          'zipCode2.numeric' => '半角数字以外の文字が含まれています。',
          'telNo1.digits_between' => '最大5桁までです。電話番号1欄',
          'telNo2.digits_between' => '最大4桁までです。電話番号2欄',
          'telNo3.digits_between' => '最大4桁までです。電話番号3欄',
          'zipCode1.digits_between' => '3桁で入力してください。郵便番号（前）',
          'zipCode2.digits_between' => '4桁で入力してください。郵便番号（後）',
        ]
      );
    }
    if (isset($request->delivFanNo)) {
      $request->validate(
        [
          'delivFanNo' => 'numeric|digits_between:10,10',
          'delivTelNo1' => 'required|numeric|digits_between:1,5',
          'delivTelNo2' => 'required|numeric|digits_between:1,4',
          'delivTelNo3' => 'required|numeric|digits_between:3,4',
          'delivLastName' => 'required|regex:/^[ぁ-んァ-ン一-龯ｧ-ﾝﾞﾟ]+$/',
          'delivFirstName' => 'required|regex:/^[ぁ-んァ-ン一-龯ｧ-ﾝﾞﾟ]+$/',
        ],
        [
          'delivTelNo1.required' => '送付先電話番号が入力されていません。ご確認ください。',
          'delivTelNo2.required' => '送付先電話番号が入力されていません。ご確認ください。',
          'delivTelNo3.required' => '送付先電話番号が入力されていません。ご確認ください。',
          'delivTelNo1.digits_between' => '最大5桁までです。送付先電話番号1欄',
          'delivTelNo2.digits_between' => '最大4桁までです。送付先電話番号2欄',
          'delivTelNo3.digits_between' => '最大4桁までです。送付先電話番号3欄',
          'delivLastName.required' => '送付先送付先お名前（姓）が入力されていません。ご確認ください。',
          'delivFirstName.required' => '送付先送付先お名前（名）が入力されていません。ご確認ください。',
          'delivFanNo.numeric' => '半角数字以外の文字が含まれています。',
          'delivTelNo1.numeric' => '半角数字以外の文字が含まれています。',
          'delivTelNo2.numeric' => '半角数字以外の文字が含まれています。',
          'delivTelNo3.numeric' => '半角数字以外の文字が含まれています。',
          'delivFanNo.digits_between' => '10桁の数字を入力してください。',
          'delivLastName.regex' => '半角文字が含まれています。',
          'delivFirstName.regex' => '半角文字が含まれています。',
        ]
      );
    }
    if (isset($request->emailChange)) {
      $request->validate(
        [
          'email' => 'required|regex:/^[!-~]+$/',
          'emailConf' => 'required|same:email',
        ],
        [
          'email.required' => 'メールアドレスが入力されていません。入力してください。',
          'email.regex' => 'メールアドレスは半角英数記号で入力してください。',
          'emailConf.required' => '確認用メールアドレスが入力されていません。入力してください。',
          'emailConf.same' => '確認用メールアドレスとメールアドレスが一致していません。ご確認ください。',
        ]

      );
    }
    if (isset($request->passChange)) {
      $request->validate(
        [
          'fanPasswordCurrent' => 'required',
          'fanPassword' => 'required|regex:/^(?=.*?[0-9]+)(?=.*?[a-zA-Z]+).{8,20}$/',
          'fanPasswordConf' => 'required|same:fanPassword',
        ],
        [
          'fanPasswordCurrent.required' => 'パスワードが入力されていません。入力してください。',
          'fanPassword.required' => '新しいパスワードが入力されていません。入力してください。',
          'fanPassword.regex' => '半角英数を含む8桁以上20桁以下で入力してください。',
          'fanPasswordConf.required' => '確認用パスワードが入力されていません。入力してください。',
          'fanPasswordConf.same' => '確認用パスワードとパスワードが一致していません。ご確認ください。',
        ]
      );
    }
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page29-sp';
    if($agent->isDesktop()) {
      $slug = 'page29-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));    
  }

  public function customerComplete(Request $request)
  {
    $title = "プロフィール設定 | 会員基本情報";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page30-sp';
    if($agent->isDesktop()) {
      $slug = 'page30-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));    
  }

  public function favorite(Request $request)
  {
    $title = "プロフィール設定 | お気に入り選手";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page31-sp';
    if($agent->isDesktop()) {
      $slug = 'page31-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));    
  }

  public function favoriteConfirm(Request $request)
  {
    $title = "プロフィール設定 | お気に入り選手";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page32-sp';
    if($agent->isDesktop()) {
      $slug = 'page32-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));    
  }

  public function favoriteComplete(Request $request)
  {
    $title = "プロフィール設定 | お気に入り選手";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page33-sp';
    if($agent->isDesktop()) {
      $slug = 'page33-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));    
  }

  public function uniform(Request $request)
  {
    $title = "プロフィール設定 | 背番号設定";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $playerUniforms = PlayerUniform::all();

    $agent = new Agent();
    $slug = 'page34-sp';
    if($agent->isDesktop()) {
      $slug = 'page34-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title', 'playerUniforms'));    
  }
  
  public function uniformConfirm(Request $request)
  {
    if ($request->isMethod('get')) {
      return redirect()->route('mypage.profile.uniform.index');
    }
    $request->name = strtoupper($request->name);
    $request->validate(
      [
        'name' => 'regex:/^[A-Za-z.]+$/|max:13',
        'number' => 'numeric|digits_between:0,3',
      ],
      [
        'name.max' => '最大13文字までです。13文字以内で入力してください。',
        'name.regex' => '※半角英字、ピリオド(.)のみで入力してください。',
        'number.digits_between' => '最大3文字までです。3文字以内で入力してください。',
        'number.numeric' => '半角数字にて入力ください。',
      ]
    );
    $title = "プロフィール設定 | 背番号設定";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page35-sp';
    if($agent->isDesktop()) {
      $slug = 'page35-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'request', 'title'));    
  }

  public function uniformComplete(Request $request)
  {
    if ($request->isMethod('get')) {
      return redirect()->route('mypage.profile.uniform.index');
    }
    $title = "プロフィール設定 | 背番号設定";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $uniform = UniformRegistration::where('amcno', $request->amcno)->first();
    if (!$uniform) {
      $uniform = new UniformRegistration();
      $uniform->created_at = $now;
      $uniform->amcno = $request->amcno;
    }
    $uniform->name = $request->name;
    $uniform->uniformnum = $request->number;
    $uniform->updated_at = $now;

    $uniform->save();

    $agent = new Agent();
    $slug = 'page36-sp';
    if($agent->isDesktop()) {
      $slug = 'page36-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'request', 'title'));    
  }

  public function getUniform(Request $request)
  {
    $data = [];
    $data['data'] = [];
    if (isset($request->amcNo)) {
      $find = UniformRegistration::where([
        ['amcno', $request->amcNo],
      ])->first();
      if ($find) {
        $data['data'] = [
          'name' => $find->name,
          'uniformnum' => $find->uniformnum,
        ];
      }
    }

    $data['status'] = "OK";
    return response()->json($data, 200);
  } 
}
