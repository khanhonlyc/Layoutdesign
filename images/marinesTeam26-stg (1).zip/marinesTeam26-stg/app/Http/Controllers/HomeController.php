<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Jenssegers\Agent\Agent;
use App\Models\Banner;
use App\Models\Movie;
use App\Models\ViewedMessage;
use App\Models\BrowsingLog;
use Carbon\Carbon;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Response;
use DB;
use View;

class HomeController extends Controller
{
  /**
   * Create a new controller instance.
   *
   * @return void
   */
  public function __construct()
  {
    // $this->middleware('auth');
  }
  /**
   * Show the application dashboard.
   *
   * @return \Illuminate\Contracts\Support\Renderable
   */
  public function index(Request $request)
  {
    $title = "";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $list = Movie::where('status', 1)
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->with(["tag_movies.tag"])->orderBy('created_at', 'DESC')->get();
    $listLive = $list->filter(function ($item) {
      return $item->movie_type_code == 2;
    });
    $listVideo = $list->filter(function ($item) {
      return $item->movie_type_code == 1;
    });
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();


    $tickets = json_decode(Redis::get('tickets'));
    if(empty(Redis::get('tickets')) || count((array)$tickets) == 0) {
      $responseTicket = Http::withOptions([
          'proxy' => '10.200.101.18:8080'
      ])->withHeaders([
          'Content-Type' => 'application/json',
          'Cache-Control' => 'no-cache'
      ])->get('https://cms-api.pacific-league.jp/api/game_schedule/?team=1992001&year=2023');

      $tickets = json_decode($responseTicket->body(), true);

      $tickets = is_array($tickets) ? $tickets : [];
      Redis::set('tickets', json_encode($tickets),  'EX', 300);
    }
    if(is_object($tickets)) {
      $tickets = json_decode(json_encode($tickets), true);
    }
    $battleToday = [];
    $tickets = array_filter($tickets, function ($value)
    {
      $toDay = date("Y-m-d");
      $endDay = date("Y-m-d",strtotime("+30 day"));
      return is_array($value) && $value['homeTeamCode'] == '1992001' && $value['gameDate'] >= $toDay && $value['gameDate'] <= $endDay;
    });

    // foreach ($tickets as $item) {
    //     $carbon = new Carbon();
    //     //$carbon = $carbon->addDays(3);
    //     if ($item['gameDate'] == $carbon->format('Y-m-d') && 
    //         $carbon >= Carbon::parse($carbon->format('Y-m-d') . ' ' . $item['gameTime'])->subHours(4) && 
    //         $carbon <= Carbon::parse($carbon->format('Y-m-d') . ' ' . $item['gameTime'])->addHours(4)) {
    //         $battleToday = $item;
    //         break;
    //     }
    // }

    $news = [];
    $news = json_decode(Redis::get('news'));
    if(empty(Redis::get('news')) || count($news) == 0) {
      $responseNews = Http::withOptions([
          'proxy' => '10.200.101.18:8080'
      ])->withHeaders([
          'Content-Type' => 'application/json',
          'Cache-Control' => 'no-cache'
      ])->get('http://cms-api.pacific-league.jp/api/news/?team=1992001');

      $news = json_decode($responseNews->body(), true);
      if(isset($news['status']) && $news['status'] == false) {
        $news = [];
      } else {
        $news = is_array($news) ? $news : [];
        usort($news ,function($first,$second){
          return strtolower($first['newsDate']) < strtolower($second['newsDate']);
        });

        $news = array_slice($news, 0, 5);
        Redis::set('news', json_encode($news),  'EX', 300);   
      }
    }
    
    $agent = new Agent();
    $slug = 'index-sp';
    if($agent->isDesktop()) {
      $slug = 'index-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listVideo', 'listBanner', 'listLive', 'title', 'tickets', 'news', 'battleToday'));
  }

  public function guidebook(Request $request)
  {
    $title = "GUIDE BOOK | 有料コンテンツ";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page64-sp';
    if($agent->isDesktop()) {
      $slug = 'page64-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  }  

  public function coupon(Request $request)
  {
    $title = "チケット引換券コード";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page15-sp';
    if($agent->isDesktop()) {
      $slug = 'page15-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  }  

  public function marines(Request $request)
  {
    $title = "デジタル会員証";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page20-sp';
    if($agent->isDesktop()) {
      $slug = 'page20-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  }  

  public function message(Request $request)
  {
    $title = "メッセージ・お知らせ";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page16-sp';
    if($agent->isDesktop()) {
      $slug = 'page16-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  }

  public function readMessage(Request $request)
  {
    $data = [];
    $readed = ViewedMessage::where([
      ['amcno', $request->amcno], 
      ['messageid', $request->messageid], 
    ])->first();
    if($readed) {
      $data['status'] = "FAIL";
      return response()->json($data, 200);
    }
    $newView = new ViewedMessage();
    $newView->messageid = $request->messageid;
    $newView->amcno = $request->amcno;
    $newView->created_at = Carbon::now();
    if ($newView->save()) {
      $data['status'] = "OK";
      return response()->json($data, 200);
    }
  }

  public function getMessage(Request $request)
  {
    $data = [];

    $list = ViewedMessage::where([
      ['amcno', $request->amcno],
    ])->get()->pluck('messageid');

    $data['status'] = "OK";
    $data['data'] = $list;
    return response()->json($data, 200);
  }

  public function createLog(Request $request){
    $log = new BrowsingLog();
    $log->access_ip = $request->server()['REMOTE_ADDR'];
    $log->user_agent = $request->server()['HTTP_USER_AGENT'];
    $log->referer = $request->header()['origin'] ? str_replace($request->header()['origin'][0], "", $request['referer']) : $request['referer'];
    $log->request_url =$request->header()['origin'] ?  str_replace($request->header()['origin'][0], "", $request->server()['HTTP_REFERER']) : $request->server()['HTTP_REFERER'];
    $log->marines_id = $request['amcno'];
    $log->regist_dt = Carbon::now();
    $log->method = $request['method'];
    $log->save();
    $data['status'] = "OK";
    return response()->json($data, 200);
  }

  public function apiTickets()
  {
    $responseTicket = Http::withOptions([
        'proxy' => '10.200.101.18:8080'
    ])->withHeaders([
        'Content-Type' => 'application/json',
        'Cache-Control' => 'no-cache'
    ])->get('https://cms-api.pacific-league.jp/api/game_schedule/?team=1992001&year=2023');

    $tickets = json_decode($responseTicket->body(), true);

    dd($tickets);
  }

  public function apiNews()
  {
    $responseNews = Http::withOptions([
        'proxy' => '10.200.101.18:8080'
    ])->withHeaders([
        'Content-Type' => 'application/json',
        'Cache-Control' => 'no-cache'
    ])->get('http://cms-api.pacific-league.jp/api/news/?team=1992001');

    $news = json_decode($responseNews->body(), true);

    var_dump($news);
  }

  public function getGuidebook(Request $request)
  {
    $agent = new Agent();
    $contents = View::make('parts.guidebook.guidebook-sp')->with('type', $request->type_member);
    if($agent->isDesktop()) {
      $contents = View::make('parts.guidebook.guidebook')->with('type', $request->type_member);
    }
    $response = Response::make($contents, 200);
    $response->header('Content-Type', 'text/plain');
    return $response;
  }

  public function apiPits($year)
  {
    $responsePit = Http::withOptions([
        'proxy' => '10.200.101.18:8080'
    ])->withHeaders([
        'Content-Type' => 'application/json',
        'Cache-Control' => 'no-cache'
    ])->get('http://cms-api.pacific-league.jp/api/result_pitcher/?team=1992001&year='.$year.'&kind=1&league=P');

    $pits = json_decode($responsePit->body(), true);

    dd($pits);
  }
  public function apiBats($year)
  {
    $responseBat = Http::withOptions([
        'proxy' => '10.200.101.18:8080'
    ])->withHeaders([
        'Content-Type' => 'application/json',
        'Cache-Control' => 'no-cache'
    ])->get('http://cms-api.pacific-league.jp/api/result_batter/?team=1992001&year='.$year.'&kind=1&league=P');

    $bats = json_decode($responseBat->body(), true);

    dd($bats);
  }
}
