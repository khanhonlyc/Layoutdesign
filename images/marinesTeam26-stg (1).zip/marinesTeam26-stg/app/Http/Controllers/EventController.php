<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Jenssegers\Agent\Agent;
use App\Models\Banner;
use Carbon\Carbon;

class EventController extends Controller
{

  public function index(Request $request)
  {
    $title = "イベント情報 | 申込受付";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page48-sp';
    if($agent->isDesktop()) {
      $slug = 'page48-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  }

  public function show($id)
  {
    $title = "イベント情報 | 申込受付";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $isActive = str_replace("https://".request()->header()['host'][0], "", isset(request()->header()['referer']) ? request()->header()['referer'][0] : '');
    $isActive = str_replace("/mypage/event", "", $isActive);
    
    switch ($isActive) {
      case '/applied':
        $typeEvent = '申込済み';
        break;
      case '/close':
        $typeEvent = '申込締切';
        break;      
      case '/performed':
        $typeEvent = '開催済み';
        break;
      
      default:
        $typeEvent = '申込受付';
        break;
    }
    $agent = new Agent();
    $slug = 'page49-sp';
    if($agent->isDesktop()) {
      $slug = 'page49-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'id', 'listBanner', 'title', 'typeEvent'));
  }

  public function confirm($id)
  {
    $title = "イベント情報 | 申込受付";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page50-sp';
    if($agent->isDesktop()) {
      $slug = 'page50-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'id', 'listBanner', 'title'));
  }

  public function complete($id)
  {
    $title = "イベント情報 | 申込受付";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page51-sp';
    if($agent->isDesktop()) {
      $slug = 'page51-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'id', 'listBanner', 'title'));
  }

  public function applied(Request $request)
  {
    $title = "イベント情報 | 申込済み";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page54-sp';
    if($agent->isDesktop()) {
      $slug = 'page54-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  }

  public function performed(Request $request)
  {
    $title = "イベント情報 | 開催済み";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page58-sp';
    if($agent->isDesktop()) {
      $slug = 'page58-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  }

  public function close(Request $request)
  {
    $title = "イベント情報 | 申込締切";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page56-sp';
    if($agent->isDesktop()) {
      $slug = 'page56-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  }
}
