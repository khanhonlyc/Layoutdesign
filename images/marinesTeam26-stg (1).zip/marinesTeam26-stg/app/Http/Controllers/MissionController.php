<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Jenssegers\Agent\Agent;
use App\Models\Movie;
use App\Models\Tag;
use App\Models\Banner;
use App\Models\FanRankName;
use Carbon\Carbon;
use View;

class MissionController extends Controller
{
  public function monthly(Request $request)
  {
    $title = "ミッション｜月間ミッション";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page68-sp';
    if($agent->isDesktop()) {
      $slug = 'page68-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  } 

  public function special(Request $request)
  {
    $title = "ミッション｜特別ミッション";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page69-sp';
    if($agent->isDesktop()) {
      $slug = 'page69-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  } 
}
