<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Jenssegers\Agent\Agent;
use App\Models\Banner;
use Carbon\Carbon;

class PointController extends Controller
{
  public function grant(Request $request)
  {
    $title = "Mポイント｜Mポイント受取（補助券）";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page66-sp';
    if($agent->isDesktop()) {
      $slug = 'page66-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title'));
  }

  public function complete(Request $request)
  {
    if ($request->isMethod('get')) {
      return redirect()->route('mypage.point.grant');
    }
    $title = "Mポイント｜Mポイント受取（補助券）";
    $now = Carbon::now();
    $date = Carbon::parse($now)->format('Y-m-d H:i:s');
    $gameDate = isset($request->game_date) ? $request->game_date : Carbon::now()->format('Y/m/d');
    $listBanner = Banner::where('status', 1)->with('fantypenameen')
    ->where('publish_start', '<=', $date)
    ->where('publish_end', '>=', $date)
    ->orderBy('sort_no')->get();

    $agent = new Agent();
    $slug = 'page67-sp';
    if($agent->isDesktop()) {
      $slug = 'page67-pc';
    }
    return view('pages.home.' . $slug, compact('slug', 'listBanner', 'title', 'gameDate'));
  }
}
