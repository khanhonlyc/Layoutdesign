<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PlayerUniform extends Model
{
    use HasFactory;

    protected $table = 'player_uniform';
    protected $fillable = [
        'playerCode',
        'playerUniformNo',
        'playerName',
        'uniformName'
    ];
}
