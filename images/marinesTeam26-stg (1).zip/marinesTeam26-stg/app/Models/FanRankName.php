<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
class FanRankName extends Model
{
  use HasFactory;
  public $timestamps = false;
  protected $table = 'fan_type_name_en';
  protected $fillable = [
    'fantypecode',
    'fantypenameen',
    'created_at',
    'updated_at',
    'deleted_at'
  ];
}
