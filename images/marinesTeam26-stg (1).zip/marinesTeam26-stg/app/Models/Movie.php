<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Carbon\Carbon;

class Movie extends Model
{
  use HasFactory, SoftDeletes;
  public $timestamps = false;
  protected $table = 'movie';
  protected $appends = ['is_new', 'fantypecodes'];
  protected $fillable = [
    'movie_type_code',
    'sort_no',
    'title',
    'thumbnail_url',
    'sauce',
    'fan_type_code',
    'publish_start',
    'publish_end',
    'status',
    'delete_flg',
    'created_at',
    'updated_at',
    'deleted_at'
  ];
  public function tag_movies() {
    return $this->hasMany(TagMovie::class);
  }

  public function getIsNewAttribute()
  {
      $timeNew = Carbon::now()->subDays(7);
      $timePublish = new Carbon($this->publish_start);
      if ($timePublish >= $timeNew) {
        return 1;
      }
      return 0;
  }

  public function getFantypecodesAttribute()
  {
      $array = explode(",", $this->fan_type_code);
      $newArr = [];
      foreach ($array as $key => $item) {
        switch ($item) {
          case 1:
            $newArr[] = '02';
            break;
          case 2:
            $newArr[] = '03';
            break;
          case 3:
            $newArr[] = '04';
            break;
          case 4:
            $newArr[] = '07';
            break;
          case 5:
            $newArr[] = '09';
            break;
          case 6:
            $newArr[] = '14';
            break;
          default:
            // code...
            break;
        }
      }
      return $newArr;
  }
}
