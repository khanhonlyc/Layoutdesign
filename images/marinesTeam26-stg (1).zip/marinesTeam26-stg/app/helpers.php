<?php

if (! function_exists('route_path')) {
    function route_path($name, $parameters = [])
    {
        return route($name, $parameters, false);
    }
}