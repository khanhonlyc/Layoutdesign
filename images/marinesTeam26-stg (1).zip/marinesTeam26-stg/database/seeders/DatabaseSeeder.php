<?php
namespace Database\Seeders;
use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\ViewedMessage;
use App\Models\FanRankName;
use App\Models\UniformRegistration;
use App\Models\RowsingLog;
use App\Models\Banner;
use App\Models\Movie;
use App\Models\Manager;
use App\Models\EditPermission;
class DatabaseSeeder extends Seeder
{
  /**
   * Seed the application's database.
   *
   * @return void
   */
  public function run()
  {
    // User::factory(30)->create();
    // ViewedMessage::factory(30)->create();
    // FanRankName::factory(30)->create();
    // UniformRegistration::factory(30)->create();
    // RowsingLog::factory(30)->create();
    // Banner::factory(30)->create();
    // Movie::factory(30)->create();
    // Manager::factory(30)->create();
    // EditPermission::factory(30)->create();
  }
}
