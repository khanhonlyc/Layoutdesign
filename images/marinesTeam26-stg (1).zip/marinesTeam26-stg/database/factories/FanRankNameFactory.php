<?php
namespace Database\Factories;
use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\FanRankName;
class FanRankNameFactory extends Factory
{
    protected $model = FanRankName::class;
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'fantypecode'    => $this->faker->text(10),
            'fantypenameen'    => $this->faker->text(10),
            'created_at'    => $this->faker->dateTime()
        ];
    }
}
