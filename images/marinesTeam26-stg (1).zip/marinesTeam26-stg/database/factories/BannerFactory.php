<?php
namespace Database\Factories;
use Illuminate\Database\Eloquent\Factories\Factory;
use App\Models\Banner;
class BannerFactory extends Factory
{
  protected $model = Banner::class;
  /**
   * Define the model's default state.
   *
   * @return array
   */
  public function definition()
  {
    return [
      'banner_type_code' => $this->faker->numberBetween(1, 30),
      'sort_no' => $this->faker->numberBetween(1, 30),
      'title' => $this->faker->text(10),
      'image_url' => $this->faker->imageUrl(),
      'url' => $this->faker->url(),
      'target' => $this->faker->text(10),
      'fan_type_code' => $this->faker->numberBetween(1, 30),
      'publish_start' => $this->faker->dateTime(),
      'publish_end' => $this->faker->dateTime(),
      'status' => $this->faker->randomElement([0, 1]),
      'delete_flg' => $this->faker->randomElement([0, 1]),
      'create_at' => $this->faker->dateTime(),
      'update_at' => $this->faker->dateTime(),
      'delete_at' => $this->faker->dateTime()
    ];
  }
}
