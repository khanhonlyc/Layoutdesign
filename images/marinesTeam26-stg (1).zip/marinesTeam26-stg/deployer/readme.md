## インストール
- deployerディレクトリをhotfactoryユーザのhome直下に設置  
- set('dep_env', 'staging'); を環境によって書き換える
```
# staging
set('dep_env', 'staging');
# production
set('dep_env', 'production');
```
## その他事前準備
### サーバでのgit config設定
```
git config --global http.proxy http://10.200.101.18:8080
git config --global user.name "team26-Deployer"
git config --global credential.helper store

一度cloneを手動で実施し、passwordをstoreさせる
```
### 環境変数にproxy設定追加
composerがproxyに阻まれるので追加する必要あり
```
# .bashrc 追記
export HTTP_PROXY=http://10.200.101.18:8080
export HTTPS_PROXY=http://10.200.101.18:8080
export HTTP_PROXY_REQUEST_FULLURI=0
export HTTPS_PROXY_REQUEST_FULLURI=0
```

## デプロイ方法
サーバ上で実行
- @PROD
    - master サーバ (m2cwvsv01)からのみ実行。（slaveにも同時にdeploy出来ます）
    - mainブランチのみデプロイ可能
  ```
  [hotfactory@m2cwvsv01 ~]$ pwd
  /home/hotfactory
  [hotfactory@m2cwvsv01 ~]$ dep deploy
  ```
  - prodでデプロイした際のコンソール表示
  ```
  [hotfactory@m2cwvsv01 ~]$ dep deploy
  Select hosts: (comma separated)
  [0] localhost
  [1] m2cwvsv02
  > 0,1                    # デプロイ対象hostの指定。カンマ区切りで0,1を指定してください
  task validation
  task set_branch
  task deploy:info
  [localhost] info deploying main
  [m2cwvsv02] info deploying main
  task deploy:setup
  ⠇ actory@localhost's password:   ⠴   # sudo のパスワード
  task deploy:lock
  task deploy:release
  task deploy:update_code
  task deploy:shared
  task deploy:writable
  task deploy:vendors
  task artisan:storage:link
  task artisan:config:cache
  task artisan:route:cache
  task artisan:view:cache
  task artisan:event:cache
  task artisan:migrate
  task deploy:symlink
  task deploy:unlock
  task deploy:cleanup
  task deploy:success
  [localhost] info successfully deployed!
  [m2cwvsv02] info successfully deployed!
  task nginx_reload
  [localhost] run sudo systemctl reload php81-php-fpm
  [m2cwvsv02] run sudo systemctl reload php81-php-fpm
  [localhost]  [sudo] password for hotfactory:   # sudo のパスワード
  [m2cwvsv02]  [sudo] password for hotfactory:   # sudo のパスワード
  [localhost] run sudo systemctl reload nginx
  [localhost]  [sudo] password for hotfactory:   # sudo のパスワード
  [m2cwvsv02] run sudo systemctl reload nginx
  [m2cwvsv02]  [sudo] password for hotfactory:   # sudo のパスワード
  [hotfactory@m2cwvsv01 ~]$
  ```
  
- @STG
    - トピックブランチをデプロイする場合
  ```
  dep deploy --branch={topic_branch_name}
  ```
    - stagingブランチをデプロイする場合
  ```
  dep deploy
  ```
