<?php
namespace Deployer;
use Deployer\Exception\ConfigurationException;

require 'recipe/laravel.php';

// Config

// Project name
set('application','marinesTeam26');

// Project repository
set('repository','https://github.com/HOT-FACTORY/marinesTeam26.git');

// [Optional] Allocate tty for git clone. Default value is false.
//set('git_tty', true);

set('keep_releases', 5);

set('dep_env', 'production');

add('shared_files', []);
add('shared_dirs', []);
add('writable_dirs', []);

// Hosts
import('servers.yaml');

// Hooks
// Tasks
desc('validation');
task('validation', function () {
  $dep_env = get('dep_env');
  if($dep_env === 'production' && !empty(input()->getOption('branch'))) {
    throw new ConfigurationException('本番環境ではTopicブランチをデプロイ出来ません。');
  }
});
fail('validation', 'deploy:failed');

desc('set_branch');
task('set_branch', function() {
  $branch = null;
  $stage = get('dep_env');
  if ($stage === 'production') {
    $branch = 'main';
  } else if ($stage === 'staging') {
    $branch = input()->getOption('branch');
    if (empty($branch)) {
      $branch = 'stg';
    }
  }
  set('branch', $branch);
});
before('deploy', 'validation');
after('validation', 'set_branch');

after('deploy:failed', 'deploy:unlock');

// nginx,php再起動
after('deploy:success', 'nginx_reload');
task('nginx_reload', function () {
  run('sudo systemctl reload php81-php-fpm');
  run('sudo systemctl reload nginx');
});
