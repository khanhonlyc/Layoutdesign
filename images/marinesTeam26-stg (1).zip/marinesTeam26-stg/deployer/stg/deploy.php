<?php
namespace Deployer;

require 'recipe/laravel.php';
//require 'contrib/slack.php';

// Config

// Project name
set('application','marinesTeam26');

// Project repository
set('repository','https://github.com/HOT-FACTORY/marinesTeam26.git');

// [Optional] Allocate tty for git clone. Default value is false.
//set('git_tty', true);

set('keep_releases', 5);

set('dep_env', 'staging');

add('shared_files', []);
add('shared_dirs', []);
add('writable_dirs', []);

// Hosts

host('localhost')
  ->set('remote_user', 'hotfactory')
  ->set('deploy_path', '/var/www/site');

// Hooks
// Tasks
task('set_branch', function(){
  $branch = null;
  $stage = get('dep_env');
  if ($stage == 'production') {
    $branch = 'main';
  } else if ($stage == 'staging') {
    $branch = input()->getOption('branch');
    if (empty($branch)) {
      $branch = 'stg';
    }
  }
  set('branch', $branch);
});
before('deploy', 'set_branch');

after('deploy:failed', 'deploy:unlock');

// slack
//set('slack_webhook', 'https://hooks.slack.com/services/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');
//after('set_branch', 'slack:notify');
//after('deploy:success', 'slack:notify:success');
//after('deploy:failed', 'slack:notify:failure');
//after('rollback', 'slack:notify:rollback');

// nginx,php再起動
after('deploy:success', 'nginx_reload');
task('nginx_reload', function () {
  run('sudo systemctl reload php81-php-fpm');
  run('sudo systemctl reload nginx');
});
