<div class="login-pp">
  <div class="js-bg-login"></div>
  <div class="content">
    <h3>マイページ ログイン</h3>
    <div class="form">
      <form action="">
        <div class="form-group">
          <label class="icon" for=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
              <path d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0S96 57.3 96 128s57.3 128 128 128zm-45.7 48C79.8 304 0 383.8 0 482.3C0 498.7 13.3 512 29.7 512H418.3c16.4 0 29.7-13.3 29.7-29.7C448 383.8 368.2 304 269.7 304H178.3z" /></svg></label>
          <input class="form-control" type="text" placeholder="マリーンズID（会員番号）">
        </div>
        <div class="form-group">
          <label class="icon" for=""><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
              <path d="M144 144v48H304V144c0-44.2-35.8-80-80-80s-80 35.8-80 80zM80 192V144C80 64.5 144.5 0 224 0s144 64.5 144 144v48h16c35.3 0 64 28.7 64 64V448c0 35.3-28.7 64-64 64H64c-35.3 0-64-28.7-64-64V256c0-35.3 28.7-64 64-64H80z" /></svg></label>
          <input class="form-control" placeholder="パスワード" type="password">
        </div>
        <div class="form-group">
          <label class="checkbox">
            <input type="checkbox">
            <span>ログイン状態を保持する</span>
          </label>
        </div>
        <div class="form-group">
          <button type="submit" class="btn-login">ログインする</button>
        </div>
      </form>
      <a class="q-pass" href="#">パスワードを忘れた方はこちら ></a>
    </div>
    <div class="note">
      <div class="item">
        <h4>ログイン</h4>
        <p>マリーンズID（会員番号）とパスワードを入力してログインしてください。<br> ※マリーンズIDは初期入会時に発行される89で始まる10ケタの番号です。会員証（プラスチックカード）の裏面、もしくはマイページやMアプリの「デジタル会員証」で確認できます。※マリーンズIDでログインすることでチケット先行販売に参加することができます。</p>
        <a href="#">詳細はこちら ></a>
      </div>
      <div class="item">
        <h4>2021年度以前に入会された方</h4>
        <p>2021年度有料会員の方で、2022年度有料継続入会の手続きがお済みでない場合は、2022年2月1日以降無料会員としてログインされます。 </p>
      </div>
    </div>
  </div>
</div>