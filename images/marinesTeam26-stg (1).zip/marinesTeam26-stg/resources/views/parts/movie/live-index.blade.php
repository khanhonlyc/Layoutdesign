@if(count($listLive) || count($listVideo))
@if(count($listLive))
<div class="items">
<div class="heading-box">
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 512">
    <!--! Font Awesome Pro 6.2.0 by @fontawesome  - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2022 Fonticons, Inc. -->
    <path d="M54.2 202.9C123.2 136.7 216.8 96 320 96s196.8 40.7 265.8 106.9c12.8 12.2 33 11.8 45.2-.9s11.8-33-.9-45.2C549.7 79.5 440.4 32 320 32S90.3 79.5 9.8 156.7C-2.9 169-3.3 189.2 8.9 202s32.5 13.2 45.2 .9zM320 256c56.8 0 108.6 21.1 148.2 56c13.3 11.7 33.5 10.4 45.2-2.8s10.4-33.5-2.8-45.2C459.8 219.2 393 192 320 192s-139.8 27.2-190.5 72c-13.3 11.7-14.5 31.9-2.8 45.2s31.9 14.5 45.2 2.8c39.5-34.9 91.3-56 148.2-56zm64 160c0-35.3-28.7-64-64-64s-64 28.7-64 64s28.7 64 64 64s64-28.7 64-64z"></path></svg>
  <h2>LIVE <span>ライブ</span></h2>
</div>
</div>
@foreach ($listLive as $key => $item)
<div class="items mt-2">
<div class="row m-0 align-items-center">
  <div class="col-md-7 p-0">
    <a class="images" href="{{ route_path('mypage.movie.show', $item->id) }}">
      <img class="w-100 d-block" src="{{ asset($item->thumbnail_url) }}" alt="">
    </a>
  </div>
  <div class="col-md-5 p-0">
    <div class="content-custom-news">
      <span class="date">
        @if($item->is_new)
          <small>NEW</small>
        @endif
        <span>{{ \Carbon\Carbon::parse($item->publish_start)->format('Y.m.d') }}</span>
      </span>
      <h3>{{ $item->title }}</h3>
      <p>@foreach ($item->tag_movies as $tag_movie) {{$tag_movie->tag ? $tag_movie->tag->tag_name : ''}} @endforeach</p>
    </div>
  </div>
</div>
</div>
@endforeach
@else
<div class="items">
<div class="row m-0 align-items-center">
  <div class="col-md-7 p-0">
    <a class="images" href="{{ route_path('mypage.movie.show', $listVideo->first()->id) }}">
      <img class="w-100 d-block" src="{{ asset($listVideo->first()->thumbnail_url) }}" alt="">
    </a>
  </div>
  <div class="col-md-5 p-0">
    <div class="content-custom-news">
      <span class="date">
        @if($listVideo->first()->is_new)
          <small>NEW</small>
        @endif
        <span>{{ \Carbon\Carbon::parse($listVideo->first()->publish_start)->format('Y.m.d') }}</span>
      </span>
      <h3>{{ $listVideo->first()->title }}</h3>
      <p>@foreach ($listVideo->first()->tag_movies as $tag_movie) {{$tag_movie->tag ? $tag_movie->tag->tag_name : ''}} @endforeach</p>
    </div>
  </div>
</div>
</div>
@endif
@endif
