@if(count($listLive) > 0)
<div class="heading-custom-plus">
    <h2>LIVE</h2>
    <h3><i class="fa-solid fa-wifi"></i> LIVE <span>ライブ</span></h3>
</div>
<div class="row m-0 align-items-center items">
    @foreach ($listLive as $item)
        <div class="col-md-7 p-0">
          <div class="items" style="margin-bottom:30px">
            <a class="images" href="{{ route_path('mypage.movie.show', $item->id) }}">
              <img class="w-100 d-block" src="{{ asset($item->thumbnail_url) }}" alt="">
            </a>
          </div>
        </div>
        <div class="col-md-5 p-0">
            <div class="content-custom-news content-custom-news2">
            <span class="date">
                @if($item->is_new)
                  <small>NEW</small>
                @endif
                <span>{{ \Carbon\Carbon::parse($item->publish_start)->format('Y.m.d') }}</span>
            </span>
            <h3>{{ $item->title }}</h3>
            <p>@foreach ($item->tag_movies as $tag_movie) {{$tag_movie->tag ? $tag_movie->tag->tag_name : ''}} @endforeach</p>
            </div>
        </div>
    @endforeach
</div>
@elseif(count($listVideo) > 0)
<div class="heading-custom-plus">
    <h2>recommend</h2>
    <h3><i class="fa-regular fa-thumbs-up"></i> recommend <span>レコメンド</span></h3> 
</div>
<div class="">
    <div class="items">
        <div class="row m-0 align-items-center">
            <div class="col-md-7 p-0">
          <div class="items" style="margin-bottom:30px">
            <a class="images" href="{{ route_path('mypage.movie.show', $listVideo->first()->id) }}">
              <img class="w-100 d-block" src="{{ asset($listVideo->first()->thumbnail_url) }}" alt="">
            </a>
          </div>
            </div>
            <div class="col-md-5 p-0">
                <div class="content-custom-news">
                <span class="date">
                    @if($listVideo->first()->is_new)
                      <small>NEW</small>
                    @endif
                    <span>{{ \Carbon\Carbon::parse($listVideo->first()->publish_start)->format('Y.m.d') }}</span></span>
                <h3>{{ $listVideo->first()->title }}</h3>
                <p>@foreach ($listVideo->first()->tag_movies as $tag_movie) {{$tag_movie->tag ? $tag_movie->tag->tag_name : ''}} @endforeach</p>
                </div>
            </div>
        </div>
    </div>                  
</div>
@endif
