@foreach ($listVideo as $key => $item)
  @if(!count($listLive) && $key == 0)
    @continue
  @endif
  <div class="items">
    <div class="img-custom">
      <div>
        <a class="images" href="{{ route_path('mypage.movie.show', $item->id) }}">
          <img class="w-100 d-block" src="{{ asset($item->thumbnail_url) }}" alt="">
        </a>
      </div>
      <span class="date">
        @if($item->is_new)
          <small>NEW</small>
        @endif
        <span>{{ \Carbon\Carbon::parse($item->publish_start)->format('Y.m.d') }}</span>
      </span>
    </div>
    <h3>{{ $item->title }}</h3>
    <p>@foreach ($item->tag_movies as $tag_movie) {{$tag_movie->tag ? $tag_movie->tag->tag_name : ''}} @endforeach</p>
  </div>
@endforeach
