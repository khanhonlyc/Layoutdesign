@if(count($list))
@foreach ($list as $item)
<div class="col-md-4">
  <div class="items items-news-archive">
      <a class="images" href="{{ route_path('mypage.movie.show', $item->id) }}">
        <img class="w-100 d-block" src="{{ asset($item->thumbnail_url) }}" alt="">
      </a>
      <span class="date">
        @if($item->is_new)
          <small>NEW</small>
        @endif
        <span>{{ \Carbon\Carbon::parse($item->publish_start)->format('Y.m.d') }}</span>
      </span>
      <h3>{{ $item->title }}</h3>
      <p>@foreach ($item->tag_movies as $tag_movie) {{$tag_movie->tag ? $tag_movie->tag->tag_name : ''}} @endforeach</p>
  </div>
</div>
@endforeach
<div class="col-md-12">
    {!! $list->appends($_GET)->links('pagination.paginate') !!}
</div>
@endif
