@if ($type == 9)
<div class="text-center">
	<p class="mt-4 font-weight-bold">
	ガイドブックのダウンロードは<br>
	有料会員限定となります。</p>
</div>
<a class="btn-custom btn-custom-icon" href="/mypage/">ホームへもどる</a>
@else
<div class="title">
  <h3>2023年度版 ガイドブック</h3>
</div>
<div class="content">
  <div class="images">
    <img src="/mypage/images/thumb-guidebook2023.png" alt="">
  </div>
  <a class="btn-custom btn-pdf" download="2023年度版 ガイドブック"
  href="/mypage/pdf/guidebook2023.pdf">ダウンロードする</a>
  <p class="text-center m-0">（約15MB）</p>
</div>
@endif
