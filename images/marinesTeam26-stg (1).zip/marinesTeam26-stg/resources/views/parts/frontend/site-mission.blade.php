<section class="site-mission site-mission-page pd-main">
    <h2 class="heading">CHALLENGE MISSION</h2>
    <div class="list-content" id="mission-index-html">
      <div class="content text-center">
          <p><strong>現在受付中のミッションはありません。</strong></p>
      </div>
    </div>
    <a class="btn-custom btn-custom-icon" href="{{ route_path('mypage.mission.monthly') }}">ミッションの詳細はこちら</a>
  </section>
