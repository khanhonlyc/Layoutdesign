<section class="site-logo-pn pd-main">
  <div class="container">
    @yield("image_17")
  </div>
</section>
