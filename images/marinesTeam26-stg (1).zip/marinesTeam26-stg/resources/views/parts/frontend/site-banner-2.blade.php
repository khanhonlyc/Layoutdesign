<section class="site-banner site-banner-2 slick-slider-custom">
  @yield("title_image_10")
</section>
