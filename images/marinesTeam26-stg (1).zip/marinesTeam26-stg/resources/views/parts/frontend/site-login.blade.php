<section class="site-login one-time-password-message" style="display: none;">
  <div class="container">
    @yield("text_19")
  </div>
</section>
