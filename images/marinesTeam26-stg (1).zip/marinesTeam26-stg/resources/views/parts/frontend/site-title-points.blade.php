<section class="site-title-points">
  <div class="container">
    @yield("text_25")
  </div>
</section>