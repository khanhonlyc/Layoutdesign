<section class="site-infor-event">
  <div class="container">
    <div class="infor-event">
      @yield("text_date_33")
    </div>
  </div>
</section>
