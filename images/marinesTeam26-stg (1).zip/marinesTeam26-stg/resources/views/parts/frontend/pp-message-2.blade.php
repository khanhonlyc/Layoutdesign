<section class="pp-message js-pp-mess2 active">
  @yield("text_img_28")
</section>
