<section class="site-member pd-main">
  <div class="container">
    @yield("title_image_27")
  </div>
</section>
