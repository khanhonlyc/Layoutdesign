<section class="site-marines pd-main">
  <div class="container">
    @yield("title_image_date_15")
  </div>
</section>
