@extends('parts.frontend.site-member')
@section('title_image_27')
<div class="member">
  <div class="vit">
    <h3 class="fan-type-css rank-name-eng"></h3>
    <img style="display: none;" class="junior-v" src="/mypage/images/v4.png" alt="">
    <img style="display: none;" class="academy-v" src="/mypage/images/v2.png" alt="">
  </div>
  <div class="member_content">
    <span class="fan-type-name"></span>
    <div class="img" id="qr-code">
    </div>
    <p>マリーンズID</p>
    <p class="amc-no"></p>
  </div>
  <div class="img-member">
    <img style="display: none;" class="w-100 academy-v" src="/mypage/images/v1.png" alt="">
  </div>
  <div class="img-member2">
    <img style="display: none;" class="w-100 academy-v" src="/mypage/images/v3.png" alt="">
  </div>
</div>
<div class="member-box">
  <h3><div class="fan-name" style="color: #000;"></div>さんの現在のステージ</h3>
  <div class="content">
    <div class="m">
      <svg viewBox="0 0 36 36" class="circular-chart green">
        <path class="circle-bg" d="M18 2.0845
                    a 15.9155 15.9155 0 0 1 0 31.831
                    a 15.9155 15.9155 0 0 1 0 -31.831" />
        <path class="circle circle-rank-color" d="M18 2.0845
                    a 15.9155 15.9155 0 0 1 0 31.831
                    a 15.9155 15.9155 0 0 1 0 -31.831" />
        <text x="18" y="20.35" class="percentage"></text>
      </svg>
      <div class="hi">
        <h4 class="fc-rank-name"></h4>
        <span>ステージ</span>
      </div>
    </div>
    <div class="mpt">
      <p>累計 Mポイント</p>
      <span class="t"><span class="sum-point-m"></span><small>Mpt</small></span>
    </div>
    <div class="mpt check-rank">
      <p><span class="next-fc-rank-name next-fc-rank-color"></span>ステージまであと</p>
      <span class="t"><span class="necessary-point"></span><small>Mpt</small></span>
    </div>
    <div class="note">
      <a class="text-dark" href="https://www.marines.co.jp/fanclub/point/stage.html" target="_blank">
        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13">
          <g id="Group_369" data-name="Group 369" transform="translate(660 -1447)">
            <text id="_" data-name="?" transform="translate(-656.4 1457)" font-size="10" font-family="Arial-BoldMT, Arial" font-weight="700" letter-spacing="0.02em">
              <tspan x="0" y="0">?</tspan>
            </text>
            <g id="Ellipse_22" data-name="Ellipse 22" transform="translate(-660 1447)" fill="none" stroke="#000" stroke-width="1">
              <circle cx="6.5" cy="6.5" r="6.5" stroke="none" />
              <circle cx="6.5" cy="6.5" r="6" fill="none" />
            </g>
          </g>
        </svg> Mポイントステージ制度とは </a>
      <a class="text-dark" href="https://www.marines.co.jp/fanclub/point/saveup.html" target="_blank">
        <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 13 13">
          <g id="Group_369" data-name="Group 369" transform="translate(660 -1447)">
            <text id="_" data-name="!" transform="translate(-655 1457)" font-size="10" font-family="Arial-BoldMT, Arial" font-weight="700" letter-spacing="0.02em">
              <tspan x="0" y="0">!</tspan>
            </text>
            <g id="Ellipse_22" data-name="Ellipse 22" transform="translate(-660 1447)" fill="none" stroke="#000" stroke-width="1">
              <circle cx="6.5" cy="6.5" r="6.5" stroke="none" />
              <circle cx="6.5" cy="6.5" r="6" fill="none" />
            </g>
          </g>
        </svg> Mポイントの貯め方 </a>
    </div>
  </div>
</div>
<a class="btn-custom btn-custom-icon" href="{{ route_path('mypage.profile.customer.index') }}">会員情報はこちら</a>
@endsection
