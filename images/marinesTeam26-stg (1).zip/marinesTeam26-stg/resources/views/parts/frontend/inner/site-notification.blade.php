@extends('parts.frontend.site-notification')
@switch($slug)
  @case("index-sp")
    @php  @endphp
    @break
  @case("index2-sp")
    @php  @endphp
    @break
  @default
    @php  @endphp
    @break
@endswitch
@section('title_3')
  <div class="items">千葉　純一郎 様1</div>
  <div class="items">千葉　純一郎 様2</div>
  <div class="items">千葉　純一郎 様3</div>
@endsection
