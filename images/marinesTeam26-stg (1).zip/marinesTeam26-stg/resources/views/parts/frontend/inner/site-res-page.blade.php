@extends('parts.frontend.site-res-page')
@section('text_31')
<p>修正したい項目のみを入力して確認を押してください</p>
<div class="tt-res">
  <h3>入力についてのご注意</h3>
  <div class="text">
    <p>登録情報の入力時には下記に関して注意してください。</p>
    <p>・難しい漢字の場合はなるべく略字で入力してください。<br> ・入力できない文字は、変換の上入力してください。<br> （例 ：「髙」→「高」）<span class="modal-open">※詳細はこちら</span></p>
  </div>
</div>
<p class="m-0">※シーズンシート登録情報の変更は、別途マリーンズインフォメーションセンター(03-5682-6329)へ連絡をお願いします。</p>
@endsection
