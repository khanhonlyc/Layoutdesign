@extends('parts.frontend.site-news')
@section('title_content_date_image_9')
<div class="container">
  <h2 class="heading">NEWS</h2>
  <div class="list-news">
    @empty($news)
    <div class="text-center text-empty-news">
      <span>球団公式ニュースは以下からご確認ください。</span>
    </div>
    @else
    @foreach ($news as $new)
    @if(is_array($new))
      @php
        $new = (object) $new;
      @endphp
    @endif
    <div class="items-news">
      <div class="content">
        <span>{{ \Carbon\Carbon::parse($new->newsDate)->format('Y/m/d') }}（{{ $weekMap[\Carbon\Carbon::parse($new->newsDate)->dayOfWeek] }}）</span>
        <h3><a href="{{ $new->newsUrl }}" target="_blank" rel="noopener noreferrer">{{ $new->newsTitle ?? '' }}</a></h3>
      </div>
      <div class="l-category">
        <a class="category" style="background-color:{{ NEW_BG_COLOR[$new->newsCategory] ?? '#000' }}" href="#">{{ $new->newsCategory ?? '' }}</a>
      </div>
    </div>
    @endforeach
    @endempty
  </div>
  <a class="btn-custom" href="https://www.marines.co.jp/news/list/index.html" target="_blank">NEWS一覧はこちら</a>
</div>
@endsection
