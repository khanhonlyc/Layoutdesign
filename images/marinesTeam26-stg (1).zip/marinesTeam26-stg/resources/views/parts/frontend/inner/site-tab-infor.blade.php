@extends('parts.frontend.site-tab-infor')
@section('text_33')
<ul id="scrollcenter">
  <li class="{{ (request()->is('mypage/event')) || (isset($typeEvent) && $typeEvent == '申込受付') ? 'active' : '' }}"><a href="{{ route_path('mypage.event.index') }}">申込受付</a></li>
  <li class="{{ (request()->is('mypage/event/applied')) || (isset($typeEvent) && $typeEvent == '申込済み') ? 'active' : '' }}"><a href="{{ route_path('mypage.event.applied') }}">申込済み</a></li>
  <li class="{{ (request()->is('mypage/event/close')) || (isset($typeEvent) && $typeEvent == '申込締切') ? 'active' : '' }}"><a href="{{ route_path('mypage.event.close') }}">申込締切</a></li>
  <li class="{{ (request()->is('mypage/event/performed')) || (isset($typeEvent) && $typeEvent == '開催済み') ? 'active' : '' }}"><a href="{{ route_path('mypage.event.performed') }}">開催済み</a></li>
</ul>
@endsection
