@extends('parts.frontend.site-link-member')
@switch($slug)
  @case("index-sp")
    @php  @endphp
    @break
  @case("index2-sp")
    @php  @endphp
    @break
  @default
    @php  @endphp
    @break
@endswitch
@section('text_18')
<div class="text-center">
  <a href="#">有料会員への入会はこちらから！></a>
</div>
@endsection
