@extends('parts.frontend.site-login')
@section('text_19')
<div class="content">
  <p>ワンタイムパスワードにてログインされました。パスワードの変更を行ってください。</p>
  <a class="btn-custom" href="#">パスワードの変更はこちら</a>
</div>
@endsection
