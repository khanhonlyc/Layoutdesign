@extends('parts.frontend.site-mission')
@section('title_date_price_11')
<h2 class="heading">CHALLNGE MISSION</h2>
<div class="date">
  <p><span>0</span> 月 月間ミッション</p>
  <span class="date">［2023.00.00 - 00.00］</span>
</div>
<div class="row row-custom">
  <div class="col-4 col-custom">
    <div class="items">
      <div class="mpt"> CLEAR </div>
      <div class="mpt">5Mpt</div>
      <div class="number">
        <span class="mi">Mission</span>
        <span class="so">01</span>
      </div>
      <h3>期間中の <br> グッズ購入金額が</h3>
      <p>2,000円以上</p>
    </div>
  </div>
  <div class="col-4 col-custom">
    <div class="items">
      <div class="mpt"> CLEAR </div>
      <div class="mpt">5Mpt</div>
      <div class="number">
        <span class="mi">Mission</span>
        <span class="so">02</span>
      </div>
      <h3>期間中の <br> グッズ購入金額が</h3>
      <p>2,000円以上</p>
    </div>
  </div>
  <div class="col-4 col-custom">
    <div class="items">
      <div class="mpt"> CLEAR </div>
      <div class="mpt">5Mpt</div>
      <div class="number">
        <span class="mi">Mission</span>
        <span class="so">03</span>
      </div>
      <h3>期間中の <br> グッズ購入金額が</h3>
      <p>2,000円以上</p>
    </div>
  </div>
  <div class="col-4 col-custom">
    <div class="items">
      <div class="mpt"> CLEAR </div>
      <div class="mpt">5Mpt</div>
      <div class="number">
        <span class="mi">Mission</span>
        <span class="so">04</span>
      </div>
      <h3>期間中の <br> グッズ購入金額が</h3>
      <p>2,000円以上</p>
    </div>
  </div>
  <div class="col-4 col-custom">
    <div class="items">
      <div class="mpt"> CLEAR </div>
      <div class="mpt">5Mpt</div>
      <div class="number">
        <span class="mi">Mission</span>
        <span class="so">05</span>
      </div>
      <h3>期間中の <br> グッズ購入金額が</h3>
      <p>2,000円以上</p>
    </div>
  </div>
  <div class="col-4 col-custom">
    <div class="items">
      <div class="mpt"> CLEAR </div>
      <div class="mpt">5Mpt</div>
      <div class="number">
        <span class="mi">Mission</span>
        <span class="so">06</span>
      </div>
      <h3>期間中の <br> グッズ購入金額が</h3>
      <p>2,000円以上</p>
    </div>
  </div>
</div>
<a class="btn-custom" href="#">ミッションの詳細はこちら</a>
@endsection
