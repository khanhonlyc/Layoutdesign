@extends('parts.frontend.site-banner')
@section('title_content_image_4')
<div class="items items-mobile" style="background-image:url('/mypage/images/den.png');">
  <div class="ao" style="background-image: url(/mypage/images/sp2.png);"></div>
  <div class="container" style="position: relative; z-index: 3;">
    <div class="content">
      <h3 class="fan-name"></h3>
      <p class="br">現在のMポイント＞<a class="text-white" href="{{ route_path('mypage.history.point') }}">履歴</a></p>
      <p class="mpt"><span class="sum-point-m"></span> <span>Mpt</span></p>
      <p class="check-rank"><span class="next-fc-rank-name"></span>ステージまであと <span class="necessary-point"></span>Mpt</p>
      <p class="br">来場回数＞<a class="text-white" href="{{ route_path('mypage.history.visit') }}">履歴</a></p>
      <div class="img">
        <p><span class="present-comming"></span> <span>回</span></p>
        <div class="i present-comming-img">
        </div>
      </div>
    </div>
  </div>
  <div class="warp-uniform">
    <div class="bg-uniform">
      <div class="inner-uniform">
        <div id="js_Name" class="txt-name"></div>
        <div id="js_Number" class="txt-number"></div>
      </div>
    </div>
  </div>
  <a class="icon" href="{{ route_path('mypage.profile.uniform.index') }}"><img src="/mypage/images/st.png" alt=""></a>

</div>

@endsection
