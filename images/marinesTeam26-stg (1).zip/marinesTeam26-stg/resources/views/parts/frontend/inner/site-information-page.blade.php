@extends('parts.frontend.site-information-page')
@section('text_date_30')
<div class="table-information">
  <h2><span class="year1"></span>年度申込情報</h2>
    <table class="table">
      <tr>
        <td>会員種別</td>
        <td class="fan-type1-name"></td>
      </tr>
      <tr class="no-free">
        <td>特典グッズ種類</td>
        <td class="goods1-name"></td>
      </tr>
      <tr class="no-free">
        <td>配送希望</td>
        <td class="deliv-method1-name"></td>
      </tr>
      <tr class="no-free">
        <td>配送方法</td>
        <td class="deliv-flag1-name"></td>
      </tr>
      <tr class="no-free">
        <td>受渡状態</td>
        <td class="deliv-status1-name"></td>
      </tr>
      <tr class="no-free">
        <td>発送伝票番号</td>
        <td class="delivCode1"></td>
      </tr>
      <tr class="no-free">
        <td>出荷日</td>
        <td class="ship-date-1"></td>
      </tr>
    </table>
    <div class="content text-center" id="group-edit-app">
      <div class="button border-top">
        <a class="btn-custom btn-custom-icon btn-custom-style-2" href="/mix/FmaMemberAdmission?action=init&acu=false">申込情報の修正はこちら</a>
      </div>
      <b><p class="mb-4">※上記記載以外の会員情報を更新する場合は、下記の基本情報から手続きを行ってください。</p></b>
    </div>
</div>
<div class="table-information">
  <h2>基本情報</h2>
    <table class="table">
      <tr>
        <td>マリーンズID</td>
        <td class="amc-no"></td>
      </tr>
      <tr>
        <td>フリガナ</td>
        <td class="name-kana"></td>
      </tr>
      <tr>
        <td>お名前</td>
        <td class="name"></td>
      </tr>
      <tr>
        <td>性別</td>
        <td class="sex"></td>
      </tr>
      <tr>
        <td>生年月日</td>
        <td class="birth-day"></td>
      </tr>
      <tr>
        <td>電話番号</td>
        <td class="tel"></td>
      </tr>
      <tr>
        <td>郵便番号</td>
        <td class="zip-code"></td>
      </tr>
      <tr>
        <td>自宅住所</td>
        <td class="address"></td>
      </tr>
      <tr>
        <td>送付先会員番号</td>
        <td class="deliv-fan-no"></td>
      </tr>
      <tr>
        <td>送付先お名前</td>
        <td class="deliv-name"></td>
      </tr>
      <tr>
        <td>送付先電話番号</td>
        <td class="deliv-tel"></td>
      </tr>
      <tr>
        <td>メールアドレス</td>
        <td class="email-info"></td>
      </tr>
      <tr>
        <td>パスワード</td>
        <td class="fan-pass"></td>
      </tr>
    </table>
  <div class="content">
    <div class="pp">
      <div class="email">
        <i class="fa-regular fa-envelope"></i>
        <span>マリーンズメルマガの配信</span>
      </div>
      <a href="#" class="mailMagazine"></a>
    </div>
    <div class="button">
      <a class="btn-custom btn-custom-icon" href="{{ route_path('mypage.profile.customer.edit') }}">基本情報の更新はこちら</a>
    </div>
  </div>
</div>
<div class="table-information" style="display: none;">
  <h2>SNSアカウント連携</h2>
  <div class="content">
    <div class="twiter-h">
      <span><i class="fa-brands fa-twitter"></i> twitter連携</span>
      <span class="note">未連携</span>
    </div>
    <div class="button">
      <a class="btn-custom btn-custom-icon twitter" href="#"><i class="fa-brands fa-twitter"></i> twitter連携はこちら</a>
    </div>
  </div>
</div>
<div class="table-information year2-table">
  <h2><span class="year2"></span>年度申込情報</h2>
    <table class="table">
      <tr>
        <td>会員種別</td>
        <td class="fan-type2-name"></td>
      </tr>
      <tr class="no-free2">
        <td>特典グッズ種類</td>
        <td class="goods2-name"></td>
      </tr>
      <tr class="no-free2">
        <td>配送希望</td>
        <td class="deliv-method2-name"></td>
      </tr>
      <tr class="no-free2">
        <td>配送方法</td>
        <td class="deliv-flag2-name"></td>
      </tr>
      <tr class="no-free2">
        <td>受渡状態</td>
        <td class="deliv-status2-name"></td>
      </tr>
      <tr class="no-free2">
        <td>発送伝票番号</td>
        <td class="delivCode2"></td>
      </tr>
      <tr class="no-free2">
        <td>出荷日</td>
        <td class="ship-date-2"></td>
      </tr>
    </table>
</div>
<script type="text/javascript" src="/mypage/js/frontend/inner/site-information-page.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
