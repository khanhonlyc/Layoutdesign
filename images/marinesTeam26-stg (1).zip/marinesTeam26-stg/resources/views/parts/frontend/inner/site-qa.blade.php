@extends('parts.frontend.site-qa')
@section('text_date_form_35')
<div class="content_qa">
  <div class="title">
    <h3 class="vote-plan-title"></h3>
    <span class="vote-time"></span>
  </div>
  <div class="content js-qa">
    <form action="{{ route('mypage.vote.confirm', $id) }}" id="question-list" method="POST">
      @csrf
    </form>
    <button class="btn btn-custom" type="button" id="btn-reset">リセット</button>
    <button class="btn-custom btn-custom-icon hover-den" type="button" id="btn-confirm">回答の確認はこちら</button>
  </div>
</div>
<a class="btn-custom btn-back" href="javascript: history.go(-1)" id="btn-back">もどる</a>
<script type="text/javascript">
  var voteId = '{{ $id }}';
</script>
<script type="text/javascript" src="/mypage/js/frontend/inner/site-qa.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
