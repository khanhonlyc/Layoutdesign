@extends('parts.frontend.site-marrines')
@section('title_image_date_15')
<div class="title">
  <img src="/mypage/images/m1.png" alt="">
</div>
<div class="slick-slider-custom" id="live-html">

</div>
@endsection
