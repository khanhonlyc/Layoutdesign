@extends('parts.frontend.site-banner-2')
@section('title_image_10')
<div class="container">
  <h2 class="heading">MY FAVORITE PLAYER</h2>
</div>
<div class="slick-banner-none">
  <div class="items">
    <img class="w-100 d-block no-favorite" src="/mypage/images/bg-favorite-default.jpg" alt="">
    <img class="w-100 d-block has-favorite" id="bg-favorite" src="" alt="" style="display:none !important;">
    <div class="text-content has-favorite" style="display:none;">
      <div class="row m-0 align-items-center">
        <div class="col-9 p-0">
          <div class="title-nh-45">
            <div class="flex-nh-title">
              <span  class="player-uniform-no"></span>
              <span  class="player-name-roma"></span>
            </div>
            <span  class="player-name"></span>
          </div>
          <span class="text1" id="index-1"> </span>
          <span class="text1" id="index-2"> </span>
          <span class="text1" id="index-3"> </span>
          <span class="date-cn" id="date-update"></span>
        </div>
      </div>
    </div>
    <a class="icon" href="{{ route_path('mypage.profile.favorite.index') }}"><img src="/mypage/images/st.png" alt=""></a>
  </div>
</div>
<a class="btn-custom btn-favorite btn-red no-favorite" href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手設定をしよう！</a>
@endsection
