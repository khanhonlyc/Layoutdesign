@extends('parts.frontend.site-top')
@section('title_1')
<div class="title d-flex align-items-center" style=" font-weight: bold;"><span class="fan-name"></span>さま</div>
@endsection
@section('title_color_1')
<a class="btn-custom fan-type-name fan-type-css" href="#"></a>
@endsection
