@extends('parts.frontend.site-mtp-top')
@section('text_35')
<p>保有Mポイント <span>99,599</span> <small>Mpt</small></p>
@endsection
