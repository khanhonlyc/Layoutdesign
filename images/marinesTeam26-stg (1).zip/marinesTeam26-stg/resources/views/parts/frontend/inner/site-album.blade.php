@extends('parts.frontend.site-album')
@section('image_5')
	@php
		date_default_timezone_set ('Asia/Tokyo');
		$time1 = new DateTime('2023-10-30 13:00:00');
		$nowDateTime = new DateTime();
	@endphp
		@if ( $nowDateTime->format('Y-m-d H:i:s') >= $time1->format('Y-m-d H:i:s') )
  <div class="items banner-fantype fan-type-code-02 fan-type-code-03 fan-type-code-04 fan-type-code-07 fan-type-code-14 items-banner top-banner" style="display: none;">
	<form action="https://l-tike.com/st1/marines_movie23_fc" method="POST">
	<input type="image" class="w-100 d-block" src="/mypage/images/banner1.jpg" alt="送信する">
	<input type="hidden" name="CERK" value="ae72cbdc476832330ff15d7602cbd859" />
	</form>
  </div>
  <div class="items banner-fantype fan-type-code-02 fan-type-code-03 fan-type-code-04 fan-type-code-07 fan-type-code-14 items-banner top-banner" style="display: none;">
	<form action="https://l-tike.com/st1/marines_movieg23_fc" method="POST">
	<input type="image" class="w-100 d-block" src="/mypage/images/banner2.jpg" alt="送信する">
	<input type="hidden" name="CERK" value="382c913425fece81b731afae2d9473a8" />
	</form>
  </div>
  		@endif
@foreach ($listBanner as $item)
    @if($item->banner_type_code == 2)
    @php
        $class = "";
    @endphp
    @foreach ($item->fantypenameen as $fantype)
    @php
        $class .= " fan-type-code-".$fantype->fantypecode;
    @endphp
    @endforeach
    <div class="items banner-fantype{{ $class }} items-banner" style="display: none;">
      <a href="{{ $item->url }}" target="{{ $item->target }}">
        <img class="w-100 d-block" src="{{ asset($item->image_url) }}" alt="{{ $item->title }}">
      </a>
    </div>
    @endif
  @endforeach
@endsection
