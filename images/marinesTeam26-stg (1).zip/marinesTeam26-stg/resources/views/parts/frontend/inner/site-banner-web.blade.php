@extends('parts.frontend.site-banner-web')
@switch($slug)
  @case("page15-sp")
    @php $title1 = "WEB引換券コード"; @endphp
    @break
    @case("page16-sp")
    @php $title1 = "ダイレクトメッセージ・事務局からのお知らせ"; @endphp
    @break
    @case("page18-sp")
    @php $title1 = "ポイント交換"; @endphp
    @break
    @case("page19-sp")
    @php $title1 = "ポイント交換"; @endphp
    @break
    @case("page20-sp")
    @php $title1 = "デジタル会員証"; @endphp
    @break
    @case("page21-sp")
    @php $title1 = "デジタル会員証"; @endphp
    @break
    @case("page22-sp")
    @php $title1 = "デジタル会員証"; @endphp
    @break
    @case("page23-sp")
    @php $title1 = "デジタル会員証"; @endphp
    @break
    @case("page24-sp")
    @php $title1 = "デジタル会員証"; @endphp
    @break
    @case("page25-sp")
    @php $title1 = "デジタル会員証"; @endphp
    @break
    @case("page27-sp")
    @php $title1 = "会員情報｜基本情報"; @endphp
    @break
    @case("page28-sp")
    @php $title1 = "会員情報｜基本情報"; @endphp
    @break
    @case("page29-sp")
    @php $title1 = "会員情報｜基本情報"; @endphp
    @break
    @case("page30-sp")
    @php $title1 = "会員情報｜基本情報"; @endphp
    @break
    @case("page31-sp")
    @php $title1 = "会員情報｜お気に入り選手登録"; @endphp
    @break
    @case("page32-sp")
    @php $title1 = "会員情報｜お気に入り選手登録"; @endphp
    @break
    @case("page33-sp")
    @php $title1 = "会員情報｜お気に入り選手登録"; @endphp
    @break
    @case("page34-sp")
    @php $title1 = "会員情報｜マイユニホーム"; @endphp
    @break
    @case("page35-sp")
    @php $title1 = "会員情報｜マイユニホーム"; @endphp
    @break
    @case("page36-sp")
    @php $title1 = "会員情報｜マイユニホーム"; @endphp
    @break
    @case("page37-sp")
    @php $title1 = "会員履歴｜ Mポイント実績"; @endphp
    @break
    @case("page38-sp")
    @php $title1 = "会員履歴｜ Mポイント実績"; @endphp
    @break
    @case("page42-sp")
    @php $title1 = "会員履歴｜来場履歴"; @endphp
    @break
    @case("page43-sp")
    @php $title1 = "会員履歴｜来場履歴"; @endphp
    @break
    @case("page44-sp")
    @php $title1 = "会員履歴｜来場履歴"; @endphp
    @break
    @case("page45-sp")
    @php $title1 = "会員履歴｜チケット購入履歴"; @endphp
    @break
    @case("page46-sp")
    @php $title1 = "会員履歴｜来場特典配布"; @endphp
    @break
    @case("page47-sp")
    @php $title1 = "会員履歴｜来場特典配布"; @endphp
    @break
    @case("page48-sp")
    @php $title1 = "イベント情報｜申込受付"; @endphp
    @break
    @case("page49-sp")
    @php $title1 = "イベント情報｜" . $typeEvent; @endphp
    @break
    @case("page50-sp")
    @php $title1 = "イベント情報｜申込受付"; @endphp
    @break
    @case("page51-sp")
    @php $title1 = "イベント情報｜申込受付"; @endphp
    @break
    @case("page52-sp")
    @php $title1 = "イベント情報｜申込受付"; @endphp
    @break
    @case("page53-sp")
    @php $title1 = "イベント情報｜申込受付"; @endphp
    @break
    @case("page54-sp")
    @php $title1 = "イベント情報｜申込済み"; @endphp
    @break
    @case("page55-sp")
    @php $title1 = "イベント情報｜申込済み"; @endphp
    @break
    @case("page56-sp")
    @php $title1 = "イベント情報｜申込締切"; @endphp
    @break
    @case("page57-sp")
    @php $title1 = "イベント情報｜申込締切"; @endphp
    @break
    @case("page58-sp")
    @php $title1 = "イベント情報｜開催済み"; @endphp
    @break
    @case("page59-sp")
    @php $title1 = "イベント情報｜開催済み"; @endphp
    @break
    @case("page60-sp")
    @php $title1 = "アンケート"; @endphp
    @break
    @case("page61-sp")
    @php $title1 = "アンケート"; @endphp
    @break
    @case("page62-sp")
    @php $title1 = "アンケート"; @endphp
    @break
    @case("page63-sp")
    @php $title1 = "アンケート"; @endphp
    @break
    @case("page64-sp")
    @php $title1 = "ガイドブック"; @endphp
    @break
    @case("page66-sp")
    @php $title1 = "Mポイント｜Mポイント受取（補助券）"; @endphp
    @break
    @case("page67-sp")
    @php $title1 = "Mポイント｜Mポイント受取（補助券）"; @endphp
    @break
    @case("page68-sp")
    @php $title1 = "ミッション"; @endphp
    @break
    @case("page69-sp")
    @php $title1 = "ミッション"; @endphp
    @break
 @default
    @php $title1 = ""; @endphp
    @break
@endswitch
@section('text_23')
<div class="text-center">
  <h2>{{$title1}}</h2>
</div>
@endsection
