@extends('parts.frontend.site-title-points')
@section('text_25')
<div class="text-center">
  <h2>保有Mポイント <span>99,999</span> <small>Mpt</small></h2>
</div>
@endsection
