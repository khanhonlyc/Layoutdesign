@extends('parts.frontend.site-select-items')
@section('form_text_img_26')
<p class="note">下記の中から交換する商品を選択してください。</p>
<div class="row row-custom">
  <div class="col-6 col-custom">
    <div class="items-select">
      <div class="img">
        <img src="/mypage/images/ao.png" alt="">
        <span>800 <small>Mpt</small></span>
      </div>
      <h3>テスト商品</h3>
      <p>商品説明テキスト商品説明テキスト</p>
      <div class="select">
        <span>交換個数</span>
        <select name="" id="">
          <option>0</option>
          <option>1</option>
          <option>2</option>
          <option>3</option>
          <option>4</option>
          <option>5</option>
          <option>6</option>
          <option>7</option>
          <option>8</option>
          <option>9</option>
          <option>10</option>
        </select>
      </div>
    </div>
  </div>
  <div class="col-6 col-custom">
    <div class="items-select">
      <div class="img">
        <img src="/mypage/images/ao.png" alt="">
        <span>800 <small>Mpt</small></span>
      </div>
      <h3>テスト商品</h3>
      <p>商品説明テキスト商品説明テキスト</p>
      <div class="select">
        <span>交換個数</span>
        <select name="" id="">
          <option>0</option>
          <option>1</option>
          <option>2</option>
          <option>3</option>
          <option>4</option>
          <option>5</option>
          <option>6</option>
          <option>7</option>
          <option>8</option>
          <option>9</option>
          <option>10</option>
        </select>
      </div>
    </div>
  </div>
  <div class="col-6 col-custom">
    <div class="items-select">
      <div class="img">
        <img src="/mypage/images/ao.png" alt="">
        <span>800 <small>Mpt</small></span>
      </div>
      <h3>テスト商品</h3>
      <p>商品説明テキスト商品説明テキスト</p>
      <div class="select">
        <span>交換個数</span>
        <select name="" id="">
          <option>0</option>
          <option>1</option>
          <option>2</option>
          <option>3</option>
          <option>4</option>
          <option>5</option>
          <option>6</option>
          <option>7</option>
          <option>8</option>
          <option>9</option>
          <option>10</option>
        </select>
      </div>
    </div>
  </div>
  <div class="col-6 col-custom">
    <div class="items-select">
      <div class="img">
        <img src="/mypage/images/ao.png" alt="">
        <span>800 <small>Mpt</small></span>
      </div>
      <h3>テスト商品</h3>
      <p>商品説明テキスト商品説明テキスト</p>
      <div class="select">
        <span>交換個数</span>
        <select name="" id="">
          <option>0</option>
          <option>1</option>
          <option>2</option>
          <option>3</option>
          <option>4</option>
          <option>5</option>
          <option>6</option>
          <option>7</option>
          <option>8</option>
          <option>9</option>
          <option>10</option>
        </select>
      </div>
    </div>
  </div>
</div>
<div class="item-checkbox">
  <h3>配送料の支払い方法の選択</h3>
  <div class="content">
    <label>
      <input type="checkbox">
      <span>着払いのみ</span>
    </label>
    <p>※マイページからのお申込みは着払いのみの受付となります。<br> アイテムのサイズや種類、数量、お届け先の住所により配送料は異なります。配送料の目安はこちらをご <br>覧ください</p>
  </div>
</div>
<button class="btn-custom btn-custom-icon" type="submit">確認はこちら</button>
<a class="reset" href="javascript:void(0)"><svg xmlns="http://www.w3.org/2000/svg" id="Component_36_2"
    data-name="Component 36 – 2" width="14.222" height="16" viewBox="0 0 14.222 16">
    <path id="Subtraction_1" data-name="Subtraction 1"
      d="M7.111,14.223A7.111,7.111,0,1,1,7.111,0c.2,0,.4.008.592.024V2.408a4.738,4.738,0,1,0,4.111,4.11H14.2c.017.2.024.4.024.593A7.119,7.119,0,0,1,7.111,14.223Z"
      transform="translate(0 1.777)" />
    <path id="Polygon_1" data-name="Polygon 1" d="M3.555,0,7.111,5.926H0Z" transform="translate(12.444) rotate(90)" />
  </svg> リセット</a>
@endsection
