@extends('parts.frontend.site-date')
@section('title_2')
  <span class="text"><span id="time-now-js"></span> 時点</span>
@endsection
@section('title_color_2')
  <a class="btn-custom fc-rank-color" href="#"><span class="fc-rank-name"></span>ステージ <span><span class="sum-point-m"></span> <small>Mpt</small></span></a>
@endsection
