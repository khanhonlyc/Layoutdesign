@extends('parts.frontend.site-logo-pn')
@section('image_17')
<div class="slick-album slick-slider-custom">
  @foreach ($listBanner as $item)
    @if($item->banner_type_code == 5)
    @php
        $class = "";
    @endphp
    @foreach ($item->fantypenameen as $fantype)
    @php
        $class .= " fan-type-code-".$fantype->fantypecode;
    @endphp
    @endforeach
    <div class="items banner-fantype{{ $class }} items-banner footer-banner" style="display: none;">
      <a href="{{ $item->url }}" target="{{ $item->target }}">
        <img class="w-100 d-block" src="{{ asset($item->image_url) }}" alt="{{ $item->title }}">
      </a>
    </div>
    @endif
  @endforeach
</div>
@endsection
