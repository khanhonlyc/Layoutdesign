@extends('parts.frontend.site-tab')
@section('text_29')
<ul>
  <li class="{{ (request()->is('mypage/profile/customer*')) ? 'active' : '' }}"><a href="{{ route_path('mypage.profile.customer.index') }}">基本情報</a></li>
  <li class="{{ (request()->is('mypage/profile/favorite*')) ? 'active' : '' }}"><a href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手登録</a></li>
  <li class="{{ (request()->is('mypage/profile/uniform*')) ? 'active' : '' }}"><a href="{{ route_path('mypage.profile.uniform.index') }}">マイユニホーム</a></li>
</ul>
@endsection
