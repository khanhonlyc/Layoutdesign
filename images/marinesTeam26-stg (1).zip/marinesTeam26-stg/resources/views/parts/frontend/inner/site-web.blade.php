@extends('parts.frontend.site-web')
@section('title_content_image_7')

@empty($tickets)
@else
<div class="slick-web">
  <div class="items">
    <div class="content">
      <a target="_blank" href="https://www.marines.co.jp/game/schedule/index.html">
        <img class="img-custom"  src="/mypage/images/01.svg" alt="">
      </a>
    </div>
  </div>
  @foreach ($tickets as $ticket)
  <div class="items">
    <div class="content">
      <div class="logo">
        <img src="/mypage/images/ticket-logo/{{ $ticket['visitorTeamCode'] ?? 2008001 }}_m.png" alt="">
      </div>
      <span class="title">{{ SHORT_TEAM_NAME[$ticket['visitorTeamCode']] ?? $ticket['visitorTeamName'] }}</span>
      <div class="number font-big">{{ \Carbon\Carbon::parse($ticket['gameDate'])->format('m/d') }}<span>［{{ $weekMap[\Carbon\Carbon::parse($ticket['gameDate'])->dayOfWeek] }}］</span></div>
      <div class="tiems font-big">{{ \Carbon\Carbon::parse($ticket['gameTime'])->format('H:i') }}</div>
      <p>{{ $ticket['gameStadiumName'] }}</p>
      <a class="btn-buy" target="_blank" rel="noopener noreferrer" href="/mix/FmaMemberOutSiteLink.do?code=0&gamedate={{ \Carbon\Carbon::parse($ticket['gameDate'])->format('Ymd') }}">BUY TICKET</a>
    </div>
  </div>
  @endforeach
  <div class="items">
    <div class="content">
      <a target="_blank" href="https://www.marines.co.jp/event/">
        <img class="img-custom"  src="/mypage/images/02.svg" alt="">
      </a>
    </div>
  </div>
</div>
@endempty
<div class="container">
  <a class="btn-custom" href="{{ route_path('mypage.coupon') }}">WEB引換コードの確認はこちら</a>
</div>
@endsection
