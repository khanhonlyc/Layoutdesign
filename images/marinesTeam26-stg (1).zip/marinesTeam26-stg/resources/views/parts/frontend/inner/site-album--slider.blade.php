@extends('parts.frontend.site-album--slider')
@section('image_13')
  @foreach ($listBanner as $item)
    @if($item->banner_type_code == 4)
    @php
        $class = "";
    @endphp
    @foreach ($item->fantypenameen as $fantype)
    @php
        $class .= " fan-type-code-".$fantype->fantypecode;
    @endphp
    @endforeach
    <div class="items banner-fantype{{ $class }} items-banner content-banner" style="display: none;">
      <a href="{{ $item->url }}" target="{{ $item->target }}">
        <img class="w-100 d-block" src="{{ asset($item->image_url) }}" alt="{{ $item->title }}">
      </a>
    </div>
    @endif
  @endforeach
@endsection
