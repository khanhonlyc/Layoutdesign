@extends('parts.frontend.site-select-items--payment')
@section('title_price_image_27')
<p class="note">下記の中から交換する商品を選択してください。<br> <span style="color:#D12B63">※交換後のキャンセルはできません。</span></p>
<div class="list-cart">
  <div class="items-cart">
    <div class="row row-custom">
      <div class="col-7 col-custom">
        <div class="images">
          <div class="img">
            <img src="/mypage/images/ao.png" alt="">
          </div>
          <div class="title-c">
            <h3>テスト商品</h3>
            <p class="m-0">800Mpt</p>
          </div>
        </div>
      </div>
      <div class="col-5 col-custom">
        <div class="total">
          <span>x1</span>
          <p class="m-0">800 Mpt</p>
        </div>
      </div>
    </div>
  </div>
  <div class="items-cart">
    <div class="row row-custom">
      <div class="col-7 col-custom">
        <div class="images">
          <div class="img">
            <img src="/mypage/images/ao.png" alt="">
          </div>
          <div class="title-c">
            <h3>テスト商品</h3>
            <p class="m-0">800Mpt</p>
          </div>
        </div>
      </div>
      <div class="col-5 col-custom">
        <div class="total">
          <span>x1</span>
          <p class="m-0">1,600 Mpt</p>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="total-cart">
  <p class="total-1">合計 <span>2,400Mpt</span></p>
  <p class="total-2">交換確定後のMポイント <span>97,599<small>Mpt</small></span></p>
</div>
<div class="payment">配送料の支払い方法 【着払い】</div>
<button class="btn-custom btn-custom-icon" type="submit">この内容で交換する</button>
<a class="reset" href="#"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 384 512">
    <path
      d="M41.4 233.4c-12.5 12.5-12.5 32.8 0 45.3l192 192c12.5 12.5 32.8 12.5 45.3 0s12.5-32.8 0-45.3L109.3 256 278.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-192 192z" />
  </svg> もどる</a>
@endsection
