@extends('parts.frontend.site-infor-event')
@section('text_date_33')
<ul class="list-event">

</ul>
<script type="text/javascript">
  var isApplied = "{{request()->is('mypage/event/applied') ? 1 : 0}}";
  var isClose = "{{request()->is('mypage/event/close') ? 1 : 0}}";
  var isPerformed = "{{request()->is('mypage/event/performed') ? 1 : 0}}";
</script>
<script type="text/javascript" src="/mypage/js/frontend/inner/site-infor-event.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
