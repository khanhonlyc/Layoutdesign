@extends('parts.frontend.pp-ads')
@section('img_text_21')
  <div class="js-bg2"></div>
  <div class="content">
    @foreach ($listBanner as $item)
      @if($item->banner_type_code == 1)
        @php
            $class = "";
        @endphp
        @foreach ($item->fantypenameen as $fantype)
        @php
            $class .= " fan-type-code-".$fantype->fantypecode;
        @endphp
        @endforeach
        <a href="{{ $item->url }}" target="{{ $item->target }}" class=" banner-fantype{{ $class }} banner-modal" style="display: none;"><img src="{{ asset($item->image_url) }}" alt="{{ $item->title }}"></a>
      @endif
    @endforeach
    <div class="js-close2"><i class="fa-regular fa-circle-xmark"></i> <span>閉じる</span></div>
  </div>
@endsection
