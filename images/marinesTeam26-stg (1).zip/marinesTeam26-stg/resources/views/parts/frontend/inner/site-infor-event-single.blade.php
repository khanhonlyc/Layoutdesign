@extends('parts.frontend.site-infor-event-single')
@section('text_date_34')
@if (isset($typeEvent) && $typeEvent != '開催済み')
@if (isset($typeEvent) && $typeEvent == '申込受付')
<div class="title">
    <p>以下の項目を確認して申し込むボタンを押してください。</p>
</div>
@else
<div class="title">
    <p>当選の連絡はTEAM26マイページ内機能、ダイレクトメッセージにてお知らせいたします。</p>
</div>
@endif
@endif
<div class="infor-event">
  <h3 class="heading event-title"></h3>
  <h4 class="note" style="display: none;"></h4>
  <div class="single-event">
    <div class="items">
      <label>受付期間</label>
      <p><strong><span class="start-time"></span> - <span class="end-time"></span></strong></p>
    </div>
    <div class="items">
      <label>開催日時</label>
      <p><strong class="event-time"></strong></p>
    </div>
    <div class="items">
      <label>開催場所</label>
      <p><strong class="event-place"></strong></p>
    </div>
    <div class="items">
      <label>内容</label>
      <p class="event-detail"></p>
    </div>
    <div class="items display-point d-none">
      <label>使用ポイント</label>
      <p class="event-point"></p>
    </div>

  </div>
  <a class="btn-custom btn-custom-icon btn-confirm" href="{{ route_path('mypage.event.confirm', $id) }}">イベントに申し込む</a>
</div>
@switch($typeEvent)
    @case('申込済み')
        <a class="btn-custom btn-back" href="{{ route_path('mypage.event.applied') }}">もどる</a>
        @break

    @case('申込締切')
        <a class="btn-custom btn-back" href="{{ route_path('mypage.event.close') }}">もどる</a>
        @break

    @case('開催済み')
        <a class="btn-custom btn-back" href="{{ route_path('mypage.event.performed') }}">もどる</a>
        @break

    @default
        <a class="btn-custom btn-back" href="{{ route_path('mypage.event.index') }}">もどる</a>
@endswitch
<script type="text/javascript">
  var eventId = '{{ $id }}';
  var eventType = "{{ $typeEvent }}"
</script>
<script type="text/javascript" src="/mypage/js/frontend/inner/site-infor-event-single.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
