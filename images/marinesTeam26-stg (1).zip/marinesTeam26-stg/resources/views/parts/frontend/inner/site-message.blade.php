@extends('parts.frontend.site-message')
@section('title_date_16')
<div class="code-container container-personal-mess" style="display:none;">
  <div class="items-code">
      <h3 class="title">ダイレクトメッセージ <span style="background-color:#D12B63" class="personal-mess-number"></span></h3>
      <div class="content">
          <ul class="personal-message-list">
          </ul>
      </div>
  </div>
</div>
<div class="code-use container-mess" style="display:none;">
  <div class="items-code">
      <h3 class="title">事務局からのお知らせ <span style="background-color:#333333" class="mess-number"></span></h3>
      <div class="content sp-16">
          <ul class="message-list">

          </ul>
      </div>
  </div>
</div>
@endsection
