@extends('parts.frontend.site-good')
@section('title_image_12')
@php
$code = 13;
@endphp
<h2 class="heading">GOODS</h2>
<div class="slick-goods">
  @foreach ($listBanner as $item)
    @if($item->banner_type_code == 3)
    @php
        $class = "";
    @endphp
    @foreach ($item->fantypenameen as $fantype)
    @php
        $class .= " fan-type-code-".$fantype->fantypecode;
    @endphp
    @endforeach
    <div class="items banner-fantype{{ $class }} items-banner goods-banner" style="display: none;">
      <a href="{{ $item->url }}" target="{{ $item->target }}">
        <img class="w-100 d-block" src="{{ asset($item->image_url) }}" alt="{{ $item->title }}">
      </a>
    </div>
    @endif
  @endforeach
</div>
<a class="btn-custom" href="/mix/FmaMemberOutSiteLink.do?code={{ $code }}">オンラインストアはこちら</a>
@endsection
