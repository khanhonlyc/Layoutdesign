<section class="site-web slick-slider-custom">
  @yield("title_content_image_7")
</section>
