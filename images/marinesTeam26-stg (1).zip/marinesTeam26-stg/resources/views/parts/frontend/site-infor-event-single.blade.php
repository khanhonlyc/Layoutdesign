<section class="site-infor-event site-infor-event-single">
  <div class="container">
    @yield("text_date_34")
  </div>
</section>
