<section class="site-select-items site-payment pd-main">
  <div class="container">
    @yield("title_price_image_27")
  </div>
</section>