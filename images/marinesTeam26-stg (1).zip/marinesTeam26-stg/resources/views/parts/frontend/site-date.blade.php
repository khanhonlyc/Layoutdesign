<section class="site-date">
  <div class="container">
    @yield("title_2")
    @yield("title_color_2")
  </div>
</section>
