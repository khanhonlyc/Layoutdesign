<section class="site-history-member pd-main">
  <div class="container">
    @yield("text_date_32")
  </div>
</section>
