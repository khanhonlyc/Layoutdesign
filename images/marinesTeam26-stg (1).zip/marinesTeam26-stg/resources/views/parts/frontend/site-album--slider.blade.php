<section class="site-album site-album-2-mb nam slick-slider-custom">
  <div class="slick-album">
    @yield("image_13")
  </div>
</section>
