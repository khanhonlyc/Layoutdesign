<div class="col-md-3nh">
  <section class="site-banner">
    <div class="items">
      <div class="content">
        <h3 class="fan-name"></h3>
        <p class="br">現在のMポイント ＞ <a class="text-white" href="{{ route_path('mypage.history.point') }}">履歴</a></p>
        <p class="mpt"><span class="mpt-font-bold sum-point-m"></span> <span>Mpt</span></p>
        <p class="check-rank"><span class="next-fc-rank-name"></span>ステージまであと <span class="necessary-point"></span>Mpt</p>
        <p class="br">来場回数 ＞ <a class="text-white" href="{{ route_path('mypage.history.visit') }}">履歴</a></p>
        <div class="img">
          <p><span class="present-comming"></span> <span>回</span></p>
          <div class="i present-comming-img">
          </div>
        </div>
      </div>
      <div class="images" style="background-image: url('/mypage/images/sp2.png');">
        <div class="block-uniform">
          <div id="js_Name" class="txt-name"></div>
          <div id="js_Number" class="txt-number"></div>
        </div>
        <a class="link-st" href="{{ route_path('mypage.profile.uniform.index') }}"><img src="/mypage/images/st.png" alt=""></a>
      </div>
    </div>
  </section>
  <div class="header__menu_destop none-sidebar-right" style="margin-top: 30px;">
  <div class="top p-0">
    <div class="item1 member-bg" style="background-image:url('/mypage/images/bg-menu.png'); background-position: top; overflow: hidden;">
      <span class="year fan-type-css rank-name-eng"></span>
      <div class="content">
        <p class="t fan-type-name"></p>
        <div class="row align-items-center">
          <div class="col-md-5">
            <div class="img" id="qr-code-menu-1">
            </div>
          </div>
          <div class="col-md-7">
            <p class="id">マリーンズID<br><span class="amc-no"></span></p>
          </div>
        </div>
      </div>
    </div>
    <div class="item2">
      <h3>現在のステージ</h3>
      <div class="content">
        <div class="flex-custom">
          <div class="circle">
            <h4 class="fc-rank-name"></h4>
            <span>ステージ</span>
          </div>
          <div class="text">
            <div class="m4"><span class="next-fc-rank-name next-fc-rank-color"></span>ステージ</div>
            <div class="m4_2">まであと</div>
            <div class="mpt"><span class="sum-point-m"></span> <span>Mpt</span></div>
          </div>
        </div>
        <p>ステージランクの判定は翌日以降になる場合があります。<br><a class="text-dark" href="https://www.marines.co.jp/fanclub/point/stage.html?_gl=1*go8blv*_ga*OTA3NTE4NDQxLjE2NjI1Mjg3NTA.*_ga_VDEHFZZJD4*MTY3Mzg1NzYwOS42Ny4xLjE2NzM4NTc3MDcuMzIuMC4w" target="_blank">詳しくはこちら</a>をご覧ください</p>
      </div>
    </div>
  </div>
  </div>
  <section class="site-code" style="padding:30px 0px">
    <div class="code-container box-person-mess-js" style="display:none;">
      <div class="items-code">
        <h3 class="title text-left" style="padding-left: 10px;">ダイレクトメッセージ <span style="background-color:#D12B63" class="personal-mess-number"></span></h3>
        <div class="content">
          <ul class="personal-message-list">
          </ul>
        </div>
      </div>
    </div>
    <div class="code-use box-mess-js" style="display:none;">
      <div class="items-code">
        <h3 class="title text-left" style="padding-left: 10px;">事務局からのお知らせ <span style="background-color:#333333" class="mess-number"></span></h3>
        <div class="content">
          <ul class="message-list">
          </ul>
        </div>
      </div>
    </div>
  </section>
  <!-- <section class="sidebar-img">
  @foreach ($listBanner as $item)
    @if($item->banner_type_code == 5)
    <div class="items">
      <img class="w-100 d-block" src="{{ $item->image_url }}" alt="{{ $item->title }}">
    </div>
    @endif
  @endforeach
  </section> -->
</div>
