<div class="col-md-3nh none-table">
  <div class="header__menu_destop">
    <div class="top">
      <div class="item1 member-bg" style="background-image:url('/mypage/images/bg-menu.png'); background-position: top; overflow: hidden;">
        <span class="year fan-type-css rank-name-eng"></span>
        <div class="content">
          <p class="t fan-type-name"></p>
          <div class="row align-items-center">
            <div class="col-md-5">
              <div class="img" id="qr-code-menu">
              </div>
            </div>
            <div class="col-md-7">
              <p class="id">マリーンズID<br><span class="amc-no"></span></p>
            </div>
          </div>
        </div>
      </div>
      <div class="item2">
        <h3>現在のステージ</h3>
        <div class="content">
          <div class="flex-custom" style="display: inline-flex;">
            <div class="circle" style="border:none;">
              <svg viewBox="0 0 36 36" class="circular-chart green" style="width:90px;height:90px;margin:0;">
                <path fill="red" class="circle-bg" d="M18 2.0845
                a 15.9155 15.9155 0 0 1 0 31.831
                a 15.9155 15.9155 0 0 1 0 -31.831" />
                <path class="circle circle-rank-color" d="M18 2.0845
                a 15.9155 15.9155 0 0 1 0 31.831
                a 15.9155 15.9155 0 0 1 0 -31.831" />
                <text x="18" y="20.35" class="percentage"></text>
              </svg>
              <div class="hi" style="position:absolute;">
                <h4 class="fc-rank-name"></h4>
                <span>ステージ</span>
              </div>
            </div>
            <div class="text check-rank">
              <div class="m4"><span class="next-fc-rank-name next-fc-rank-color"></span>ステージ</div>
              <div class="m4_2">まであと</div>
              <div class="mpt"><span class="necessary-point"></span> <span>Mpt</span></div>
            </div>
          </div>
          <p>ステージランクの判定は翌日以降になる場合があります。<br><a class="text-dark" href="https://www.marines.co.jp/fanclub/point/stage.html?_gl=1*go8blv*_ga*OTA3NTE4NDQxLjE2NjI1Mjg3NTA.*_ga_VDEHFZZJD4*MTY3Mzg1NzYwOS42Ny4xLjE2NzM4NTc3MDcuMzIuMC4w" target="_blank">詳しくはこちら</a>をご覧ください</p>
        </div>
      </div>
    </div>
    <div class="menu js-menu-pc">
      <ul>
        <li>
          <a href="{{ route_path('mypage.mission.monthly') }}">ミッション</a>
        </li>
        <li>
          <a href="{{ route_path('mypage.movie.index') }}">MARINES PLUS</a>
        </li>
      </ul>
      <ul>
        <li>
          <a href="{{ route_path('mypage.marines') }}">デジタル会員証</a>
        </li>
        <li>
          <a href="{{ route_path('mypage.coupon') }}">WEB引換コード</a>
        </li>
        <li><a href="/mix/FmaMemberPointExchange">Mポイント交換</a></li>
        <li><a href="/mix/FmaMemberPointTicketReg">Mポイント受取（補助券）</a></li>
      </ul>
      <ul>
        <li class="childer">
          <a class="js-dropdown-menu" href="javascript:void(0)">会員情報</a>
          <ul class="sub-menu-pc">
            <li><a href="{{ route_path('mypage.profile.customer.index') }}">基本情報</a></li>
            <li><a href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手登録</a></li>
            <li><a href="{{ route_path('mypage.profile.uniform.index') }}">マイユニホーム</a></li>
          </ul>
        </li>
        <li class="childer">
          <a class="js-dropdown-menu" href="javascript:void(0)">会員履歴</a>
          <ul class="sub-menu-pc">
            <li><a href="{{ route_path('mypage.history.point') }}">Mポイント実績</a></li>
            <li><a href="{{ route_path('mypage.history.visit') }}">来場履歴</a></li>
            <li><a href="{{ route_path('mypage.history.ticket') }}">チケット購入履歴</a></li>
            <li><a href="{{ route_path('mypage.history.privilege') }}">来場特典配布</a></li>
          </ul>
        </li>
        <li><a href="{{ route_path('mypage.event.index') }}">イベント応募</a></li>
      </ul>
      <ul>
        <li><a href="/mix/CrmMemberVoteList">アンケート</a></li>
        <li><a href="{{ route_path('mypage.guidebook') }}">ガイドブック</a></li>
      </ul>
      <ul>
        <li><a href="/mix/FmaMemberContinueFanType?action=info">{{ App\Models\Membership::first()->membership_year }}年度有料継続入会<br>(自動継続対象外の方)</a></li>
        <li><a href="/mix/FmaMemberInfo?action=init&acu=true">{{ App\Models\Membership::first()->membership_year }}年度自動継続情報更新<br>(自動継続対象の方)</a></li>
      </ul>
    </div>
    <div class="out js-out" onclick="doActionLogout()">
      <div class="container">
        <div class="d-flex justify-content-center align-items-center">
          <svg xmlns="http://www.w3.org/2000/svg" class="svg-icon" style="width: 1em; height: 1em;vertical-align: middle;fill: currentColor;overflow: hidden;" viewBox="0 0 1024 1024" version="1.1">
            <path d="M768 106V184c97.2 76 160 194.8 160 328 0 229.6-186.4 416-416 416S96 741.6 96 512c0-133.2 62.8-251.6 160-328V106C121.6 190.8 32 341.2 32 512c0 265.2 214.8 480 480 480s480-214.8 480-480c0-170.8-89.6-321.2-224-406z" fill="" />
            <path d="M512 32c-17.6 0-32 14.4-32 32v448c0 17.6 14.4 32 32 32s32-14.4 32-32V64c0-17.6-14.4-32-32-32z" fill="" /></svg>
          <span>ログアウト</span>
        </div>
      </div>
    </div>
  </div>
</div>
