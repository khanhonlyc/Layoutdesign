<section class="site-notification"  style="display: none;">
  <div class="container">
    <marquee class="line-notification" width="100%" behavior="scroll">
      <!-- @yield("title_3") -->
    </marquee>
  </div>
</section>
