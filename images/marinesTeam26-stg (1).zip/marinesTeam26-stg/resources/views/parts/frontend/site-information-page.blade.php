<section class="site-information-page">
  <div class="container">
    @yield("text_date_30")
  </div>
</section>
