<section class="site-code pd-main">
  <div class="container">
    @yield("title_date_24")
  </div>
</section>