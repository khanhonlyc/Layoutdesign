<section class="pp-message js-pp-mess1">
  @yield("text_text_25")
</section>