<section class="site-album huy slick-slider-custom site-banner-top">
  <div class="slick-album">
    @yield("image_5")
  </div>
</section>
