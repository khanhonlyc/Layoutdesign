<section class="site-mtp-top">
  <div class="container">
    @yield("text_35")
  </div>
</section>
