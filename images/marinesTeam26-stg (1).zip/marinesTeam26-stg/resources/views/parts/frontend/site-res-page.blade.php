<section class="site-res-page">
  <div class="container">
    <div class="content">
      @yield("text_31")
    </div>
  </div>
</section>
