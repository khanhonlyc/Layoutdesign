@empty($battleToday)
<section class="site-banner slick-slider-custom">
  <div class="slick-banner">
    @yield("title_content_image_4")
  </div>
</section>
@else
<div class="">
  <!-- Banner thêm mb -->
  <div class="qr-code-mb" style="background-image: url(https://membertest060225.team26.jp//mypage/images/bg-menu.png);
  background-position: top;
  overflow: hidden;">
  <div class="row align-items-center m-0">
    <div class="img" id="qr-code-index">
    </div>
    <div class="text">
      <p class="t fan-name" style="color: rgb(176, 207, 213); font-size: 90%;"></p>
      <p class="hv fan-type-name fan-type-css"  style="background-color: #f5d365;"></p>
      <p class="mpt fc-rank-color">
        <span><span class="fc-rank-name"></span>ステージ</span>
        <span class="point"><span class="sum-point-m"></span><small>Mpt</small></span>
      </p>
      <p class="id-user">マリーンズID <span class="amc-no"></span></p>
    </div>
  </div>
</div>
<div class="site-album_banner">
  <div class="row m-0">
    <div class="col-md-8 p-0">
      <div class="content">
        <h3>TODAYS HOME GAME</h3>
        <div class="img">
          <div class="row m-0 align-items-center">
            <div class="col-4 p-0">
              <div class="img_dt">
                <img class="w-100 d-block" src="/mypage/images/ticket-logo/{{ $battleToday['homeTeamCode'] ?? 2008001 }}_l.png" alt="">
              </div>
            </div>
            <div class="col-4 p-0">
              <div class="text">
                <div class="nb">{{ \Carbon\Carbon::parse($battleToday['gameDate'])->format('m/d') }}<span>［{{ $weekMap[\Carbon\Carbon::parse($battleToday['gameDate'])->dayOfWeek] }}］</span></div>
                <div class="time">
                  <span>試合開始</span>
                  <p>{{ \Carbon\Carbon::parse($battleToday['gameTime'])->format('H:i') }}</p> 
                </div>
                <p class="t">{{ $battleToday['gameStadiumName'] }}</p>
              </div>
            </div>
            <div class="col-4 p-0">
              <div class="img_dt">
                <img class="w-100 d-block" src="/mypage/images/ticket-logo/{{ $battleToday['visitorTeamCode'] ?? 2008001 }}_l.png" alt="">
              </div>
            </div>
          </div>
        </div>
        <a href="https://www.marines.co.jp/gamelive/result/" target="_blank" class="btn-custom btn-custom-icon">試合速報はこちら</a>
      </div>
    </div>
    <div class="col-md-4 p-0">
      <ul class="box">
        <li>
          <a href="/mix/FmaMemberOutSiteLink.do?code=0" target="_blank">
            <img src="/mypage/images/ticket.svg" alt="">
            <span>チケット購入</span>
          </a>
        </li>
        <li>
          <a href="/mix/FmaMemberOutSiteLink?code=6" target="_blank">
            <img src="/mypage/images/ticket_my.svg" alt="">
            <span>マイチケット</span>
          </a>
        </li>
        <li>
          <a href="https://www.marines.co.jp/event/" target="_blank">
            <img src="/mypage/images/event.svg" alt="">
            <span>イベント情報</span>
          </a>
        </li>
        <li>
          <a href="https://www.marines.co.jp/stadium/" target="_blank">
            <img src="/mypage/images/map.svg" alt="">
            <span>スタジアム案内</span>
          </a>
        </li>
        <li>
          <a href="/mix/FmaMemberOutSiteLink.do?code=13" target="_blank">
            <img src="/mypage/images/goods_info.svg" alt="">
            <span>グッズ情報</span>
          </a>
        </li>
        <li>
          <a href="https://www.marines.co.jp/gourmet/" target="_blank">
            <img src="/mypage/images/gourmet.svg" alt="">
            <span>グルメ情報</span>
          </a>
        </li>
      </ul>
    </div>
  </div>
  <div class="button-marrin">
    <a href="/mypage/movie"><img src="/mypage/images/m1.png" alt=""> <span>視聴はこちら</span></a>
  </div>
</div>
</div>
@endempty
