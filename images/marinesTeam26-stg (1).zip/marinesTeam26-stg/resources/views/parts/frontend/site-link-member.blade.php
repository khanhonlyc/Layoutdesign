<section class="site-link-member">
  @yield('text_18')
</section>
