<section class="site-news">
  @yield("title_content_date_image_9")
</section>
