<section class="site-banner-web">
  <div class="container">
    @yield("text_23")
  </div>
</section>