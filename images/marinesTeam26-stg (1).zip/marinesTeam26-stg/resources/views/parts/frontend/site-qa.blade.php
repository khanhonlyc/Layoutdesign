<section class="site-qa">
  <div class="container">
    @yield("text_date_form_35")

  </div>
</section>
