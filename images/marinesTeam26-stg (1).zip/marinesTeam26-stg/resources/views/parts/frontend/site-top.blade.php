<section class="site-top">
  <div class="container">
    @yield("title_1")
    @yield("title_color_1")
  </div>
</section>
