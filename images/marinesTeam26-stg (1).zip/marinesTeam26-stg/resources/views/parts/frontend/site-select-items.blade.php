<section class="site-select-items pd-main">
  <div class="container">
    @yield("form_text_img_26")
  </div>
</section>