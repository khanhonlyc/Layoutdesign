<section class="site-search pd-main">
  <div class="container">
    @yield("form_img_text_20")
  </div>
</section>