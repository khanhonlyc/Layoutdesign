<section class="birthday-bnr-sec mt-5">
    <div class="birthday-bnr">
        <div class="birthday-bnr--img"></div>
        <div class="birthday-bnr--txt">
            <p>
                TEAM26有料会員限定サービスとして、「お気に入り選手登録」で1人目に登録した選手から、誕生日当日に誕生日のお祝いメッセージが届きます。<br>
                お届けするバースデーメッセージはスマートフォンなどの壁紙に設定できるサイズになっていますので、ぜひ保存をして設定してみてください！
            </p>
        </div>
    </div>
</section>