<section class="site-good slick-slider-custom">
  <div class="container">
    @yield("title_image_12")
  </div>
</section>
