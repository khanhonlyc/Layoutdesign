<section class="pp-ads">
  @yield("img_text_21")
</section>