<section class="site-marines site-video site-news-page">
  @yield("full_22")
</section>
