<section class="site-tab site-tab-infor">
  <div class="container">
    @yield("text_33")
  </div>
</section>
@yield("script_extend")
@section("script_extend")
<script type="text/javascript" src="/mypage/js/frontend/site-tab-infor.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
