<section class="site-qa">
  <div class="container">
    <div class="content_qa">
	  <div class="title">
	    <h3 class="vote-plan-title"></h3>
	    <span class="vote-time"></span>
	  </div>
	  <div class="content js-qa">
	    <form action="" id="question-list">
	    </form>
	    <button class="btn-custom btn-custom-icon hover-den" type="button" id="btn-complete">送信する</button>
	  </div>
	</div>
	<a class="btn-custom btn-back" href="javascript: history.go(-1)" id="btn-back">もどる</a>

  </div>
</section>

<script type="text/javascript">
  var voteId = '{{ $id }}';
  var request = {!! json_encode($request->all()) !!}
</script>
<script type="text/javascript" src="/mypage/js/frontend/site-qa-confirm.js?ver={{ \App\Enums\Version::LAST }}"></script>