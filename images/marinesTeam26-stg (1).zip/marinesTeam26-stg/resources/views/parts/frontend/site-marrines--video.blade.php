<section class="site-marines site-video site-video-custom pd-main">
  <div class="container">
    @yield("title_image_data_16")

  </div>
</section>
