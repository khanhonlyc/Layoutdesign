<div class="site-top-pc">
    <div class="row align-items-center">
        <div class="col-md-8">
            <div class="content">
                <span class="title"><span class="fan-name"></span>さま</span>
                <div class="mpt fan-type-css">
                    <span class="fan-type-name fan-type-css"></span>
                    <div class="number fc-rank-color text-white">
                        <p class="m-0"><span class="fc-rank-name"></span>ステージ</p>
                        <p class="m-0"><span class="sum-point-m"></span>Mpt</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <a class="notifi" href="/mypage/message">
                <span class="text count-notification"></span>
                <div class="loa">
                    <img src="/mypage/images/loa2.png" alt="">
                    <span class="number mess-non-read" style="display: none;"></span>
                    </div>
            </a>
        </div>
    </div>
</div>