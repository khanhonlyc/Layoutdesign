@extends('layouts.frontend') 
@section('menu-login') 
 	@include('parts.login.menu-login')
@endsection 
@section('login-js') 
 	@include('parts.login.login-js')
@endsection 
@section('main') 
<main>
  <section class="site-banner-login">
    <img class="w-100 d-block" src='{{secure_asset("mypage/images/login-bn.png")}}' alt="">
  </section>
  <section class="site-recruiting-members">
    <div class="container">
      <h2>2023年度会員募集中!</h2>
      <img class="w-100 d-block" src='{{secure_asset("mypage/images/member.png")}}' alt="">
      <div class="button">
        <div class="row row-custom">
          <div class="col-6 col-custom">
            <a class="btn-custom" href="#">継続入会の方は<br>こちら</a>
          </div>
          <div class="col-6 col-custom">
            <a class="btn-custom" href="#">マイページ<br>ログイン</a>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="site-login-team26">
    <img class="w-100 d-block" src='{{secure_asset("mypage/images/login-box.png")}}' alt="">
  </section>
  <section class="site-recruiting-members">
    <div class="container">
      <h2>2023年度会員募集中!</h2>
      <img class="w-100 d-block" src='{{secure_asset("mypage/images/member.png")}}' alt="">
      <div class="button">
        <div class="row row-custom">
          <div class="col-6 col-custom">
            <a class="btn-custom" href="#">継続入会の方は<br>こちら</a>
          </div>
          <div class="col-6 col-custom">
            <a class="btn-custom" href="#">マイページ<br>ログイン</a>
          </div>
        </div>
      </div>
    </div>
  </section>
  <section class="site-login-team26">
    <a href="#"><img class="w-100 d-block" src='{{secure_asset("mypage/images/login-box2.png")}}' alt=""></a>
  </section>
  <section class="site-recruiting-members">
    <div class="container">
      <h2>2023年度会員募集中!</h2>
      <img class="w-100 d-block" src='{{secure_asset("mypage/images/member.png")}}' alt="">
      <div class="button">
        <div class="row row-custom">
          <div class="col-6 col-custom">
            <a class="btn-custom" href="#">継続入会の方は<br>こちら</a>
          </div>
          <div class="col-6 col-custom">
            <a class="btn-custom" href="#">マイページ<br>ログイン</a>
          </div>
        </div>
      </div>
    </div>
  </section>
</main>
@endsection 