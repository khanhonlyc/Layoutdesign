@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile">
        アンケート
      </div>
      <section class="site-infor-event">
        <div class="container">
            <p class="notifi-data">下記のアンケートをただいま受付中です！ご協力よろしくお願いします。
            </p>
        <div class="infor-event infor-what">
            <ul class="list-vote">

            </ul>
          </div>
        </div>
      </section>
    </div>
  </section>
</main>
<script type="text/javascript" src="/mypage/js/pc/page60.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
