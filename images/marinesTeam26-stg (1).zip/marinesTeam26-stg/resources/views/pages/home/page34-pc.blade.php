@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom page-profile-customer site-uniform-font">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile">
        会員情報｜マイユニホーム
      </div>
      <section class="site-tab">
        <div class="container">
          <ul>
            <li><a href="{{ route_path('mypage.profile.customer.index') }}">基本情報</a></li>
            <li><a href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手登録</a></li>
            <li  class="active"><a href="{{ route_path('mypage.profile.uniform.index') }}">マイユニホーム</a></li>
          </ul>
        </div>
      </section>
      <section class="site-information-page site-uniform-page" style="padding-bottom: 0;">
        <div class="container">
          <div class="row">
            <div class="col-md-4">
              <div class="table-information">
                <h2>現在のマイユニホーム</h2>
                <div class="images-products">
                  <img class="w-100 d-block" src="/mypage/images/sp.png" alt="">
                  <div class="block-uniform">
                    <div id="js_Name" class="txt-name"></div>
                    <div id="js_Number" class="txt-number"></div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-8">
              <form class="table-information uniform-form" action="{{ route_path('mypage.profile.uniform.confirm') }}" method="POST" id="post_uniform">
                @csrf
                <h2>マイユニホームの登録・変更</h2>
                <div class="table-member">
                  <table>
                    <tr>
                      <td>ネーム表記</td>
                      <td>
                        <input class="form-control" placeholder="例）CHIBA" type="text" id="name-uni" name="name" value="{{old('name', request()->name)}}">
                        @if ($errors->has('name'))
                          <div class=" text-left"><span class="text-danger">{{ $errors->first('name') }}</span></div>
                        @else
                        <p>※最大13文字まで <br> ※半角英字、ピリオド(.)のみ使用可能<br>※小文字は大文字に変換されます。</p>
                        @endif
                      </td>
                    </tr>
                    <tr>
                      <td>背番号表記</td>
                      <td>
                        <input class="form-control" placeholder="例）043" type="text" id="number-uni" name="number" value="{{old('number', request()->number)}}">
                        @if ($errors->has('number'))
                          <div class=" text-left"><span class="text-danger">{{ $errors->first('number') }}</span></div>
                        @else
                        <p>※最大3文字まで <br> ※半角数字のみ使用可能</p>
                        @endif
                      </td>
                    </tr>
                    <tr>
                      <td>お気に入り選手で設定する</td>
                      <td>
                        <div class="label">
                          <label>
                            <input type="checkbox" name="" id="use-favorite">
                            <span>設定する</span>
                          </label>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td>現在の設定</td>
                      <td>
                        <input class="form-control" type="text" placeholder="" id="favorite" disabled>
                        <input class="form-control" type="text" placeholder="" name="favorite" hidden>
                      </td>
                    </tr>
                  </table>
                  <div class="text-center">
                    <a class="link" href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手設定はこちら ></a>
                  </div>
                  <div class="button">
                    <a class="btn-custom btn-custom-icon" href="javascript:{}" onclick="document.getElementById('post_uniform').submit();">登録・変更の確認</a>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  </section>
</main>
<script type="text/javascript">
  var listPlayers = {!! json_encode($playerUniforms) !!};
</script>
<script type="text/javascript" src="/mypage/js/pc/page34.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
