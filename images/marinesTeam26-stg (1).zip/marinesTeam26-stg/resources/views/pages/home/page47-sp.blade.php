@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-tab')
<section class="site-tab">
<div class="container">
  <ul>
    <li><a href="{{ route_path('mypage.history.point') }}">Mポイント実績</a></li>
    <li><a href="{{ route_path('mypage.history.visit') }}">来場履歴</a></li>
    <li><a href="{{ route_path('mypage.history.ticket') }}">チケット購入履歴</a></li>
    <li class="active"><a href="{{ route_path('mypage.history.privilege') }}">来場特典配布</a></li>
  </ul>
</div>
</section>
@endsection
@section('site-history-member')
<section class="site-history-member pd-main">
    <div class="container">
        <div class="history-content">
            <div class="calendar">
                  <select name="" id="year">
                    @for ($i = 2006; $i < 2024; $i++)
                    <option value="{{ $i }}" {{ \Carbon\Carbon::now()->year == $i ? 'selected' : '' }}>{{ $i }}年</option>
                    @endfor
                  </select>
            </div>
        </div>
        <div class="table-history">
            <div class="table">
                <div class="table-header">
                    <ul>
                        <li>獲得日</li>
                        <li>来場特典</li>
                        <li></li>
                    </ul>
                </div>
                <div class="content content-house content-house-47 privilege-list">

                </div>
            </div>
        </div>
    </div>
</section>
<script type="text/javascript" src="/mypage/js/sp/page47.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
