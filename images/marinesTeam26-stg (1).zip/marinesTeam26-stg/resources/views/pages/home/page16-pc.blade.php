@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom">
    <div class="container">
      @include('parts.member.member-top')
      <marquee class="line-notification" behavior="" direction="">
      </marquee>
      <div class="title-profile">
        ダイレクトメッセージ・事務局からのお知らせ
      </div>
      
      <section class="site-code">
        <div class="container">
          <div class="row">
            <div class="col-md-6 container-personal-mess" style="display:none;">
              <div class="code-container">
                <div class="items-code">
                  <h3 class="title text-left" style="padding-left: 20px;">ダイレクトメッセージ <span style="background-color:#D12B63" class="personal-mess-number"></span></h3>
                  <div class="content">
                    <ul class="personal-message-list">

                    </ul>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 container-mess" style="display:none;">
              <div class="code-use">
                <div class="items-code">
                  <h3 class="title text-left" style="padding-left: 20px;">事務局からのお知らせ <span style="background-color:#333333" class="mess-number"></span></h3>
                  <div class="content">
                    <ul class="message-list">
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </section>
</main>
@endsection
