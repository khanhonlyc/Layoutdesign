@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-tab')
<section class="site-tab">
<div class="container">
  <ul>
    <li class="active"><a href="{{ route_path('mypage.history.point') }}">Mポイント実績</a></li>
    <li><a href="{{ route_path('mypage.history.visit') }}">来場履歴</a></li>
    <li><a href="{{ route_path('mypage.history.ticket') }}">チケット購入履歴</a></li>
    <li><a href="{{ route_path('mypage.history.privilege') }}">来場特典配布</a></li>
  </ul>
</div>
</section>
@endsection
@section('site-history-member')
@include('parts.frontend.inner.site-history-member')
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
