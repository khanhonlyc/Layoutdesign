@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-tab')
@include('parts.frontend.inner.site-tab')
@endsection
@section('site-information-page')
<section class="site-information-page site-information-page-34">
    <div class="container">
        <div class="table-information">
          <h2>現在のマイユニホーム</h2>
          <div class="warp-uniform">
            <img class="w-100 d-block" src="/mypage/images/sp2.png" alt="">
            <div class="bg-uniform">
              <div class="inner-uniform">
                <div id="js_Name1" class="txt-name">{{ Cookie::get('js_Name'); }}</div>
                <div id="js_Number" class="txt-number"></div>
              </div>
            </div>
          </div>
        </div>
        </div>
        </div>
        <div class="container mt-5">
            <form class="table-information" action="{{ route_path('mypage.profile.uniform.confirm') }}" method="POST" id="post_uniform">
                @csrf
                <h2>マイユニホームの登録・変更</h2>
                <div class="table-member">
                    <table>
                        <tbody><tr>
                            <td>ネーム表記</td>
                            <td>
                                <input class="form-control" placeholder="例）CHIBA" type="text" id="name-uni" name="name" value="{{old('name', request()->name)}}">
                            @if ($errors->has('name'))
                              <div class=" text-left"><span class="text-danger">{{ $errors->first('name') }}</span></div>
                            @else
                                <p>※最大13文字まで <br>
                                ※半角英字、ピリオド(.)のみ使用可能<br>
                                ※小文字は大文字に変換されます。</p>
                            @endif
                            </td>
                        </tr>
                        <tr>
                            <td>背番号表記</td>
                            <td>
                                <input class="form-control" placeholder="例）043" type="text" id="number-uni" name="number" value="{{old('number', request()->number)}}">
                              @if ($errors->has('number'))
                                  <div class=" text-left"><span class="text-danger">{{ $errors->first('number') }}</span></div>
                                @else
                                    <p>※最大3文字まで <br>
                                    ※半角数字のみ使用可能</p>
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <td>お気に入り選手で設定する</td>
                            <td>
                                <div class="label">
                                    <label>
                                        <input type="checkbox" name="" id="use-favorite">
                                        <span>設定する</span>
                                    </label>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>現在の設定</td>
                            <td>
                                <input class="form-control" type="text" placeholder="" id="favorite" disabled>
                                <input class="form-control" type="text" placeholder="" name="favorite" hidden>
                            </td>
                        </tr>
                    </tbody></table>
                    <a class="link" href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手設定はこちら &gt;</a>
                    <div class="button">
                        <a class="btn-custom btn-custom-icon" href="javascript:{}" onclick="document.getElementById('post_uniform').submit();">登録・変更の確認</a>
                    </div>
                </div>
            </form>          
        </div>
    </div>
</section>
<script type="text/javascript">
  var listPlayers = {!! json_encode($playerUniforms) !!};
</script>
<script type="text/javascript" src="/mypage/js/sp/page34.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
