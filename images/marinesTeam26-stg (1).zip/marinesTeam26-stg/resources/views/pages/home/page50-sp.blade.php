@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-tab-infor')
<div class="display-point display-point-save justify-content-center align-items-center pt-3 pb-3">
    <p class="m-0">保有Mポイント</p>
    <span class="point" id="point-saving"><span> Mpt</span>
    </span>
</div>
@include('parts.frontend.inner.site-tab-infor')
@endsection
@section('site-infor-event-single')
<section class="site-infor-event site-infor-event-single">
    <div class="container">
        <div class="title">
            <p>登録ボタンを押すと、以下のイベントへの参加申込が完了します。</p>
        </div>
        <div class="infor-event">
            <h3 class="heading event-title"></h3>
            <div class="single-event">
                <div class="items">
                    <label>開催日時</label>
                    <p><strong class="event-time"></strong></p>
                </div>
                <div class="items">
                    <label>開催場所</label>
                    <p><strong class="event-place"></strong></p>
                </div>
                <div class="items display-point">
                  <label>使用ポイント</label>
                  <p><strong class="event-point"></strong></p>
                </div>
            </div>
            <div class="display-point display-point-calc justify-content-center align-items-center font-weight-bold">
                <p class="m-0">登録後のMポイント</p>
                <span class="point" id="point-calc"><span> Mpt</span></span>
            </div>
            <a class="btn-custom btn-custom-icon" id="btn-post-event" href="javascript:void(0);">登録する</a>
            </div>
            <a class="btn-custom btn-back" href="{{ route_path('mypage.event.show', $id) }}">イベント詳細にもどる</a>
    </div>
</section>
<script type="text/javascript">
    var eventId = '{{ $id }}';
</script>
<script type="text/javascript" src="/mypage/js/sp/page50.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
