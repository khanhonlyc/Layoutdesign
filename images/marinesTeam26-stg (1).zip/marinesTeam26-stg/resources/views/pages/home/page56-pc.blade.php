@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile">
        イベント情報｜申込締切
      </div>
      <section class="site-tab site-tab-infor">
        <div class="container">
          <ul>
            <li><a href="{{ route_path('mypage.event.index') }}">申込受付</a></li>
            <li><a href="{{ route_path('mypage.event.applied') }}">申込済み</a></li>
            <li class="active"><a href="{{ route_path('mypage.event.close') }}">申込締切</a></li>
            <li><a href="{{ route_path('mypage.event.performed') }}">開催済み</a></li>
          </ul>
        </div>
      </section>
      <section class="site-infor-event">
        <div class="container">
          <div class="infor-event">
            <ul class="list-event">

            </ul>
          </div>
        </div>
      </section>
    </div>
  </section>
</main>
<script type="text/javascript" src="/mypage/js/pc/page56.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
