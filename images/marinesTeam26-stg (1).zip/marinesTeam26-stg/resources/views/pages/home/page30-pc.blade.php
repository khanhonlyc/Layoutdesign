@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom page-profile-customer">
    <div class="container">
       @include('parts.member.member-top')
      <div class="title-profile">
        会員情報｜基本情報
      </div>
      <section class="site-tab">
        <div class="container">
          <ul>
            <li class="active"><a href="{{ route_path('mypage.profile.customer.index') }}">基本情報</a></li>
            <li><a href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手登録</a></li>
            <li><a href="{{ route_path('mypage.profile.uniform.index') }}">マイユニホーム</a></li>
          </ul>
        </div>
      </section>
      <section class="site-res-page">
        <div class="container">
          <div class="content">
            <p>「基本情報」の更新が完了しました。</p>
          </div>
        </div>
      </section>
      <section class="site-information-page">
        <div class="container">
          <div class="button">
            <a class="btn-custom btn-custom-icon" href="{{ route_path('mypage.index') . '/' }}">ホームへもどる</a>
          </div>
          <a class="btn-custom btn-back" href="{{ route_path('mypage.profile.customer.index') }}">基本情報へもどる</a>
        </div>
      </section>
    </div>
  </section>
</main>
@endsection
