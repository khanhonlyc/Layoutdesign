@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-tab')
<section class="site-tab">
    <div class="container">
        <ul>
            <li><a href="#">お気に入り選手登録</a></li>
            <li class="active"><a href="#">マイユニホーム</a></li>
        </ul>
    </div>
</section>
@endsection
@section('site-res-page')
<section class="site-res-page">
    <div class="container">
        <div class="content">
            <p>マイユニホームの登録が完了しました。
            </p>
        </div>
    </div>
</section>
@endsection
@section('site-information-page')
<section class="site-information-page">
    <div class="container">
        <div class="images-products">
          <img class="w-100 d-block" src="/mypage/images/sp.png" alt="">
          <div class="block-uniform">
            <div id="js_Name3" class="txt-name">{{ $request->name }}</div>
            <div id="js_Number3" class="txt-number">{{ $request->number }}</div>
          </div>
        </div>
      <a class="btn-custom btn-custom-icon" href="{{ route_path('mypage.index') . '/' }}">ホームへもどる</a>
      <a class="btn-custom btn-back" href="{{ route_path('mypage.profile.uniform.index') }}">マイユニホームへもどる</a>
    </div>
</section>
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
