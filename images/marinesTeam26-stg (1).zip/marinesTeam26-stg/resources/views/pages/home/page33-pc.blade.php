@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom page-profile-customer">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile">
        会員情報｜お気に入り選手登録
      </div>
      <section class="site-tab">
        <div class="container">
          <ul>
            <li><a href="{{ route_path('mypage.profile.customer.index') }}">基本情報</a></li>
            <li class="active"><a href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手登録</a></li>
            <li><a href="{{ route_path('mypage.profile.uniform.index') }}">マイユニホーム</a></li>
          </ul>
        </div>
      </section>
      <section class="site-res-page">
        <div class="container">
          <div class="content">
            <p>「お気に入り選手」の登録・変更が完了しました。<br>
              <strong>NO.１</strong>選手の登録・変更内容はホーム画面の <strong>「MY FAVORITE PLAYER」</strong>でも確認いただけます。 </p>
            </div>
          </div>
        </section>
        <section class="site-banner">
          <div class="slick-banner-none" style="padding: 0px 40px;">
            <div class="items" style="max-width: 700px; width: 100%; margin:0 auto; margin-top: 60px;">
              <img class="w-100 d-block has-favorite" id="bg-favorite" src="">
              <div class="text-content has-favorite">
                <div class="row m-0 align-items-center">
                  <div class="col-9 p-0">
                    <div class="title-nh-45">
                        <div class="flex-nh-title">
                          <span style="font-size: 34px;" class="player-uniform-no"></span>
                          <span style="font-size: 2.4vw !important;margin-bottom: 7px !important;" class="player-name-roma"></span>
                        </div>
                        <span style="font-size:26px; margin-bottom: 15px;" class="player-name"></span>
                      </div>
                    <span id="index-1"></span>
                    <span id="index-2"></span>
                    <span id="index-3"></span>
                    <span class="date-cn" id="date-update"></span>
                  </div>
                  <div class="col-6 p-0 d-flex flex-column align-items-end">
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="site-information-page">
          <div class="container">
            <div class="table-information box-member-play m-0 p-0">
              <h2>変更後のお気に入り選手</h2>
              <div class="list-member-play">
                <div class="row">
                  <div class="col-md-4">
                    <div class="items" id="favorite-1">
                      <h3>お気に入り選手　１人目</h3>
                      
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="items" id="favorite-2">
                      <h3>お気に入り選手　2人目</h3>

                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="items" id="favorite-3">
                      <h3>お気に入り選手　3人目</h3>
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <a class="btn-custom btn-custom-icon" href="{{ route_path('mypage.index') . '/' }}">ホームへもどる</a>
            <a class="btn-custom btn-back" href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手登録へもどる</a>
          </div>
        </section>
      </div>
    </section>
  </main>
  <script type="text/javascript" src="/mypage/js/pc/page33.js?ver={{ \App\Enums\Version::LAST }}"></script>
  @endsection
