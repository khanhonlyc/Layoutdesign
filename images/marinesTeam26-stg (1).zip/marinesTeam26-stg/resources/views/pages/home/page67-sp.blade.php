@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-ex-point')
<section class="site-page67 pd-main">
        <div class="text-left">
          <div class="contents_right">
            <h2 class="t2">Mポイントの付与が完了しました。<br />
              @if(!is_null($gameDate) && $gameDate !== "null")
              試合日は{{ $gameDate }}です。<br />
              @endempty
            Mポイントの詳細は会員履歴内Mポイント実績にてご確認ください。</h2>
            <p></p>

            <div class="btn">
              <a class="btn-custom btn-custom-icon" href="{{ route_path('mypage.history.point')}}" target="_parent">
                <span>Mポイント実績はこちら</span>
              </a>
              <a class="btn-custom btn-back" style="margin-top: 20px;" href="/mypage/point/grant"><span>Mポイントへもどる</span></a>
            </div>
          </div>
    </section>
    <style>
    </style>
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
