@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile"> 
        アンケート
      </div>
      <section class="site-qa">
        <div class="container">
          <div class="text">
            <p class="respon-complete">
              アンケートへご回答いただきありがとうございました。<br>
              ご回答いただいた内容を精査しより安心・安全な観戦環境づくり、新たなサービスの提供に励んでいきますので引き続き千葉ロッテマリーンズの応援をお願いいたします。
            </p>
          </div>
          <a class="btn-custom btn-custom-icon" href="{{ route_path('mypage.index').'/' }}">ホームへもどる</a>
          <a class="btn-custom btn-back" href="{{ route_path('mypage.vote.index') }}">アンケート一覧にもどる</a>
        </div>
      </section>
    </div>
  </section>
</main>
</script>
<script type="text/javascript" src="/mypage/js/pc/page63.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
