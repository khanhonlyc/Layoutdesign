@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-tab')
@include('parts.frontend.inner.site-tab')
@endsection
@section('site-res-page')
<section class="site-res-page">
    <div class="container">
        <div class="content">
            <p>「基本情報」の更新が完了しました。</p>
        </div>
    </div>
</section>
@endsection
@section('site-information-page')
<section class="site-information-page">
    <div class="container">
        <div class="button">
            <a class="btn-custom btn-custom-icon" href="{{ route_path('mypage.index') . '/' }}">ホームへもどる</a>
        </div>
        <a class="btn-custom btn-back" href="{{ route_path('mypage.profile.customer.index') }}">基本情報へもどる</a>
    </div>
</section>
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
