@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom page-profile-customer">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile">
        会員履歴｜来場履歴
      </div>
      <section class="site-tab">
        <div class="container">
          <ul>
            <li><a href="{{ route_path('mypage.history.point') }}">Mポイント実績</a></li>
            <li class="active"><a href="{{ route_path('mypage.history.visit') }}">来場履歴</a></li>
            <li><a href="{{ route_path('mypage.history.ticket') }}">チケット購入履歴</a></li>
            <li><a href="{{ route_path('mypage.history.privilege') }}">来場特典配布</a></li>
          </ul>
        </div>
      </section>
      <section class="site-history-member pd-main">
        <div class="container">
          <div class="history-house">
            <div class="row">
              <div class="col-md-6">
                <div class="items">
                  <h3 class="d-flex"><div class="year-selected">{{ \Carbon\Carbon::now()->year }}</div>年のホーム来場回数</h3>
                  <span class="home-cnt"></span>
                </div>
              </div>
              <div class="col-md-6">
                <div class="items">
                  <h3 class="d-flex"><div class="year-selected">{{ \Carbon\Carbon::now()->year }}</div>年の来場試合の勝率</h3>
                  <span class="wonrate"></span>
                </div>
              </div>
            </div>
          </div>
          <div class="history-content">
            <div class="calendar">
              <select name="" id="year-rec">
                @for ($i = 2006; $i < 2024; $i++)
                <option value="{{ $i }}" {{ \Carbon\Carbon::now()->year == $i ? 'selected' : '' }}>{{ $i }}年</option>
                @endfor
              </select>
            </div>
          </div>
          <div class="table-history table-history-page43 table-house">
            <div class="table">
              <div class="table-header">
                <ul>
                  <li>来場年月日</li>
                  <li>対戦相手・球場</li>
                  <li>勝敗</li>
                  <li>得点</li>
                </ul>
              </div>
              <div class="content content-house rec-coming-list">
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </section>
</main>
<script type="text/javascript" src="/mypage/js/pc/page43.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
