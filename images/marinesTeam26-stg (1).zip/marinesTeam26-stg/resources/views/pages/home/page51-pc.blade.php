@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile">
        イベント情報｜申込受付
      </div>
      <section class="site-tab site-tab-infor">
        <div class="container">
          <ul>
            <li class="active"><a href="{{ route_path('mypage.event.index') }}">申込受付</a></li>
            <li><a href="{{ route_path('mypage.event.applied') }}">申込済み</a></li>
            <li><a href="{{ route_path('mypage.event.close') }}">申込締切</a></li>
            <li><a href="{{ route_path('mypage.event.performed') }}">開催済み</a></li>
          </ul>
        </div>
      </section>
      <section class="site-infor-event site-infor-event-single">
        <div class="container">
          <div class="title">
            <p>イベント参加へのお申込みありがとうございました。<br>
            当選の連絡はTEAM26マイページ内機能ダイレクトメッセージにてお知らせいたします。</p>
          </div>
          <a class="btn-custom btn-back" href="{{ route_path('mypage.event.index') }}">イベント一覧画面にもどる</a>
        </div>
      </section>
    </div>
  </section>
</main>
<script type="text/javascript" src="/mypage/js/pc/page51.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
