@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile"> 
        アンケート
      </div>
      <section class="site-qa">
        <div class="container">
          <div class="content_qa">
            <div class="title">
              <h3 class="vote-plan-title"></h3>
              <span class="vote-time"></span>
            </div>
            <div class="content js-qa">
              <form action="{{ route('mypage.vote.confirm', $id) }}" id="question-list" method="POST">
                @csrf
  
              </form>
              <div class="group-btn-qa d-sm-flex justify-content-center">
                <button class="btn btn-custom" type="button" id="btn-reset">リセット</button>
                <button class="btn-custom btn-custom-icon hover-den" type="button" id="btn-confirm">回答の確認はこちら</button>
              </div>
            </div>
          </div>
          <a class="btn-custom btn-back " href="javascript: history.go(-1)" id="btn-back">もどる</a>
        </div>
      </section>
    </div>
  </section>
</main>
<script type="text/javascript">
  var voteId = '{{ $id }}';
</script>
<script type="text/javascript" src="/mypage/js/pc/page62.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
