@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-tab')
<section class="site-tab">
    <div class="container">
        <ul>
            <li><a href="#">お気に入り選手登録</a></li>
            <li class="active"><a href="#">マイユニホーム</a></li>
        </ul>
    </div>
</section>
@endsection
@section('site-information-page')
<section class="site-information-page site-information-page-35">
    <div class="container">
        <div class="table-information">
            <h2>マイユニホーム_登録・変更</h2>
            <div class="warp-uniform">
              <img class="w-100 d-block" src="/mypage/images/sp2.png" alt="">
              <div class="bg-uniform">
                <div class="inner-uniform">
                  <div id="js_Name2" class="txt-name">{{ $request->name }}</div>
                  <div id="js_Number2" class="txt-number">{{ $request->number }}</div>
                </div>
              </div>
            </div>
              <form class="table-member" action="{{ route_path('mypage.profile.uniform.complete') }}" method="POST" id="post_uniform">
                @csrf
                <table>
                    <tbody><tr>
                        <td>ネーム表記</td>
                        <td>
                            <strong>{{ $request->name }}</strong>
                            <input type="hidden" name="name" value="{{ $request->name }}">
                        </td>
                    </tr>
                    <tr>
                        <td>背番号表記</td>
                        <td>
                            <strong>{{ $request->number }}</strong>
                            <input type="hidden" name="number" value="{{ $request->number }}">
                        </td>
                    </tr>
                    <!-- <tr>
                        <td>お気に入り選手で設定する</td>
                        <td>
                            {{ $request->favorite }}
                        </td>
                    </tr> -->
                </tbody></table>
                <input type="hidden" name="amcno">
                <div class="button m-0">
                    <a class="btn-custom btn-custom-icon" style="background-color: #fff; border-color: #D12B63; color: #D12B63;" href="javascript:{}" onclick="document.getElementById('post_uniform').submit();">変更する</a>
                </div>
            </form>
        </div>
        <a class="btn-custom btn-back" href="{{ route_path('mypage.profile.uniform.index', ['name'=>$request->name, 'number'=>$request->number]) }}">もどる</a>
    </div>
</section>
<script type="text/javascript">
jQuery(document).ready(function($) {
  window.onload = function() {
    new CircleType(document.getElementById('js_Name2')).radius(160);
  };
});
</script>
<style type="text/css">

</style>
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
