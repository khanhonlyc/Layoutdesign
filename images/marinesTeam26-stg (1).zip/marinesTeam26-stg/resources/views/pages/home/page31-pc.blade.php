@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom page-profile-customer">
    <div class="container">
       @include('parts.member.member-top')
      <div class="title-profile">
        会員情報｜お気に入り選手登録
      </div>
      <section class="site-tab">
        <div class="container">
          <ul>
            <li><a href="{{ route_path('mypage.profile.customer.index') }}">基本情報</a></li>
            <li class="active"><a href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手登録</a></li>
            <li><a href="{{ route_path('mypage.profile.uniform.index') }}">マイユニホーム</a></li>
          </ul>
        </div>
      </section>
      <section class="site-res-page">
        <div class="container">
          <div class="content">
            <p>「お気に入り選手」を登録できます。<br> 登録変更は何度でも可能です。該当する選手がいない場合 は「未選択」を選択してください</p>
          </div>
        </div>
      </section>

      @include('parts.frontend.site-banner-birthday')
      <section class="site-information-page">
        <div class="container">
          <div class="table-information box-member-play p-0">
            <h2 class="text-left">お気に入り選手</h2>
            <form class="" method="POST" action="{{ route_path('mypage.profile.favorite.confirm') }}" id="post-favorite">
              @csrf
              <div class="list-member-play">
                <div class="row">
                  <div class="col-md-4">
                    <div class="items">
                      <h3>お気に入り選手　１人目</h3>
                      <div class="user"  id="favorite-1">
                        <div class="row m-0 align-items-end"><div class="col-md-4 p-0"><div class="img"><img src="/mypage/images/user-defeaut.png" alt=""></div></div><div class="col-md-8 p-0"><div class="text"><span>未選択</span></div></div></div>
                      </div>
                      <div class="content-member">
                        <span class="dk-td"><span>登録・変更</span></span>
                        <div class="select">
                          <select class="form-control player-list" name="favorite1" id="" required>
                            <option value="">選択してください</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="items">
                      <h3>お気に入り選手　２人目</h3>
                      <div class="user"  id="favorite-2">
                        <div class="row m-0 align-items-end"><div class="col-md-4 p-0"><div class="img"><img src="/mypage/images/user-defeaut.png" alt=""></div></div><div class="col-md-8 p-0"><div class="text"><span>未選択</span></div></div></div>
                      </div>
                      <div class="content-member">
                        <span class="dk-td"><span>登録・変更</span></span>
                        <div class="select">
                          <select class="form-control player-list1" name="favorite2" id="">
                            <option value="9999998">選択してください</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="items">
                      <h3>お気に入り選手　３人目</h3>
                      <div class="user"  id="favorite-3">
                        <div class="row m-0 align-items-end"><div class="col-md-4 p-0"><div class="img"><img src="/mypage/images/user-defeaut.png" alt=""></div></div><div class="col-md-8 p-0"><div class="text"><span>未選択</span></div></div></div>
                      </div>
                      <div class="content-member">
                        <span class="dk-td"><span>登録・変更</span></span>
                        <div class="select">
                          <select class="form-control player-list2" name="favorite3" id="">
                            <option value="9999999">選択してください</option>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <a class="btn-custom btn-custom-icon" href="javascript:void(0)" onclick="checkFavorite();">登録・変更の確認はこちら</a>
            </form>
          </div>
          <!-- <div class="text-center">
            <p class="mt-4 font-weight-bold">
            2023年度の「お気に入り選手登録」は4月7日（金）公開予定です。<br>
            公開までしばらくお待ちください。</p>
          </div> -->
          <a class="btn-custom btn-custom-icon" href="/mypage/">ホームへもどる</a>
        </div>
      </section>
    </div>
  </section>
</main>
<script type="text/javascript" src="/mypage/js/pc/page31.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
