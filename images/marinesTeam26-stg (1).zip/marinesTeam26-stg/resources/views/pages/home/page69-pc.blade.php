@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom">
    <div class="container">
      @include('parts.member.member-top')
	    <div class="title-profile">
	        ミッション｜特別ミッション
	    </div>
	    <section class="site-tab">
	        <div class="container">
	            <ul>
	                <li><a  href="{{ route_path('mypage.mission.monthly') }}">月間ミッション</a></li>
	                <li class="active"><a href="{{ route_path('mypage.mission.special') }}">特別ミッション</a></li>
	            </ul>
	        </div>
	    </section>
	    <section class="site-history-member pd-main">
                <div class="container">
                    <div class="history-content">
                        <div class="calendar">
                            <select name="" id="year">
                                <option value="">----</option>
                                
                            </select>
                        </div>
                    </div>
                    <div class="site-mission site-mission-page misstion-page pd-main">
                        <div class="list-content">
                            <div class="mission">
                                <div class="container">
                                    <div class="row" id="mission-special">
                                        <div class="content text-center w-100">
                                            <p><strong>ミッションはありません。</strong></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
    </div>
  </section>
</main>
<script type="text/javascript" src="/mypage/js/pc/page69.js"></script>
@endsection
