@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
    <section class="destop_custom page-marines-plus">
        <div class="container">
            @include('parts.member.member-top')
            <div class="title-pc-marines">
                <img src="/mypage/images/m1.png" alt="">
            </div>
            <section class="site-marines site-marines-page">
                <div class="container" id="live-html">

                </div>
            </section>
            <section class="site-marines site-video pd-main">
              <div class="container">
                  <div class="heading-custom-plus">
                    <h2>VIDEO</h2>
                    <h3><i class="fa-solid fa-circle-play"></i> VIDEO <span>ビデオ</span></h3>
                  </div>
                  <div class="slick-video-pc slick-slider-custom" id="video-html">

                  </div>
                  <a class="btn-custom" href="{{ route_path('mypage.movie.list') }}">VIDEO一覧はこちら</a>
                </div>
            </section>
            <section class="site-search pd-main">
                <div class="container">
                    <div class="search-form">
                        <form action="{{ route_path('mypage.movie.list') }}">
                            <input class="form-control" type="text" name="search" placeholder="選手名・トピックス名検索">
                            <button type="submit">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                                    <path d="M416 208c0 45.9-14.9 88.3-40 122.7L502.6 457.4c12.5 12.5 12.5 32.8 0 45.3s-32.8 12.5-45.3 0L330.7 376c-34.4 25.2-76.8 40-122.7 40C93.1 416 0 322.9 0 208S93.1 0 208 0S416 93.1 416 208zM208 352c79.5 0 144-64.5 144-144s-64.5-144-144-144S64 128.5 64 208s64.5 144 144 144z" />
                                </svg>
                            </button>
                        </form>
                        <div class="tags">
                            <h3 class="hd-tag">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512">
                                    <path d="M0 80V229.5c0 17 6.7 33.3 18.7 45.3l176 176c25 25 65.5 25 90.5 0L418.7 317.3c25-25 25-65.5 0-90.5l-176-176c-12-12-28.3-18.7-45.3-18.7H48C21.5 32 0 53.5 0 80zm112 96c-17.7 0-32-14.3-32-32s14.3-32 32-32s32 14.3 32 32s-14.3 32-32 32z" />
                                </svg>
                                <span>注目キーワード</span>
                            </h3>
                            <div class="list-tag">
                                @foreach ($topicTags as $item)
                                <a href="{{ route_path('mypage.movie.list', ['tag' => $item->tag_id]) }}">{{ $item->tag_name }}</a>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </section>
</main>
@endsection
