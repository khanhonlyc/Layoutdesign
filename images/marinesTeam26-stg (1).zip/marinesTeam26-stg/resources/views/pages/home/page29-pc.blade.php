@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom page-profile-customer">
    <div class="container">
       @include('parts.member.member-top')
      <div class="title-profile">
        会員情報｜基本情報
      </div>
      <section class="site-tab">
        <div class="container">
          <ul>
            <li class="active"><a href="{{ route_path('mypage.profile.customer.index') }}">基本情報</a></li>
            <li><a href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手登録</a></li>
            <li><a href="{{ route_path('mypage.profile.uniform.index') }}">マイユニホーム</a></li>
          </ul>
        </div>
      </section>
      <section class="site-res-page">
        <div class="container">
          <div class="content">
            <p>更新内容をご確認のうえ、内容が正しい場合は「更新」ボタンを押してください。また修正を行う場合は「もどる」ボタンを押して更新ページにて修正してください。 パスワードはセキュリティ上、表示いたしません。</p>
          </div>
        </div>
      </section>
      <section class="site-information-page">
        <div class="container">
          <form action="">
            <div class="table-information">
              <h2>基本情報</h2>
              <table class="table">
                <tr>
                  <td>マリーンズID</td>
                  <td class="amc-no">{{ request()->amcNo }}</td>
                </tr>
                <tr>
                  <td>フリガナ</td>
                  <td class="name-kana">{{ request()->name_kana }}</td>
                </tr>
                <tr>
                  <td>お名前</td>
                  <td class="name">{{ request()->name }}</td>
                </tr>
                <tr>
                  <td>性別</td>
                  <td>{{ request()->sex ? '女性' : '男性' }}</td>
                  <input type="hidden" name="sex" value="{{ request()->sex }}">
                </tr>
                <tr>
                  <td>生年月日</td>
                  <td class="birth-day">{{ request()->birthDay }}</td>
                </tr>
                <tr>
                  <td>電話番号</td>
                  <td>{{ request()->telNo1.'-'.request()->telNo2.'-'.request()->telNo3 }}</td>
                  <input type="hidden" name="telNo1" value="{{ request()->telNo1 }}">
                  <input type="hidden" name="telNo2" value="{{ request()->telNo2 }}">
                  <input type="hidden" name="telNo3" value="{{ request()->telNo3 }}">
                </tr>
                <tr>
                  <td>郵便番号</td>
                  <td>{{ request()->zipCode1.'-'.request()->zipCode2 }}</td>
                  <input type="hidden" name="zipCode1" value="{{ request()->zipCode1 }}">
                  <input type="hidden" name="zipCode2" value="{{ request()->zipCode2 }}">
                </tr>
                <tr>
                  <td>自宅住所</td>
                  <td><span class="address1">{{ request()->address1_text }}</span><br/>{{ request()->address2 }}<br/>{{ request()->address3 }}<br/>{{ request()->address4 }}<br/>{{ request()->address5 }}</td>
                  <input type="hidden" name="address1" value="{{ request()->address1 }}">
                  <input type="hidden" name="address2" value="{{ request()->address2 }}">
                  <input type="hidden" name="address3" value="{{ request()->address3 }}">
                  <input type="hidden" name="address4" value="{{ request()->address4 }}">
                  <input type="hidden" name="address5" value="{{ request()->address5 }}">
                </tr>
                <tr>
                  <td>送付先会員番号</td>
                  <td>{{ request()->delivFanNo }}</td>
                  <input type="hidden" name="delivFanNo" value="{{ request()->delivFanNo }}">
                </tr>
                <tr>
                  <td>送付先お名前</td>
                  <td>{{ request()->delivLastName.' '.request()->delivFirstName }}</td>
                  <input type="hidden" name="delivLastName" value="{{ request()->delivLastName }}">
                  <input type="hidden" name="delivFirstName" value="{{ request()->delivFirstName }}">
                </tr>
                <tr>
                  <td>送付先電話番号</td>
                  <td>{{ request()->delivTelNo1.'-'.request()->delivTelNo2.'-'.request()->delivTelNo3 }}</td>
                  <input type="hidden" name="delivTelNo1" value="{{ request()->delivTelNo1 }}">
                  <input type="hidden" name="delivTelNo2" value="{{ request()->delivTelNo2 }}">
                  <input type="hidden" name="delivTelNo3" value="{{ request()->delivTelNo3 }}">
                </tr>
                <tr>
                  <td>メールアドレス</td>
                  <td id="text-email">{{ request()->email ? request()->email : request()->email_old }}</td>
                  <input type="hidden" name="email" value="{{ request()->email ? request()->email : request()->email_old }}">
                  <input type="hidden" name="emailConf" value="{{ request()->emailConf ? request()->emailConf : request()->email_old }}">
                </tr>
                <tr>
                  <td>パスワード</td>
                  <td id="text-pass">●●●●●●●●</td>
                  <input type="hidden" name="fanPassword" value="{{ request()->fanPassword ? request()->fanPassword : '●●●●●●●●' }}">
                  <input type="hidden" name="fanPasswordConf" value="{{ request()->fanPasswordConf ? request()->fanPasswordConf : '●●●●●●●●' }}">
                  <input type="hidden" name="fanPasswordCurrent" value="{{ request()->fanPasswordCurrent }}">
                </tr>
              </table>
              <div class="content">
                <div class="pp">
                  <div class="email">
                    <i class="fa-regular fa-envelope"></i>
                    <span>マリーンズメルマガの配信</span>
                  </div>
                  @if (request()->mailMagazine)<a href="#">配信する</a>@else <a href="#">希望しない</a> @endif
                  <input type="hidden" name="mailMagazine" value="{{ request()->mailMagazine }}">
                </div>
                <div class="button">
                  <a class="btn-custom btn-custom-icon" href="javascript:void(0)" id="post-data">更新する</a>
                </div>
              </div>
            </div>
            <a class="btn-custom btn-back" href="javascript: history.go(-1)">もどる</a>
          </form>
        </div>
      </section>
    </div>
  </section>
</main>
<script type="text/javascript">
  var bookChk = "{{ request()->book_chk }}";
  var requestAll = {!! json_encode(request()->all()) !!};
</script>
<script type="text/javascript" src="/mypage/js/pc/page29.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
