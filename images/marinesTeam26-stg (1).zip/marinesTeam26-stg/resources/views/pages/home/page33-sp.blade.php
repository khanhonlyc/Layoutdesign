@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-tab')
@include('parts.frontend.inner.site-tab')
@endsection
@section('site-res-page')
<section class="site-res-page">
    <div class="container">
        <div class="content">
            <p>「お気に入り選手」の登録・変更が完了しました。<br>
                <strong>NO.１</strong>選手の登録・変更内容はホーム画面の<br><strong>「MY FAVORITE PLAYER」</strong>でも確認いただけます。
            </p>
        </div>
    </div>
</section>
<section class="site-banner">
    <div class="slick-banner-none">
      <div class="items">
        <img class="w-100 d-block has-favorite" id="bg-favorite" src="">
        <div class="text-content has-favorite">
          <div class="row m-0 align-items-center">
            <div class="col-9 p-0">
              <div class="title-nh-45">
                <div class="flex-nh-title">
                  <span style="font-size: 34px;" class="player-uniform-no"></span>
                  <span style="font-size:20px;" class="player-name-roma"></span>
                </div>
                <span style="font-size:26px; margin-bottom: 15px;" class="player-name"></span>
              </div>
              <span class="text1" id="index-1"> </span>
              <span class="text1" id="index-2"> </span>
              <span class="text1" id="index-3"> </span>
              <span class="date-cn" id="date-update"></span>
            </div>
          </div>
        </div>
      </div>
    </div>
</section>
@endsection
@section('site-information-page')
<section class="site-information-page">
    <div class="container">
        <div class="table-information">
            <h2>変更後のお気に入り選手</h2>
            <div class="list-member-play">
              <div class="items" id="favorite-1">
                <div class="number">No. <span>1</span></div>
              </div>
              <div class="items" id="favorite-2">
                <div class="number">No. <span>2</span></div>
              </div>
              <div class="items" id="favorite-3">
                <div class="number">No. <span>3</span></div>
              </div>
            </div>
        </div>
      <a class="btn-custom btn-custom-icon" href="{{ route_path('mypage.index') . '/' }}">ホームへもどる</a>
      <a class="btn-custom btn-back" href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手登録へもどる</a>
    </div>
</section>
<script type="text/javascript" src="/mypage/js/sp/page33.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
