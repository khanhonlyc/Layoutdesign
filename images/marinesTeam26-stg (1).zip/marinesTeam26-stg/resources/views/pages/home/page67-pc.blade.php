@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile"> 
        Mポイント｜Mポイント受取（補助券）
      </div>
      <section class="site-page67 pd-main">
        <div class="text-left">
          <div class="contents_right">
            <h2 class="t2">Mポイントの付与が完了しました。<br />
              @if(!is_null($gameDate) && $gameDate !== "null")
              試合日は{{ $gameDate }}です。<br />
              @endempty
            Mポイントの詳細は会員履歴内Mポイント実績にてご確認ください。</h2>
            <p></p>

            <div class="btn">
              <a class="btn-custom btn-custom-icon" href="{{ route_path('mypage.history.point')}}" target="_parent">
                <span>Mポイント実績はこちら</span>
              </a>
              <a class="btn-custom btn-back" style="margin-top: 20px;" href="/mypage/point/grant"><span>Mポイントへもどる</span></a>
            </div>
          </div>
    </section>
    </div>
  </section>
  <style>
    .contents_right{
      max-width: 90%;
      margin:0 auto;
    }
    .btn{
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
    }
  </style>
</main>
@endsection
