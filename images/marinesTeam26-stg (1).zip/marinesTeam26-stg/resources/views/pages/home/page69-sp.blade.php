@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-tab')
<section class="site-tab">
    <div class="container">
        <ul>
            <li><a href="{{ route_path('mypage.mission.monthly') }}">月間</a></li>
            <li class="active"><a href="{{ route_path('mypage.mission.special') }}">特別</a></li>
        </ul>
    </div>
</section>
@endsection
@section('site-mission-page')
	<div class="site-mission site-mission-page misstion-page pd-main site-history-member">
		<div class="history-content">
	        <div class="calendar">
	          <select name="" id="year">
                <option value="">----</option>
	            
	          </select>
	        </div>
	    </div>
        <div class="list-content">
            <div class="mission">
                <div class="container">
                    <div class="row" id="mission-special">
                        <div class="content text-center w-100">
                            <p><strong>ミッションはありません。</strong></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script type="text/javascript" src="/mypage/js/sp/page69.js"></script>
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
