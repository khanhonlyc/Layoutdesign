@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom page-profile-customer site-uniform-font">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile">
        会員情報｜マイユニホーム
      </div>
      <section class="site-tab">
        <div class="container">
          <ul>
            <li><a href="{{ route_path('mypage.profile.customer.index') }}">基本情報</a></li>
            <li><a href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手登録</a></li>
            <li  class="active"><a href="{{ route_path('mypage.profile.uniform.index') }}">マイユニホーム</a></li>
          </ul>
        </div>
      </section>
      <section class="site-information-page site-uniform-page">
        <div class="container">
          <div class="row">
            <div class="col-md-4">
              <div class="table-information">
                <h2>変更後のマイユニホーム</h2>
                <div class="images-products">
                  <img class="w-100 d-block" src="/mypage/images/sp.png" alt="">
                  <div class="block-uniform">
                    <div id="js_Name2" class="txt-name">{{ $request->name }}</div>
                    <div id="js_Number2" class="txt-number">{{ $request->number }}</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-8">
              <div class="table-information">
                <h2>マイユニホームの登録・変更</h2>
                <div class="uniform-form">
                <form class="table-member" action="{{ route_path('mypage.profile.uniform.complete') }}" method="POST" id="post_uniform">
                  @csrf
                  <table>
                    <tr>
                      <td>ネーム表記</td>
                      <td>
                        <strong>{{ $request->name }}</strong>
                        <input type="hidden" name="name" value="{{ $request->name }}">
                      </td>
                    </tr>
                    <tr>
                      <td>背番号表記</td>
                      <td>
                        <strong>{{ $request->number }}</strong>
                        <input type="hidden" name="number" value="{{ $request->number }}">
                      </td>
                    </tr>
                    <!-- <tr>
                      <td>お気に入り選手で設定する</td>
                      <td> {{ $request->favorite }} </td>
                    </tr> -->
                  </table>
                  <input type="hidden" name="amcno">
                  <div class="button m-0">
                    <a class="btn-custom btn-custom-icon" href="javascript:{}" onclick="document.getElementById('post_uniform').submit();">変更する</a>
                  </div>
                </form>
                </div>
              </div>
              <a class="btn-custom btn-back" href="{{ route_path('mypage.profile.uniform.index', ['name'=>$request->name, 'number'=>$request->number]) }}">もどる</a>
            </div>
          </div>
        </div>
      </section>
    </div>
  </section>
</main>
@endsection
