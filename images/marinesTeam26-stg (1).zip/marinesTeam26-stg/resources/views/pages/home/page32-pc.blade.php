@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom page-profile-customer">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile">
        会員情報｜お気に入り選手登録
      </div>
      <section class="site-tab">
        <div class="container">
          <ul>
            <li><a href="{{ route_path('mypage.profile.customer.index') }}">基本情報</a></li>
            <li class="active"><a href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手登録</a></li>
            <li><a href="{{ route_path('mypage.profile.uniform.index') }}">マイユニホーム</a></li>
          </ul>
        </div>
      </section>
      <section class="site-res-page">
        <div class="container">
          <div class="content">
            <p>「お気に入り選手」を以下のように変更いたします。</p>
          </div>
        </div>
      </section>
      <section class="site-information-page">
        <div class="container">
          <div class="table-information box-member-play member-change p-0 m-0">
            <h2 class="text-left">お気に入り選手の変更</h2>
            <div class="list-member-play">
              <div class="row">
                <div class="col-md-4">
                  <div class="items" id="favorite-1">
                    <input type="hidden" name="confirm_favorite1" value="{{ request()->favorite1 }}">
                    <h3>お気に入り選手　１人目</h3>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="items" id="favorite-2">
                    <input type="hidden" name="confirm_favorite2" value="{{ request()->favorite2 ? request()->favorite2 : '9999998' }}">
                    <h3>お気に入り選手　２人目</h3>
                  </div>
                </div>
                <div class="col-md-4">
                  <div class="items" id="favorite-3">
                    <input type="hidden" name="confirm_favorite3" value="{{ request()->favorite3 && request()->favorite3 != '9999999'  ? request()->favorite3 : '9999999' }}">
                    <h3>お気に入り選手　３人目</h3>
                  </div>
                </div>
              </div>
            </div>
            <a class="btn-custom btn-custom-icon" id="btn-post-favorite" style="border-color: #D12B63; background-color: #D12B63; color: #fff;" href="javascript:void(0);">変更する</a>
          </div>
          <a class="btn-custom btn-back" href="{{ route_path('mypage.profile.favorite.index') }}">もどる</a>
        </div>
      </section>
    </div>
  </section>
</main>
<script type="text/javascript">
  var rqFavorite1 = '{{ request()->favorite1 }}';
  var rqFavorite2 = '{{ request()->favorite2 }}';
  var rqFavorite3 = '{{ request()->favorite3 }}';
</script>
<script type="text/javascript" src="/mypage/js/pc/page32.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
