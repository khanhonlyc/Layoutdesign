@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom">
    <div class="container">
      <div class="row">
        @include('parts.frontend.sidebar-left')
        <div class="col-md-6nh">
          <section class="site-tab site-tab-infor">
            <div class="container">
              <ul>
                <li><a href="#">申込受付</a></li>
                <li class="active"><a href="#">申込済み</a></li>
                <li><a href="#">申込締切</a></li>
              </ul>
            </div>
          </section>
          <section class="site-infor-event site-infor-event-single">
            <div class="container">
              <div class="text" style="margin-bottom:40px;">
                <p>当選の連絡はTEAM26マイページ内機能、ダイレクトメッセージにてお知らせいたします。</p>
              </div>
              <div class="infor-event">
                <h3 class="heading">7/31(日)ちば興銀プレゼンツ<br>TEAM26練習見学会</h3>
                <div class="single-event">
                  <div class="items">
                    <label>受付期間</label>
                    <p><strong>2000/00/00 00:00 - 2000/00/00 00:00</strong></p>
                  </div>
                  <div class="items">
                    <label>開催日時</label>
                    <p><strong>2000/00/00 00:00</strong></p>
                  </div>
                  <div class="items">
                    <label>開催場所</label>
                    <p><strong>試合開始前 グラウンド上</strong></p>
                  </div>
                  <div class="items">
                    <label>内容</label>
                    <p><strong>開場前にマリーンズ選手の練習の様子をバックネット裏からご覧いただけます。</strong></p>
                  </div>
                  <div class="items">
                    <label>参加対象</label>
                    <p><strong>当日の試合を観戦される<br>
                        2022年度TEAM26会員有料会員50組200名</strong></p>
                  </div>
                  <div class="items">
                    <label>当選人数</label>
                    <p><strong>4名</strong></p>
                  </div>
                  <div class="items">
                    <label>日時</label>
                    <p><strong>7月31日（日）14:00 ～14:30</strong></p>
                  </div>
                  <div class="items">
                    <label>応募締め切り</label>
                    <p><strong>7月27日（水）</strong></p>
                  </div>
                  <div class="items">
                    <label>当選発表</label>
                    <p><strong>7月28日(木)</strong></p>
                    <p>※当選者のみマイページ内ダイレクトメッセージでお知らせします。<br>
                      ※集合場所等の詳細は当選者のみにお知らせします。</p>
                  </div>
                  <div class="items">
                    <label>注意事項</label>
                    <p>・募集人数は変更になる場合があります。<br>
                      ※当選したTEAM26有料会員本人と同伴3名までご参加いただけます。<br>
                      ※当選権利を第三者に譲渡することはできません。<br>
                      ※天候や新型コロナウイルス感染拡大などの理由により、予告なくイベントが中止、変更となる場合があります。<br>
                      ※チームの練習時間および練習場所により開催時間の変更や開催自体が中止となる場合があります。<br>
                      ※イベントの様子の写真や映像が球団の公式制作物などに使用される場合があります。<br>
                      ※マスクは必ず着用してください。<br>
                      ※ZOZOマリンスタジアムの「新型コロナウイルス感染防止対策」をご覧いただき、感染症対策を行ったうえでご参加ください。<br>
                      ※当日の観戦チケットはご自身でご準備をお願いします。試合観戦のご招待はありません。<br>
                      ※本イベントはスタンドからの練習見学です。選手との記念撮影はできません。</p>
                  </div>
                </div>
              </div>
              <a class="btn-custom btn-back" href="#">もどる</a>
            </div>
          </section>
        </div>
        @include('parts.frontend.sidebar-right')
      </div>
    </div>
  </section>
</main>
@endsection
