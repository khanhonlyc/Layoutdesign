@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-tab')
@include('parts.frontend.inner.site-tab')
@endsection
@section('site-res-page')
<section class="site-res-page">
    <div class="container">
        <div class="content">
            <p>「お気に入り選手」を登録できます。<br>
            登録変更は何度でも可能です。該当する選手がいない場合<br>
        は「未選択」を選択してください</p>
        </div>
    </div>
</section>
@endsection
@section('site-information-page')
@include('parts.frontend.site-banner-birthday')
<section class="site-information-page">
    <div class="container">
        <div class="table-information box-member-play">
            <h2>現在のお気に入り選手</h2>
            <div class="list-member-play">
                <div class="items">
                    <div class="number">No. <span>1</span></div>
                    <div class="items-img" id="favorite-1">
                        <img src="/mypage/images/user-defeaut.png" alt=""><div class="text"><h3 class="player-name_1">未選択</h3></div>
                    </div>
                </div>
                <div class="items">
                    <div class="number">No. <span>2</span></div>
                    <div class="items-img" id="favorite-2">
                        <img src="/mypage/images/user-defeaut.png" alt=""><div class="text"><h3 class="player-name_2">未選択</h3></div>
                    </div>
                </div>
                <div class="items">
                    <div class="number">No. <span>3</span></div>
                    <div class="items-img" id="favorite-3">
                        <img src="/mypage/images/user-defeaut.png" alt=""><div class="text"><h3 class="player-name_3">未選択</h3></div>
                    </div>
                </div>
            </div>
        </div>
        <form class="table-information box-member-play" method="POST" action="{{ route_path('mypage.profile.favorite.confirm') }}" id="post-favorite">
            @csrf
            <h2>お気に入り選手の登録・変更</h2>
            <div class="list-member-play">
                <div class="items">
                    <div class="number">No. <span>1</span></div>
                    <select class="form-control player-list" name="favorite1" id="" required>
                        <option value="">選択してください</option>
                    </select>
                </div>
                <div class="items">
                    <div class="number">No. <span>2</span></div>
                    <select class="form-control player-list1" name="favorite2" id="">
                        <option value="9999998">選択してください</option>
                    </select>
                </div>
                <div class="items">
                    <div class="number">No. <span>3</span></div>
                    <select class="form-control player-list2" name="favorite3" id="">
                        <option value="9999999">選択してください</option>
                    </select>
                </div>
            </div>
            <a class="btn-custom btn-custom-icon" href="javascript:void(0)" onclick="checkFavorite();">登録・変更の確認</a>
        </form>
          <!-- <div class="text-center">
            <p class="mt-4 font-weight-bold">
            2023年度の「お気に入り選手登録」は<br>4月7日（金）公開予定です。<br>
            公開までしばらくお待ちください。</p>
          </div> -->
          <a class="btn-custom btn-custom-icon" href="/mypage/">ホームへもどる</a>
        </div>
    </div>
</section>
<script type="text/javascript" src="/mypage/js/sp/page31.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
