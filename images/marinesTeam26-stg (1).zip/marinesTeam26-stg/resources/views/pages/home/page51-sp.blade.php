@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-tab-infor')
@include('parts.frontend.inner.site-tab-infor')
@endsection
@section('site-infor-event-single')
<section class="site-infor-event site-infor-event-single">
	<div class="container">
	    <div class="title">
	        <p>イベント参加へのお申込みありがとうございました。
	        当選の連絡はTEAM26マイページ内機能ダイレクトメッセージにてお知らせいたします。</p>
	    </div>
	    <a class="btn-custom btn-back" href="{{ route_path('mypage.event.index') }}">イベント一覧画面にもどる</a>
	</div>
</section>
<script type="text/javascript" src="/mypage/js/sp/page51.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
