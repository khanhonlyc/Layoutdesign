@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile"> 
        ガイドブック
      </div>
      <section class="site-qa">
        <div class="container">
          <div class="content_qa m-0">
            <div class="content_qa" style="box-shadow:none;" id="guidebook-html">

            </div>
          </div>
        </div>
      </section>
    </div>
  </section>
</main>
@endsection
