@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-tab')
@include('parts.frontend.inner.site-tab')
@endsection
@section('site-res-page')
@include('parts.frontend.inner.site-res-page')
@endsection
@section('site-information-page')
<section class="site-information-page">
<div class="container">
  <p class="text-danger" id="mess-error"></p>
  <form action="{{ route_path('mypage.profile.customer.confirm') }}" method="POST" id="post_customer">
    <input class="form-control" name="token_api" type="text" value="" hidden>
    <input class="form-control" name="book_chk" type="text" value="" hidden>
    <input class="form-control" name="email_old" type="text" value="" hidden>
    @csrf
    <div class="table-information">
      <h2>基本情報更新</h2>
      <table class="table">
        <tr>
          <td>マリーンズID</td>
          <td class="amc-no"></td>
          <input class="form-control" name="amcNo" type="text" value="" hidden>
        </tr>
        <tr>
          <td>フリガナ</td>
          <td class="name-kana"></td>
          <input class="form-control" name="name_kana" type="text" value="" hidden>
        </tr>
        <tr>
          <td>お名前</td>
          <td class="name"></td>
          <input class="form-control" name="name" type="text" value="" hidden>
        </tr>
        <tr>
          <td>性別</td>
          <td>
            <select class="form-select sex" name="sex">
              <option value="0">男性</option>
              <option value="1">女性</option>
            </select>
          </td>
        </tr>
        <tr>
          <td>生年月日</td>
          <td class="birth-day"></td>
          <input class="form-control" name="birthDay" type="text" value="" hidden>
        </tr>
          <tr>
            <td>送付先会員番号</td>
            <td>
              <input class="form-control deliv-fan-no" name="delivFanNo" type="text" value="{{ old('delivFanNo') }}" placeholder="89から始まる10桁の番号">
              @if ($errors->has('delivFanNo'))
                <div class=" text-left"><span class="text-danger">{{ $errors->first('delivFanNo') }}</span></div>
              @endif
              <p>※送付先会員番号を入力される場合は、 電話番号、郵便番号、住所は入力不要です。</p>
            </td>
          </tr>
        <tr>
          <td>送付先お名前</td>
          <td>
            <div class="flex-form">
              <input class="form-control deliv-last-name" type="text" name="delivLastName" value="{{ old('delivLastName') }}" placeholder="姓">
              <span></span>
              <input class="form-control deliv-first-name" type="text" name="delivFirstName" value="{{ old('delivFirstName') }}" placeholder="名">
            </div>
            @if ($errors->has('delivLastName') || $errors->has('delivFirstName'))
              <div class=" text-left"><span class="text-danger">{{ $errors->first('delivLastName') ? $errors->first('delivLastName') : $errors->first('delivFirstName') }}</span></div>
            @endif
          </td>
        </tr>
        <tr>
          <td>送付先電話番号</td>
          <td>
            <div class="flex-form">
              <input class="form-control deliv-tel-no-1" type="text" name="delivTelNo1" value="{{ old('delivTelNo1') }}" placeholder="043">
              <span>-</span>
              <input class="form-control deliv-tel-no-2" type="text" name="delivTelNo2" value="{{ old('delivTelNo2') }}" placeholder="000">
              <span>-</span>
              <input class="form-control deliv-tel-no-3" type="text" name="delivTelNo3" value="{{ old('delivTelNo3') }}" placeholder="0000">
            </div>
            @if ($errors->has('delivTelNo1') || $errors->has('delivTelNo2') || $errors->has('delivTelNo3'))
              <div class=" text-left"><span class="text-danger">{{ $errors->first('delivTelNo1') ? $errors->first('delivTelNo1') : ($errors->first('delivTelNo2') ? $errors->first('delivTelNo2') : $errors->first('delivTelNo3')) }}</span></div>
            @endif
          </td>
        </tr>
          <tr>
          <td>電話番号</td>
          <td>
            <div class="flex-form">
              <input class="form-control" name="telNo1" type="text" value="{{ old('telNo1') }}">
              <span>-</span>
              <input class="form-control" name="telNo2" type="text" value="{{ old('telNo2') }}">
              <span>-</span>
              <input class="form-control" name="telNo3" type="text" value="{{ old('telNo3') }}">
            </div>
            @if ($errors->has('telNo1') || $errors->has('telNo2') || $errors->has('telNo3'))
              <div class=" text-left"><span class="text-danger">{{ $errors->first('telNo1') ? $errors->first('telNo1') : ($errors->first('telNo2') ? $errors->first('telNo2') : $errors->first('telNo3')) }}</span></div>
            @endif
          </td>
        </tr>
        <tr>
          <td>郵便番号</td>
          <td>
            <div class="flex-form">
              <input class="form-control" name="zipCode1" type="text" value="{{ old('zipCode1') }}">
              <span>-</span>
              <input class="form-control" name="zipCode2" value="{{ old('zipCode2') }}">
            </div>
            <a class="btn-custom btn-custom-icon btn-form" href="javascript:void(0)" id="searchZip" onclick="searchZipCode()">住所検索</a>
            @if ($errors->has('zipCode1') || $errors->has('zipCode2'))
              <div class=" text-left"><span class="text-danger">{{ $errors->first('zipCode1') ? $errors->first('zipCode1') : $errors->first('zipCode2') }}</span></div>
            @endif
          </td>
        </tr>
        <tr>
          <td>自宅住所</td>
          <td>
            <select class="form-select" id="select-address" name="address1">

            </select>
            <input class="form-control" type="text" name="address1_text" value="" hidden>
            <input class="form-control" type="text" name="address2" value="{{old('address2')}}">
            <p class="addressMention"><span class="addressAtt" style="color:#D12B63;">[必須]</span>市区郡（全角10文字以内）　例）千葉市</p>
            <input class="form-control" type="text" name="address3" value="{{old('address3')}}">
            <p class="addressMention"><span class="addressAtt" style="color:#D12B63;">[必須]</span>町名（全角20文字以内）　例）美浜区美浜</p>
            <input class="form-control" type="text" name="address4" value="{{old('address4')}}">
            <p class="addressMention"><span class="addressAtt" style="color:#D12B63;">[必須]</span>番地（全角20文字以内）　例）３－５－１０</p>
            <input class="form-control" type="text" name="address5" value="{{old('address5')}}" placeholder="マンション・アパート名 部屋番号">
            <p class="addressMention">マンション・アパート名（全角20文字以内）　例）マリンマンション１０１号</p>
            @if ($errors->has('address1') || $errors->has('address2') || $errors->has('address3') || $errors->has('address4') || $errors->has('address5'))
              <div class=" text-left"><span class="text-danger">{{ $errors->first('address1') ? $errors->first('address1') : ($errors->first('address2') ? $errors->first('address2') : ($errors->first('address3') ? $errors->first('address3') : ($errors->first('address4') ? $errors->first('address4') : $errors->first('address5')))) }}</span></div>
            @endif
          </td>
        </tr>
        <tr>
          <td>メールアドレス</td>
          <td>
            <input class="form-control email-info" name="email" type="text" value="{{old('email')}}" {{ old('emailChange') ? '' : 'readonly="readonly"' }}>
            @if ($errors->has('email'))
              <div class=" text-left"><span class="text-danger">{{ $errors->first('email') }}</span></div>
            @endif
            <div class="confirm-email">
              <span class="confirm">確認用</span>
              <input class="form-control" name="emailConf" type="text" value="{{old('emailConf')}}" {{ old('emailChange') ? '' : 'readonly="readonly"' }}>
              @if ($errors->has('emailConf'))
                <div class=" text-left"><span class="text-danger">{{ $errors->first('emailConf') }}</span></div>
              @endif
            </div>
            <div class="form-check"><input class="form-check-input" name="emailChange" type="checkbox" value="1" id="changeEmail" {{ old('emailChange') ? 'checked' : '' }}><label class="form-check-label" for="changeEmail">メールアドレスを変更</label></div>
          </td>
        </tr>
        <tr>
          <td>パスワード</td>
          <td>
            <input class="form-control" type="password" name="fanPassword" value="" {{ old('passChange') ? '' : 'readonly="readonly' }}>
            @if ($errors->has('fanPassword'))
            <div class=" text-left"><span class="text-danger">{{ $errors->first('fanPassword') }}</span></div>
            @else
            <p>※半角英数を含む8桁以上20桁以下</p>
            @endif
            <div class="confirm-email">
              <span class="confirm">確認用</span>
              <input class="form-control" type="password" name="fanPasswordConf" value="" {{ old('passChange') ? '' : 'readonly="readonly' }}>
              @if ($errors->has('fanPasswordConf'))
                <div class=" text-left"><span class="text-danger">{{ $errors->first('fanPasswordConf') }}</span></div>
              @endif
            </div>
            <div class="form-check"><input class="form-check-input" name="passChange" type="checkbox" value="1" id="changePass" {{ old('passChange') ? 'checked' : '' }}><label class="form-check-label" for="changePass">パスワードを変更する</label></div>
          </td>
        </tr>
        <tr>
          <td>現在のパスワード</td>
          <td>
            <input class="form-control" type="password" name="fanPasswordCurrent" value="{{ old('fanPasswordCurrent') }}">
            @if ($errors->has('fanPasswordCurrent'))
              <div class=" text-left"><span class="text-danger">{{ $errors->first('fanPasswordCurrent') }}</span></div>
            @endif
            <p>※「マイページ用パスワード」を更新する際には入力が必要です。</p>
          </td>
        </tr>
      </table>
      <div class="content">
        <div class="pp">
          <div class="email">
            <i class="fa-regular fa-envelope"></i>
            <span>マリーンズメルマガの配信</span>
          </div>
          <div class="check">
            <label>
              <input type="checkbox" name="mailMagazine" class="mailMagazine" value="1" {{ old('mailMagazine') == 1 ? 'checked' : '' }}> 配信する </label>
          </div>
        </div>
        <div class="button">
          <a class="btn-custom btn-custom-icon" href="javascript:$('#post_customer').submit();">更新内容の確認はこちら</a>
        </div>
      </div>
    </div>
    <a class="btn-custom btn-back" href="javascript: history.go(-1)">もどる</a>
  </form>
</div>
<div class="modal-container modal-container-nh">
  <div class="modal-body">
    <div class="modal-close">×</div>
    <div class="modal-content">
      <h3>登録情報の入力時には下記に関してご注意ください。</h3>
      <p>難しい漢字の場合はなるべく略字で入力してください。</p>
      <p>下記のような入力できない文字は、変換の上入力してください。</p>
      <img src="/mypage/images/cation.png">
    </div>
  </div>
</div>
</section>
<script type="text/javascript">
  var oldAdress = "{{old('address1') ? old('address1') : 0}}"
  var oldAmcno = "{{ old('amcNo') ? 1 : 0 }}"
</script>
<script type="text/javascript" src="/mypage/js/sp/page28.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
<style type="text/css">
/*モーダル本体の指定 + モーダル外側の背景の指定*/

</style>
@endsection
