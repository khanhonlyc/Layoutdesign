@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom page-profile-customer">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile">
        会員履歴｜Mポイント実績
      </div>
      <section class="site-tab">
        <div class="container">
          <ul>
            <li class="active"><a href="{{ route_path('mypage.history.point') }}">Mポイント実績</a></li>
            <li><a href="{{ route_path('mypage.history.visit') }}">来場履歴</a></li>
            <li><a href="{{ route_path('mypage.history.ticket') }}">チケット購入履歴</a></li>
            <li><a href="{{ route_path('mypage.history.privilege') }}">来場特典配布</a></li>
          </ul>
        </div>
      </section>
      <section class="site-history-member pd-main">
        <div class="container">
          <div class="history-member">
            <div class="row">
              <div class="col-6">
                <div class="items-history">
                  <div class="content-top">
                    <h3>残Mポイント</h3>
                    <div class="mpt"><span class="sum-point-m"></span> Mpt</div>
                  </div>
                  <div class="row m-0">
                    <div class="col-6 p-0">
                      <div class="items-history items-history-content" style="border:0">
                        <h3>{{ \Carbon\Carbon::now()->year }}年度 残Mポイント</h3>
                        <div class="content">
                          <div class="mpt"><span class="m-point-{{ \Carbon\Carbon::now()->year }}"></span> Mpt</div>
                          <p>(<span class="m-date-{{ \Carbon\Carbon::now()->year }}"></span>まで有効)</p>
                        </div>
                      </div>
                    </div>
                    <div class="col-6 p-0">
                      <div class="items-history items-history-content">
                        <h3>{{ \Carbon\Carbon::now()->year - 1 }}年度 残Mポイント</h3>
                        <div class="content">
                          <div class="mpt"><span class="m-point-{{ \Carbon\Carbon::now()->year - 1 }}"></span> Mpt</div>
                          <p>(<span class="m-date-{{ \Carbon\Carbon::now()->year - 1 }}"></span>まで有効)</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-6">
                <div class="items-history">
                  <div class="content-top">
                    <h3>ステージポイント</h3>
                    <div class="mpt"><span class="sum-point-stage"></span> Mpt</div>
                  </div>
                  <div class="row m-0">
                    <div class="col-6 p-0">
                      <div class="items-history items-history-content" style="border:0">
                        <h3>{{ \Carbon\Carbon::now()->year }}年度 ステージポイント</h3>
                        <div class="content">
                          <div class="mpt"><span class="stage-point-{{ \Carbon\Carbon::now()->year }}"></span> Mpt</div>
                          <p>(<span class="stage-date-{{ \Carbon\Carbon::now()->year }}"></span>まで有効)</p>
                        </div>
                      </div>
                    </div>
                    <div class="col-6 p-0">
                      <div class="items-history items-history-content">
                        <h3>{{ \Carbon\Carbon::now()->year - 1 }}年度 ステージポイント</h3>
                        <div class="content">
                          <div class="mpt"><span class="stage-point-{{ \Carbon\Carbon::now()->year - 1 }}"></span> Mpt</div>
                          <p>(<span class="stage-date-{{ \Carbon\Carbon::now()->year - 1 }}"></span>まで有効)</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
          <div class="history-content">
            <div class="content__text">
              <p>マリーンズID認証済みのQRチケットで入場後、来場ポイントが反映されるまで数分かかる場合があります</p>
            </div>
            <div class="calendar">
              <select name="" id="year">
                @for ($i = 2006; $i < 2024; $i++)
                <option value="{{ $i }}" {{ \Carbon\Carbon::now()->year == $i ? 'selected' : '' }}>{{ $i }}年</option>
                @endfor
              </select>
              <select name="" id="month">
                <option value="">----</option>
                @for ($i = 1; $i < 13; $i++)
                <option value="{{ $i }}">{{ $i }}月</option>
                @endfor
              </select>
            </div>
          </div>
          <div class="table-history table-history-nh-custom">
            <div class="table">
              <div class="table-header">
                <ul>
                  <li>発生日</li>
                  <li>Mポイント種別</li>
                  <li>Mポイント</li>
                </ul>
              </div>
              <div class="content">
                <ul class="list-rec-point">
                  <span>Mポイントの実績はありません</span>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="site-history-member pd-main" style="padding: 0px;">
        <div class="container list-modal">
        </div>
      </section>
    </div>
  </section>
</main>
<script type="text/javascript" src="/mypage/js/pc/page37.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
