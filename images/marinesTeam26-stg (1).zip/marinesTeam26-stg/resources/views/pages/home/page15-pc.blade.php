@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile">
        WEB引換コード
      </div>
      <section class="site-code pd-main">
        <div class="container">
          <div class="code-container">
            <div class="items-code">
              <h3 class="title">使用可能引換コード</h3>
              <div class="content un-used-exchange-code-list">

              </div>
            </div>
            <p class="t-code">WEB引換券のご利用方法や引換券の対象日程については公式ホームページ内ファンクラブ情報のよくある質問にてご確認ください。</p>
            <p class="t-code-2">8月1日(火)以降にステージアップ特典およびお友達紹介特典としてお渡ししている一部指定席引換券(平日・一部休日使用可能)のみ、今シーズン終了までに使用実績がなかった場合は2024シーズンに繰り越して使用が可能です。</p>
            <a class="btn-custom" style="margin:60px auto" href="https://www.marines.co.jp/fanclub/benefits/exchangeticket-redirect" target="_blank">WEB引換コードのご利用方法はこちら</a>
          </div>
          <div class="code-use">
            <div class="items-code">
              <h3 class="title">使用済み引換コード</h3>
              <div class="content used-exchange-code-list">

              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </section>
</main>
<script type="text/javascript" src="/mypage/js/pc/page15.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
