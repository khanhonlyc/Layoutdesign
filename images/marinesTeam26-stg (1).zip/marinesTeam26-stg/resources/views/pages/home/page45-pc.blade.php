@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom page-profile-customer">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile">
        会員履歴｜チケット購入履歴
      </div>
      <section class="site-tab">
        <div class="container">
          <ul>
            <li><a href="{{ route_path('mypage.history.point') }}">Mポイント実績</a></li>
            <li><a href="{{ route_path('mypage.history.visit') }}">来場履歴</a></li>
            <li class="active"><a href="{{ route_path('mypage.history.ticket') }}">チケット購入履歴</a></li>
            <li><a href="{{ route_path('mypage.history.privilege') }}">来場特典配布</a></li>
          </ul>
        </div>
      </section>
      <section class="site-history-member pd-main">
        <div class="container">
          <div class="history-content">
            <div class="content__text">
              <p>※Ｍチケットオンラインでのご予約の確認は、下記の購入履歴情報から、Ｍチケットオンライン内の「マイチケット＞購入チケット」にてご確認ください。（試合終了後30日を過ぎたは表示されません。）</p>
              <p>※Ｍチケットオンライン TEAM26、カモメの窓口、マリーンズカスタマーサービスにて購入された、Ｍポイント加算対象チケットのみの表示となります。</p>
              <p>※購入されてからこのページに反映されるまで1週間程度かかる場合がございます。</p>
            </div>
            <div class="calendar">
              <select name="" id="year">
                @for ($i = 2006; $i < 2024; $i++)
                <option value="{{ $i }}" {{ \Carbon\Carbon::now()->year == $i ? 'selected' : '' }}>{{ $i }}年</option>
                @endfor
              </select>
              <select name="" id="month">
                <option value="">----</option>
                @for ($i = 1; $i < 13; $i++)
                <option value="{{ $i }}">{{ $i }}月</option>
                @endfor
              </select>
            </div>
          </div>
          <div class="table-history table-history-page45">
            <div class="table">
              <div class="table-header">
                <ul>
                  <li>購入日</li>
                  <li>試合日時・対戦相手・球場</li>
                  <li>チケット種別</li>
                </ul>
              </div>
              <div class="content content-house content-house-details ticket-list">
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </section>
</main>
<script type="text/javascript" src="/mypage/js/pc/page45.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
