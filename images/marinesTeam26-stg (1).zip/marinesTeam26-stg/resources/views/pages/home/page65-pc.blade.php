@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile"> 
        Mポイント | 補助券登録
      </div>
      <section class="site-page65 pd-main">
        <div class="container">
          <p class="text text-center">QRコード下部に書かれている <br> 6桁のコードを入力してください。</p>
          <form action="">
            <input class="form-control" type="text" placeholder="例）012345">
            <button class="btn-custom" type="submit">登録</button>
          </form>
        </div>
      </section>
    </div>
  </section>
</main>
@endsection
