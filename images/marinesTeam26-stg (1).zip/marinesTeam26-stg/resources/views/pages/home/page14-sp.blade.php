@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-marines--video')
<section class="site-marines site-video pd-main">
    <div class="title title1">
        <img src="/mypage/images/m1.png" alt="">
    </div>
    <div class="container">
        <div class="">
            <div class="items items-news-archive">
                <div class="images">
                    {!! $info->sauce !!}
                </div>
                <h3>{{ $info->title }}</h3>
                <p>@foreach ($info->tag_movies as $tag_movie) {{$tag_movie->tag ? $tag_movie->tag->tag_name : ''}} @endforeach</p>
            </div>
        </div>
        <a class="btn-custom btn-custom-bg" href="{{ route_path('mypage.movie.index')}}">もどる</a>
    </div>

</section>
@endsection
@section('site-search')
@include('parts.frontend.inner.site-search')
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
