@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-infor-event')
<section class="site-infor-event">
    <div class="container">
        <div class="title text-center">
            <p class="notifi-data">下記のアンケートをただいま受付中です！<br>
            ご協力よろしくお願いします。</p>
        </div>
        <div class="infor-event infor-what">
            <ul class="list-vote">

            </ul>
        </div>
    </div>
    
</section>
<script type="text/javascript" src="/mypage/js/sp/page60.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
