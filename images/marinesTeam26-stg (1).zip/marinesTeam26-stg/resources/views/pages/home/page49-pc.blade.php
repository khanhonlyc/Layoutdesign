@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom page-profile-customer">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile">
        イベント情報｜{{ $typeEvent }}
      </div>
      <section class="site-tab site-tab-infor">
        <div class="container">
          <ul>
            <li class="{{ $typeEvent == '申込受付' ? 'active' : '' }}"><a href="{{ route_path('mypage.event.index') }}">申込受付</a></li>
            <li class="{{ $typeEvent == '申込済み' ? 'active' : '' }}"><a href="{{ route_path('mypage.event.applied') }}">申込済み</a></li>
            <li class="{{ $typeEvent == '申込締切' ? 'active' : '' }}"><a href="{{ route_path('mypage.event.close') }}">申込締切</a></li>
            <li class="{{ $typeEvent == '開催済み' ? 'active' : '' }}"><a href="{{ route_path('mypage.event.performed') }}">開催済み</a></li>
          </ul>
        </div>
      </section>
      <section class="site-infor-event site-infor-event-single">
        <div class="container">
          @if ($typeEvent != '開催済み')
            @if ($typeEvent == '申込受付')
            <div class="title">
                <p>以下の項目を確認して申し込むボタンを押してください。</p>
            </div>
            @else
            <div class="title">
                <p>当選の連絡はTEAM26マイページ内機能、ダイレクトメッセージにてお知らせいたします。</p>
            </div>
            @endif
          @endif
          <div class="infor-event">
            <h3 class="heading event-title"></h3>
            <h4 class="note" style="display: none;"></h4>
            <div class="single-event">
              <table>
                <tr>
                  <td>受付期間</td>
                  <td><p><strong><span class="start-time"></span> - <span class="end-time"></span></strong></p></td>
                </tr>
                <tr>
                  <td>開催日時</td>
                  <td><p><strong class="event-time"></strong></p></td>
                </tr>
                <tr>
                  <td>開催場所</td>
                  <td><p><strong class="event-place"></strong></p></td>
                </tr>
                <tr>
                  <td>内容</td>
                  <td><p class="event-detail"></p></td>
                </tr>
                <tr class="display-point d-none">
                  <td>使用ポイント</td>
                  <td><p class="event-point"></p></td>
                </tr>
              </table>
            </div>
            <a class="btn-custom btn-custom-icon btn-confirm" href="{{ route_path('mypage.event.confirm', $id) }}">イベントに申し込む</a>
          </div>
          @switch($typeEvent)
              @case('申込済み')
                  <a class="btn-custom btn-back" href="{{ route_path('mypage.event.applied') }}">もどる</a>
                  @break

              @case('申込締切')
                  <a class="btn-custom btn-back" href="{{ route_path('mypage.event.close') }}">もどる</a>
                  @break

              @case('開催済み')
                  <a class="btn-custom btn-back" href="{{ route_path('mypage.event.performed') }}">もどる</a>
                  @break

              @default
                  <a class="btn-custom btn-back" href="{{ route_path('mypage.event.index') }}">もどる</a>
          @endswitch
        </div>
      </section>
    </div>
  </section>
</main>
<script type="text/javascript">
  var eventId = "{{$id}}";
  var eventType = "{{$typeEvent}}"
</script>
<script type="text/javascript" src="/mypage/js/pc/page49.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
