@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-tab')
@include('parts.frontend.inner.site-tab')
@endsection
@section('site-res-page')
<section class="site-res-page">
    <div class="container">
        <div class="content">
            <p>「お気に入り選手」を以下のように変更いたします。</p>
        </div>
    </div>
</section>
@endsection
@section('site-information-page')
<section class="site-information-page">
    <div class="container">
        <div class="table-information member-change">
            <h2>お気に入り選手の変更</h2>
                <div class="list-member-play">
                  <div class="items" id="favorite-1">
                    <input type="hidden" name="favorite1" value="{{ request()->favorite1 }}">
                    <div class="number">No. <span>1</span></div>
                  </div>
                  <div class="items" id="favorite-2">
                    <input type="hidden" name="favorite2" value="{{ request()->favorite2 ? request()->favorite2 : '9999998' }}">
                    <div class="number">No. <span>2</span></div>
                  </div>
                  <div class="items" id="favorite-3">
                    <input type="hidden" name="favorite3" value="{{ request()->favorite3 && request()->favorite3 != '9999999' ? request()->favorite3 : '9999999' }}">
                    <div class="number">No. <span>3</span></div>
                  </div>
                </div>
            <a class="btn-custom btn-custom-icon" style="border-color: #D12B63; background-color: #D12B63; color: #fff;" href="javascript:void(0);" id="btn-post-favorite">変更する</a>
        </div>
        <a class="btn-custom btn-back" href="{{ route_path('mypage.profile.favorite.index') }}">もどる</a>
    </div>
</section>
<script type="text/javascript">
  var rqFavorite1 = '{{ request()->favorite1 }}';
  var rqFavorite2 = '{{ request()->favorite2 }}';
  var rqFavorite3 = '{{ request()->favorite3 }}';
</script>
<script type="text/javascript" src="/mypage/js/sp/page32.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
