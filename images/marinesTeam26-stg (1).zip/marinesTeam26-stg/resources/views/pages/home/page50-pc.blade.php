@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom page-event">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile">
        イベント情報｜申込受付
        <div class="items1 display-point">
          <p class="m-0">保有Mポイント</p>
          <span class="point" id="point-saving"><span> Mpt</span></span>
        </div>
      </div>
      <section class="site-tab site-tab-infor">
        <div class="container">
          <ul>
            <li class="active"><a href="{{ route_path('mypage.event.index') }}">申込受付</a></li>
            <li><a href="{{ route_path('mypage.event.applied') }}">申込済み</a></li>
            <li><a href="{{ route_path('mypage.event.close') }}">申込締切</a></li>
            <li><a href="{{ route_path('mypage.event.performed') }}">開催済み</a></li>
          </ul>
        </div>
      </section>
      <section class="site-infor-event site-infor-event-single">
        <div class="container">
          <div class="title">
            <p>登録ボタンを押すと、以下のイベントへの参加申込が完了します。</p>
          </div>
          <div class="infor-event">
            <h3 class="heading event-title"></h3>
            <div class="single-event">
              <table>
                <tr>
                  <td><label>開催日時</label></td>
                  <td><p><strong class="event-time"></strong></p></td>
                </tr>
                <tr>
                  <td><label>開催場所</label></td>
                  <td><p><strong class="event-place"></strong></p></td>
                </tr>
                <tr class="display-point">
                  <td><label>使用ポイント</label></td>
                  <td><p><strong class="event-point"></strong></p></td>
                </tr>
              </table>
            </div>
            <div class="items display-point">
              <p class="m-0">登録後のMポイント</p>
              <span class="point" id="point-calc"><span> Mpt</span></span>
            </div>
            <a class="btn-custom btn-custom-icon" href="javascript:void(0);" id="btn-post-event">登録する</a>
          </div>
          <a class="btn-custom btn-back" href="{{ route_path('mypage.event.show', $id) }}">イベント詳細にもどる</a>
        </div>
      </section>
    </div>
  </section>
</main>
<script type="text/javascript">
  var eventId = "{{$id}}";
</script>
<script type="text/javascript" src="/mypage/js/pc/page50.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
