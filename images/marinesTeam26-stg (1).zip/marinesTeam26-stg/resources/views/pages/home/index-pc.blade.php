@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@php
const NEW_BG_COLOR = [
  "アカデミー" => "#003399",
  "チーム" => "#000",
  "その他" => "#FFCC00",
  "グッズ" => "#FF6666",
  "ファンクラブ" => "#B8A536",
  "イベント" => "#B71649",
  "地域振興" => "#009900",
  "メディア" => "#EE82EE",
];

const SHORT_TEAM_NAME = [
  "1947001" => "巨人",
  "1954001" => "中日",
  "1961001" => "阪神",
  "1968001" => "広島",
  "1992001" => "千葉ロッテ",
  "2004001" => "北海道日本ハム",
  "2005001" => "福岡ソフトバンク",
  "2005002" => "オリックス",
  "2005003" => "楽天イーグルス",
  "2006001" => "東京ヤクルト",
  "2008001" => "埼玉西武",
  "2012001" => "横浜DeNA",
];

$weekMap = [
    0 => '日',
    1 => '月',
    2 => '火',
    3 => '水',
    4 => '木',
    5 => '金',
    6 => '土',
];
$code = 13;
@endphp
@section('main')
<main class="mypage-css">
  <section class="site-login one-time-password-message" style="display: none;">
    <div class="container">
      <div class="content d-flex align-items-center justify-content-evenly">
        <p class="m-0 p-0">ワンタイムパスワードにてログインされました。パスワードの変更を行ってください。</p>
        <a class="btn-custom m-0" href="{{ route_path('mypage.profile.customer.index') }}">パスワードの変更はこちら</a>
      </div>
    </div>
  </section>
  <section class="destop_custom ">
    <div class="container">
      <div class="row">
        @include('parts.frontend.sidebar-left')
        <div class="col-md-6nh">
          <section class="site-album site-banner-pc slick-slider-custom">
            @empty($battleToday)
            <div class="slick-album">
	@php
		date_default_timezone_set ('Asia/Tokyo');
		$time1 = new DateTime('2023-10-30 13:00:00');
		$nowDateTime = new DateTime();
	@endphp
		@if ( $nowDateTime->format('Y-m-d H:i:s') >= $time1->format('Y-m-d H:i:s') )
                  <div class="items banner-fantype fan-type-code-02 fan-type-code-03 fan-type-code-04 fan-type-code-07 fan-type-code-14 items-banner top-banner" style="display: none;">
					<form action="https://l-tike.com/st1/marines_movie23_fc" method="POST">
					<input type="image" class="w-100 d-block" src="/mypage/images/banner1.jpg" alt="送信する">
					<input type="hidden" name="CERK" value="ae72cbdc476832330ff15d7602cbd859" />
					</form>
                  </div>
                  <div class="items banner-fantype fan-type-code-02 fan-type-code-03 fan-type-code-04 fan-type-code-07 fan-type-code-14 items-banner top-banner" style="display: none;">
					<form action="https://l-tike.com/st1/marines_movieg23_fc" method="POST">
					<input type="image" class="w-100 d-block" src="/mypage/images/banner2.jpg" alt="送信する">
					<input type="hidden" name="CERK" value="382c913425fece81b731afae2d9473a8" />
					</form>
                  </div>
          @endif
              @foreach ($listBanner as $item)
                @if($item->banner_type_code == 2)
                  @php
                      $class = "";
                  @endphp
                  @foreach ($item->fantypenameen as $fantype)
                    @php
                      $class .= " fan-type-code-".$fantype->fantypecode;
                    @endphp
                  @endforeach

                  <div class="items banner-fantype{{ $class }} items-banner top-banner" style="display: none;">
                    <a href="{{ $item->url }}" target="{{ $item->target }}">
                      <img class="w-100 d-block" src="{{ asset($item->image_url) }}" alt="{{ $item->title }}">
                    </a>
                  </div>
                @endif
              @endforeach
            </div>
            @else
            <!-- Banner thêm pc -->
            <div class="site-album_banner">
              <div class="row m-0">
                <div class="col-md-8 p-0">
                  <div class="content">
                    <h3>TODAYS HOME GAME</h3>
                    <div class="img">
                      <div class="row m-0 align-items-center">
                        <div class="col-md-4 p-0">
                          <div class="img_dt">
                            <img class="w-100 d-block" src="/mypage/images/ticket-logo/{{ $battleToday['homeTeamCode'] ?? 2008001 }}_l.png" alt="">
                          </div>
                        </div>
                        <div class="col-md-4 p-0">
                          <div class="text">
                            <div class="nb">{{ \Carbon\Carbon::parse($battleToday['gameDate'])->format('m/d') }}<span>［{{ $weekMap[\Carbon\Carbon::parse($battleToday['gameDate'])->dayOfWeek] }}］</span></div>
                            <div class="time">
                              <span>試合開始</span>
                              <p>{{ \Carbon\Carbon::parse($battleToday['gameTime'])->format('H:i') }}</p> 
                            </div>
                            <p class="t">{{ $battleToday['gameStadiumName'] }}</p>
                          </div>
                        </div>
                        <div class="col-md-4 p-0">
                          <div class="img_dt">
                            <img class="w-100 d-block" src="/mypage/images/ticket-logo/{{ $battleToday['visitorTeamCode'] ?? 2008001 }}_l.png" alt="">
                          </div>
                        </div>
                      </div>
                    </div>
                    <a href="https://www.marines.co.jp/gamelive/result/" target="_blank" class="btn-custom btn-custom-icon">試合速報はこちら</a>
                  </div>
                  <div class="button-marrin">
                    <a href="/mypage/movie"><img src="/mypage/images/m1.png" alt=""> <span>視聴はこちら</span></a>
                  </div>
                </div>
                <div class="col-md-4 p-0">
                  <ul class="box">
                    <li>
                      <a href="/mix/FmaMemberOutSiteLink.do?code=0" target="_blank">
                        <img src="/mypage/images/ticket.svg" alt="">
                        <span>チケット購入</span>
                      </a>
                    </li>
                    <li>
                      <a href="/mix/FmaMemberOutSiteLink?code=6" target="_blank">
                        <img src="/mypage/images/ticket_my.svg" alt="">
                        <span>マイチケット</span>
                      </a>
                    </li>
                    <li>
                      <a href="https://www.marines.co.jp/event/" target="_blank">
                        <img src="/mypage/images/event.svg" alt="">
                        <span>イベント情報</span>
                      </a>
                    </li>
                    <li>
                      <a href="https://www.marines.co.jp/stadium/" target="_blank">
                        <img src="/mypage/images/map.svg" alt="">
                        <span>スタジアム案内</span>
                      </a>
                    </li>
                    <li>
                      <a href="/mix/FmaMemberOutSiteLink.do?code={{ $code }}" target="_blank">
                        <img src="/mypage/images/goods_info.svg" alt="">
                        <span>グッズ情報</span>
                      </a>
                    </li>
                    <li>
                      <a href="https://www.marines.co.jp/gourmet/" target="_blank">
                        <img src="/mypage/images/gourmet.svg" alt="">
                        <span>グルメ情報</span>
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            @endempty
          </section>
          
          <section class="site-web slick-slider-custom">
            @empty($tickets)
            @else
            <div class="slick-web">
              <div class="items">
                <div class="content">
                  <a target="_blank" href="https://www.marines.co.jp/game/schedule/index.html">
                    <img class="img-custom"  src="/mypage/images/01.svg" alt="">
                  </a>
                </div>
              </div>
              @foreach ($tickets as $ticket)
              <div class="items">
                <div class="content">
                  <div class="logo">
                    <img src="/mypage/images/ticket-logo/{{ $ticket['visitorTeamCode'] ?? 2008001 }}_l.png" alt="">
                  </div>
                  <span class="title">{{ SHORT_TEAM_NAME[$ticket['visitorTeamCode']] ?? $ticket['visitorTeamName'] }}</span>
                  <div class="number font-big">{{ \Carbon\Carbon::parse($ticket['gameDate'])->format('m/d') }}<span>［{{ $weekMap[\Carbon\Carbon::parse($ticket['gameDate'])->dayOfWeek] }}］</span></div>
                  <div class="tiems font-big">{{ \Carbon\Carbon::parse($ticket['gameTime'])->format('H:i') }}</div>
                  <p>{{ $ticket['gameStadiumName'] }}</p>
                  <a class="btn-buy" target="_blank" rel="noopener noreferrer" href="/mix/FmaMemberOutSiteLink.do?code=0&gamedate={{ \Carbon\Carbon::parse($ticket['gameDate'])->format('Ymd') }}">BUY TICKET</a>
                </div>
              </div>
              @endforeach
              <div class="items">
                <div class="content">
                  <a target="_blank" href="https://www.marines.co.jp/event/">
                    <img class="img-custom" src="/mypage/images/02.svg" alt="">
                  </a>
                </div>
              </div>
            </div>
            @endempty
            <div class="container">
              <a class="btn-custom btn-custom-icon" rel="noopener noreferrer" href="{{ route_path('mypage.coupon') }}">WEB引換コードの確認はこちら</a>
            </div>
          </section>
          
          <section class="site-news">
            <div class="container">
              <h2 class="heading">NEWS</h2>
              <div class="list-news">
                @empty($news)
                <div class="text-center text-empty-news">
                  <span>球団公式ニュースは以下からご確認ください。</span>
                </div>
                @else
                @foreach ($news as $new)
                @if(is_array($new))
                  @php
                    $new = (object) $new;
                  @endphp
                @endif
                <div class="items-news">
                  <div class="content">
                    <span>{{ \Carbon\Carbon::parse($new->newsDate)->format('Y/m/d') }}（{{ $weekMap[\Carbon\Carbon::parse($new->newsDate)->dayOfWeek] }}）</span>
                    <h3><a href="{{ $new->newsUrl }}" target="_blank" rel="noopener noreferrer">{{ $new->newsTitle ?? '' }}</a></h3>
                    <div class="l-category">
                      <a class="category" style="background-color:{{ NEW_BG_COLOR[$new->newsCategory] ?? '#000' }}" href="#">{{ $new->newsCategory ?? '' }}</a>
                    </div>
                  </div>
                </div>
                @endforeach
                @endempty
              </div>
              <a class="btn-custom btn-custom-icon" href="https://www.marines.co.jp/news/list/index.html" target="_blank">NEWS一覧はこちら</a>
            </div>
          </section>

          <!-- FAVORITE -->
          <section class="site-banner site-banner-2 slick-slider-custom">
            <div class="container">
              <h2 class="heading">MY FAVORITE PLAYER</h2>
            </div>
            <div class="slick-banner-none">
              <div class="items">
                <a href="{{ route_path('mypage.profile.favorite.index') }}"><img class="w-100 d-block no-favorite" src="/mypage/images/bg-favorite-default.jpg" alt=""></a>
                <a href="#"><img class="w-100 d-block has-favorite" id="bg-favorite" src="" alt="" style="display:none !important;"></a>
                <div class="text-content has-favorite" style="display:none;">
                  <div class="row m-0 align-items-center">
                    <div class="col-9 p-0">
                      <div class="title-nh-45">
                        <div class="flex-nh-title">
                          <span style="font-size: 34px;" class="player-uniform-no"></span>
                          <span style="font-size:2.4vw !important;margin-bottom:7px !important" class="player-name-roma"></span>
                        </div>
                        <span style="font-size:26px; margin-bottom: 15px;" class="player-name"></span>
                      </div>
                      <span id="index-1"></span>
                      <span id="index-2"></span>
                      <span id="index-3"></span>
                      <span class="date-cn" id="date-update"></span>
                    </div>
                  </div>
                </div>
                <a class="link-st" href="{{ route_path('mypage.profile.favorite.index') }}">
                  <img class="w-100 d-block" src="/mypage/images/st.png" alt="">
                </a>
              </div>
            </div>
            <a class="btn-custom  btn-favorite no-favorite" href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手設定をしよう！</a>
          </section>

          <!-- CHALLENGE MISSION -->
          <section class="site-mission site-mission-page pd-main">
            <h2 class="heading">CHALLENGE MISSION</h2>
            <div class="list-content" id="mission-index-html">
              <div class="content text-center">
                  <p><strong>現在受付中のミッションはありません。</strong></p>
              </div>
            </div>
            <a class="btn-custom btn-custom-icon" href="{{ route_path('mypage.mission.monthly') }}">ミッションの詳細はこちら</a>
          </section>
        @empty($battleToday)
          <section class="site-good slick-slider-custom">
            <h2 class="heading">GOODS</h2>
            <div class="slick-good-pc">
              @foreach ($listBanner as $item)
                @if($item->banner_type_code == 3)
                  @php
                      $class = "";
                  @endphp
                  @foreach ($item->fantypenameen as $fantype)
                  @php
                      $class .= " fan-type-code-".$fantype->fantypecode;
                  @endphp
                  @endforeach
                  <div class="items banner-fantype{{ $class }} items-banner goods-banner" style="display: none;">
                    <a href="{{ $item->url }}" target="{{ $item->target }}">
                      <img class="w-100 d-block" src="{{ asset($item->image_url) }}" alt="{{ $item->title }}">
                    </a>
                  </div>
                @endif
              @endforeach
            </div>
            <a class="btn-custom btn-custom-icon" href="/mix/FmaMemberOutSiteLink.do?code={{ $code }}" target="_blank">オンラインストアはこちら</a>
          </section>
          <section class="site-album2 slick-slider-custom">
            <div class="slick-album1">
              @foreach ($listBanner as $item)
                @if($item->banner_type_code == 4)
                  @php
                      $class = "";
                  @endphp
                  @foreach ($item->fantypenameen as $fantype)
                  @php
                      $class .= " fan-type-code-".$fantype->fantypecode;
                  @endphp
                  @endforeach
                  <div class="items banner-fantype{{ $class }} items-banner content-banner" style="display: none;">
                    <div class="items1">
                      <a href="{{ $item->url }}" target="{{ $item->target }}">
                        <img class="w-100 d-block" src="{{ asset($item->image_url) }}" alt="{{ $item->title }}">
                      </a>
                    </div>
                  </div>
                @endif
              @endforeach
            </div>
          </section>
          <section class="site-marines site-news-top pd-main">
            <div class="title">
              <img src="/mypage/images/m1.png" alt="">
            </div>
            <div class="slick-slider-custom" id="live-html">

            </div>
          </section>
          <section class="site-marines site-video pd-main">
            <div class="container">
              <!--
              <div class="title">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512">
                <path d="M512 256c0 141.4-114.6 256-256 256S0 397.4 0 256S114.6 0 256 0S512 114.6 512 256zM188.3 147.1c-7.6 4.2-12.3 12.3-12.3 20.9V344c0 8.7 4.7 16.7 12.3 20.9s16.8 4.1 24.3-.5l144-88c7.1-4.4 11.5-12.1 11.5-20.5s-4.4-16.1-11.5-20.5l-144-88c-7.4-4.5-16.7-4.7-24.3-.5z"></path></svg>
                <h2>VIDEO <span>ビデオ</span></h2>
              </div>
              <div class="slick-tt slick-slider-custom" id="video-html">

              </div>
              -->
              <a class="btn-custom btn-custom-icon" href="{{ route_path('mypage.movie.index') }}">MARINES PLUS はこちら</a>
            </div>
          </section>
        @endempty
        </div>
        @include('parts.frontend.sidebar-right')
        </div>
      </div>
  </section>
  <section class="pp-ads pp-ads-pc">
    <div class="js-bg2"></div>
    <div class="content">
      @foreach ($listBanner as $item)
      @if($item->banner_type_code == 1)
        @php
            $class = "";
        @endphp
        @foreach ($item->fantypenameen as $fantype)
        @php
            $class .= " fan-type-code-".$fantype->fantypecode;
        @endphp
        @endforeach
        <a href="{{ $item->url }}" target="{{ $item->target }}" class="banner-fantype{{ $class }} banner-modal" style="display: none;"><img src="{{ asset($item->image_url) }}" alt="{{ $item->title }}"></a>
        @endif
      @endforeach
      <div class="js-close2"><i class="fa-regular fa-circle-xmark"></i> <span>閉じる</span></div>
    </div>
  </section>
</main>
@endsection
