@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('site-top')
@include('parts.frontend.inner.site-top')
@endsection
@section('site-date')
@include('parts.frontend.inner.site-date')
@endsection
@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-banner-web')
@include('parts.frontend.inner.site-banner-web')
@endsection
@section('site-qa')
<section class="site-qa">
    <div class="container">
        <div class="text">
            <p class="respon-complete">アンケートへご回答いただきありがとうございました。ご回答いただいた内容を精査しより安心・安全な観戦環境づくり、新たなサービスの提供に励んでいきますので引き続き千葉ロッテマリーンズの応援をお願いいたします。</p>
        </div>
        <a class="btn-custom btn-custom-icon" href="{{ route_path('mypage.index').'/' }}">ホームへもどる</a>
        <a class="btn-custom btn-back" href="{{ route_path('mypage.vote.index') }}">アンケート一覧にもどる</a>
    </div>
</section>
</script>
<script type="text/javascript" src="/mypage/js/sp/page63.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
