@extends('layouts.frontend')
@section('menu')
@include('parts.frontend.menu')
@endsection
@php
const NEW_BG_COLOR = [
  "アカデミー" => "#003399",
  "チーム" => "#000",
  "その他" => "#FFCC00",
  "グッズ" => "#FF6666",
  "ファンクラブ" => "#B8A536",
  "イベント" => "#B71649",
  "地域振興" => "#009900",
  "メディア" => "#EE82EE",
];

const SHORT_TEAM_NAME = [
  "1947001" => "巨人",
  "1954001" => "中日",
  "1961001" => "阪神",
  "1968001" => "広島",
  "1992001" => "千葉ロッテ",
  "2004001" => "北海道日本ハム",
  "2005001" => "福岡ソフトバンク",
  "2005002" => "オリックス",
  "2005003" => "楽天イーグルス",
  "2006001" => "東京ヤクルト",
  "2008001" => "埼玉西武",
  "2012001" => "横浜DeNA",
];

$weekMap = [
    0 => '日',
    1 => '月',
    2 => '火',
    3 => '水',
    4 => '木',
    5 => '金',
    6 => '土',
];
@endphp
<!-- ///// -->
@empty($battleToday)
  @section('site-top')
  @include('parts.frontend.inner.site-top')
  @endsection
  @section('site-date')
  @include('parts.frontend.inner.site-date')
  @endsection
@endempty
<!-- ///// -->

@section('site-notification')
@include('parts.frontend.inner.site-notification')
@endsection
@section('site-login')
@include('parts.frontend.inner.site-login')
@endsection
@section('site-banner')
@include('parts.frontend.inner.site-banner')
@endsection

<!-- ///// -->
@empty($battleToday)
  @section('site-album')
  @include('parts.frontend.inner.site-album')
  @endsection
@endempty
<!-- ///// -->

@section('site-web')
@include('parts.frontend.inner.site-web')
@endsection

@section('site-news')
@include('parts.frontend.inner.site-news')
@endsection

  @section('site-banner-2')
  @include('parts.frontend.inner.site-banner-2')
  @endsection
  @section('site-banner-mid')
  @endsection
  @section('site-mission')
  @include('parts.frontend.inner.site-mission')
  @endsection
<!-- ///// -->
@empty($battleToday)
  @section('site-good')
  @include('parts.frontend.inner.site-good')
  @endsection
  @section('site-album--slider')
  @include('parts.frontend.inner.site-album--slider')
  @endsection
  @section('site-marines')
  @include('parts.frontend.inner.site-marines')
  @endsection
  @section('site-marines--video')
  @include('parts.frontend.inner.site-marines--video')
  @endsection
@else
@section('site-banner-bot')
<section class="site-banner slick-slider-custom">
  <div class="slick-banner">
    @yield("title_content_image_4")
  </div>
</section>
@endsection
@endempty
<!-- ///// -->

@section('site-logo-pn')
@include('parts.frontend.inner.site-logo-pn')
@endsection
@section('pp-ads')
@include('parts.frontend.inner.pp-ads')
@endsection
