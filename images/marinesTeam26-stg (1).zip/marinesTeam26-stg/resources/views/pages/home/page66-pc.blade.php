@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom">
    <div class="container">
      @include('parts.member.member-top')
      <div class="title-profile"> 
        Mポイント｜Mポイント受取（補助券）
      </div>
      <section class="site-page65 pd-main">
        <div class="container">
            <div class="code error-message" style="display: none;">
                
            </div>
            <div class="contents_right">
            <p class="text">QRコード読み取りができない場合、QRコード下に記載のある6桁のコードをお客様ご自身で入力欄にご入力ください。<br>
            相違がないことを確認し、「登録する」ボタンを押してください。</p>
            </div>
            <form action="" onsubmit="return false;">
                <input class="form-control" type="text" id="ticket-code" placeholder="例）012345">
                <button class="btn-custom" id="post-ticket-code">登録する</button>
            </form>
        </div>
    </section>
    </div>
  </section>
</main>
<style>
    </style>
<script type="text/javascript">
    var urlComplete = "{{ route_path('mypage.point.complete-post')}}";
</script>
<script type="text/javascript" src="/mypage/js/pc/page66.js"></script>
@endsection
