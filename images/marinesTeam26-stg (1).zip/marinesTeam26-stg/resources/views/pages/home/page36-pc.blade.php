@extends('layouts.frontend-desktop')
@section('menu')
@include('parts.frontend.menu')
@endsection
@section('main')
<main>
  <section class="destop_custom page-profile-customer page-profile-customer-customtext site-uniform-font">
    <div class="container">
       @include('parts.member.member-top')
      <div class="title-profile">
        会員情報｜マイユニホーム
      </div>
      <section class="site-tab">
        <div class="container">
          <ul>
            <li><a href="{{ route_path('mypage.profile.customer.index') }}">基本情報</a></li>
            <li><a href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手登録</a></li>
            <li  class="active"><a href="{{ route_path('mypage.profile.uniform.index') }}">マイユニホーム</a></li>
          </ul>
        </div>
      </section>
      <section class="site-res-page">
        <div class="container">
          <div class="content">
            <p>マイユニホームの登録が完了しました。 </p>
          </div>
        </div>
      </section>
      <section class="site-information-page">
        <div class="container">
          <div class="images-products width-custom-50">
            <img class="w-100 d-block" src="/mypage/images/sp.png" alt="">
            <div class="block-uniform">
              <div id="js_Name3" class="txt-name">{{ $request->name }}</div>
              <div id="js_Number3" class="txt-number">{{ $request->number }}</div>
            </div>
          </div>
          <a class="btn-custom btn-custom-icon" href="{{ route_path('mypage.index') . '/' }}">ホームへもどる</a>
          <a class="btn-custom btn-back" href="{{ route_path('mypage.profile.uniform.index') }}">マイユニホームへもどる</a>
        </div>
      </section>
    </div>
  </section>
</main>
<script type="text/javascript" src="/mypage/js/pc/page36.js?ver={{ \App\Enums\Version::LAST }}"></script>
@endsection
