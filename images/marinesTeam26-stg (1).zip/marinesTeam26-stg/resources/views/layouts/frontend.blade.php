<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="csrf-token" content="{{ csrf_token() }}" />
  <title>{{ isset($title) ? $title : '' }}{{ !request()->is('mypage') ? ' |' : '' }}TEAM26|千葉ロッテマリーンズ公式ファンクラブ</title>
  <meta name="viewport"
    content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <link rel="shortcut icon" type="image/jpg" href="/mypage/favicon.ico">
  <link rel="stylesheet" type="text/css" href="/mypage/font-2/stylesheet.css?ver={{ \App\Enums\Version::LAST }}">
  <link rel="stylesheet" type="text/css" href="/mypage/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="/mypage/css/stylemb.css?ver={{ \App\Enums\Version::LAST }}"}>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Noto+Sans+JP:wght@400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
  <link rel="stylesheet" type="text/css"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
  <link rel="stylesheet" type="text/css" href="/mypage/css/responsive.css?ver={{ \App\Enums\Version::LAST }}">
  <?php
    $code = 13;
    $market = "210-XAX-714";
    if (url('/', null, true) == "https://membertest060225.team26.jp") {
      $market="062-YOM-768";
      echo '<script type="text/javascript" async src="//cdn.evgnet.com/beacon/chibalotte/test/scripts/evergage.min.js"></script>';
    } else {
      echo '<script type="text/javascript" async src="//cdn.evgnet.com/beacon/chibalotte/engage/scripts/evergage.min.js"></script>';
    }
  ?>
  
  <!-- Google Tag Manager -->
  <!-- Global site tag (gtag.js) - Google Analytics -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-199559925-1"></script>
  <script>
    var market = "{{ $market }}";
  </script>
  <script type="text/javascript" src="/mypage/js/google-tag.js"></script>
  <!-- End Google Tag Manager -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.4/moment.min.js"></script>
  <script type="text/javascript" src="/mypage/js/jquery.min.js"></script>
  <script type="text/javascript" src="/mypage/js/slick.min.js"></script>
  <script type="text/javascript" src="/mypage/js/jquery.lettering.js"></script>
  <script type="text/javascript" src="/mypage/js/circletype.min.js"></script>
  @php
  use App\Models\FanRankName;
  use App\Models\UniformRegistration;
  use App\Models\Pitcher;
  use App\Models\Batter;
  $listRankEn = FanRankName::all()->map->only(['fantypecode', 'fantypenameen'])->values();
  $pits = Pitcher::all()->map->only(['playerCode', 'ERA', 'SO', 'BB', 'updated_at'])->values();
  $bats = Batter::all()->map->only(['playerCode', 'AVG', 'OBP', 'RBI', 'updated_at'])->values();
  @endphp
  <script type="text/javascript">
    var arrayRankEn =  {!! json_encode($listRankEn) !!};
    var arrayPit = {!! json_encode($pits) !!};
    var arrayBat = {!! json_encode($bats) !!};
    var httpReferer = "{{ request()->server()['HTTP_REFERER'] ?? '' }}";
    var httpRequestMethod = "{{ request()->server()['REQUEST_METHOD'] }}";
    var flagRequestUni = "{{ old('name') || old('number') || request()->name || request()->number ? '0' : '1' }}";
    var isGuidebookPage = "{{request()->is('mypage/guidebook')}}";
    var isMovieListPage = "{{request()->is('mypage/movie/list')}}";
    var isMoviePage = "{{request()->is('mypage/movie')}}";
    var isTopPage = "{{request()->is('mypage')}}";
  </script>
  <script type="text/javascript" src="/mypage/js/sp/customer-sp.js?ver={{ \App\Enums\Version::LAST }}"></script>
</head>
<body>
  <section class="pp-loading">
    <div class="flex">
        <div class="flex-item">
            <div class="logo-team26">
                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="181" height="48.731" viewBox="0 0 181 48.731">
                    <image id="TEAM26_w" width="181" height="48.731" xlink:href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAggAAACMCAYAAAAZQlGEAAAACXBIWXMAAAsTAAALEwEAmpwYAAAG0WlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNy4xLWMwMDAgNzkuZGFiYWNiYiwgMjAyMS8wNC8xNC0wMDozOTo0NCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtbG5zOnN0RXZ0PSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VFdmVudCMiIHhtbG5zOmRjPSJodHRwOi8vcHVybC5vcmcvZGMvZWxlbWVudHMvMS4xLyIgeG1sbnM6cGhvdG9zaG9wPSJodHRwOi8vbnMuYWRvYmUuY29tL3Bob3Rvc2hvcC8xLjAvIiB4bXA6Q3JlYXRvclRvb2w9IkFkb2JlIFBob3Rvc2hvcCBDQyAyMDE5IChNYWNpbnRvc2gpIiB4bXA6Q3JlYXRlRGF0ZT0iMjAyMS0xMi0wNFQxNjoyNToxMSswOTowMCIgeG1wOk1vZGlmeURhdGU9IjIwMjEtMTItMDlUMTc6NTM6NDErMDk6MDAiIHhtcDpNZXRhZGF0YURhdGU9IjIwMjEtMTItMDlUMTc6NTM6NDErMDk6MDAiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6Njc5OWY3MzMtOGUzOC00MTdmLTliODEtNWY2ZGVlZDM5NjAyIiB4bXBNTTpEb2N1bWVudElEPSJhZG9iZTpkb2NpZDpwaG90b3Nob3A6MjM0ZTY5Y2ItNzcxNC1lMTRkLWFkNjktOGQyYjlmYWQzZjJmIiB4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ9InhtcC5kaWQ6MzQ1RThFMUI1MzY4MTFFOThBNTBDQUQzMjc1ODI5OEEiIGRjOmZvcm1hdD0iaW1hZ2UvcG5nIiBwaG90b3Nob3A6Q29sb3JNb2RlPSIzIiBwaG90b3Nob3A6SUNDUHJvZmlsZT0ic1JHQiBJRUM2MTk2Ni0yLjEiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDpFODkwMDQwOTUzNjcxMUU5OEE1MENBRDMyNzU4Mjk4QSIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDpFODkwMDQwQTUzNjcxMUU5OEE1MENBRDMyNzU4Mjk4QSIvPiA8eG1wTU06SGlzdG9yeT4gPHJkZjpTZXE+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDphODkxODE3Yi1kYzc5LTRiM2UtYjg2MC1hMTYwMjM2MDIwMTAiIHN0RXZ0OndoZW49IjIwMjEtMTItMDlUMTc6NTM6NDErMDk6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMi41IChNYWNpbnRvc2gpIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDxyZGY6bGkgc3RFdnQ6YWN0aW9uPSJzYXZlZCIgc3RFdnQ6aW5zdGFuY2VJRD0ieG1wLmlpZDo2Nzk5ZjczMy04ZTM4LTQxN2YtOWI4MS01ZjZkZWVkMzk2MDIiIHN0RXZ0OndoZW49IjIwMjEtMTItMDlUMTc6NTM6NDErMDk6MDAiIHN0RXZ0OnNvZnR3YXJlQWdlbnQ9IkFkb2JlIFBob3Rvc2hvcCAyMi41IChNYWNpbnRvc2gpIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Ps70MJMAACzeSURBVHic7Z15uBxVnfc/nQ0SQhL21RBICCBbi68CbiRhDRIGkU0ceXEP4EhwGXB9GRwFl0fABZh5XwZQYMBBDYKyiBDU0SE4YyAEAiQkQBKWRAhJSCBbvX/8up6u27fq1NKnzqmu+/s8z33uvd1V55zurj7nW+e3NYIgII5GoxH7eCdJ5yuKoiiVZjDwS2Ca74EkcC5wte9BtDgQuB/Y3vdAYlgKTAIW5D2x0WgY1/CGCgRFUZQBx2DgJ8CZwErgNa+j6c9bgEFUQyRExcGLwJt+h9OH4cCOiEg4DFiS52QVCIqiKEqUBnAjIg4eA6YAy72OqD8fRgSMb5EwAfgTsANwM3AWsMnTWOIYBtyG7AItRHYSMouErgRCEASXIgpF6c+XgHU5zzkC+EAJY/HNXOBaR31dAOzhqC/bfBdR+q7pletuFjCzi/NPA95lZSTl8iCyte+DBnAVMB14CngPsAKYiiw2VWB+6+cUZFEeCswArnQ8jgnINbkbbXEwEpjseBwm/gt4hYIioVuBsBIYnWu4A4dtkK25PMwALrc+Ev/cDpzkqK/lVNMOmIXTgP/w0O8MeuO6+w3w/i7Ovxs41tJYyuRK5DNxTVQcRBeSq1uPVYVViGD5E3AisvgNRW7KLnM0hqg4+BVwMiIO7gXe6WgMWQh3gF4Dfg6cADwNvJsMu0JpAmGQnTEqihN2oHfFAUDT9wAqztu6PP+tVkZRXy5FhMBS5C54CbLgVkkcAIwC7kMWvl8hOwkbkPFf5KD/3YHfIuLgDuBUYATVEwcAByD+EaOB04EHgL1bj+3QbeMqEJReYn/fA+iSpu8BVJxdgJ0LnjsScWxT4rkMuJC2x/vzwCWtx6rIcOBO2iLh7xCTbtkiYXdk52AcIg5OAYYgu6RVEwchBwB3IbssJyAiIRQOXYkEFQhKL6ECof40C563j81B1IwvI0JgBXA0Eg53EfA1n4PKQCgSpiIL4AmUKxJCcTCevuLgTqrldxDH25Edjk6RcC9duAmoQFB6iV5fBHalt00kLjik4Hm9Lh7L4iLgm4g4mAI8AXwWWWR7geHI3fuJyB1xWSJhB8SHpRfFQcg7ESEFbZHQpAuRoAJB6SUO8D0ACzR9D6DiFPVD2NfqKOrBechCugo4Hok2Ogf30QDdMhRxVAxFwlTkNV0K/JOF9ndotbs/IhJ6URyEHI6MG0QkPIgIh0IiQQWC0kvUwQmt6XsAFaeoQKjDtWGTc4AfAauBY4CHkdwCP/Y5qC4IRcIZyKJ3DCISvk53kQ3bIeLgAOSO+4Otx2+n98RByGREJGxCfDdmIyLhTsTZMjMqEJReYVtgJ9+DsEDT9wAqzniKbYfqDkKbs5BwxnVI+PFDyML6EyTUsVcZCtyECJ2HaIuECykmEkYjobWhODgB2IgIkaMsjNcnk5GQ6nXI+zQbyXmRSySoQFB6hTqYFwAO9j2AHiDvezQMiVtXZPG8DliPLHj3I1vzYVbCXmcQ8lpCkXA04l+RVySMph222CkOqlqbIi/TkNcTFQnh7kImkVCHC0YZGNRlC3k/YAvfg6g4eR0V90ZqCwx0TkYWz01I7P79yMIQJhqqC6FImI4selPIJxKiOQ3qKg5CpgHXA2voKxJ+TobMmSoQlF6hLgJhMPXZDSmLvBEJal6QXYJbWn+fjuQOmIKkrq6TOAgZhGSAPAdxvswqEkYgd9ADQRyEfAgRVKFI+G/gOOC2IAiMIkEFgtIr1GlRbfoeQMU5MOfxAz3E8W3IAjcY8T/4JXAoEq5X91o6V9FXJCxDRMKnE46/FbmDno34Z7wJ/JT6ioOQM4F/pZ3G+jHkNRtr6KhAUHqF/XwPwCJN3wOoOG8lnzPdQN9B2APZJbgVceILw9pyeaz3MFchORHmAp9sPbZLwrGh+PwA8DpyZ31aqaOrDh9D3qsVyC4TpIhxFQhKLzCG4il4q4g6KprZmnwVO+tifuqW9a3f5yL1DAYSYdKktRmPX4uk5j6znOFUlumIg2am90kFgtIL1G0L+WB6O9zMBVlNSoOAiWUORFEGKioQlF6gbneIo4A9fQ+i4mQVCOOov51dUbygAkHpBeq2gwDqh5BGVoFQJ98URakUKhCUXqCOAkH9EMxkFQgD3UFRUUpjiO8BKEoG6mZiAN1BSGM/ZH7amHJcHcVjlViI1HQog68D25TUtg9+jJTSts2ZwDtKaDeVNIFwLhmyLWXksxQvxGKD55EL0hZZvWWrxnnYH/tzltuLMgYpk1w3mr4HUHHC9MnzU47THYRyWQJcUVLbM6iXQLgNmFVCu02qKBAajcbNaQ0EQZC1r5PwKxBeQVJODnRuBlb6HkQO6nqHOBaZHF/1PZAKcyDpAqGOu0tV5BTgM5ba+irwR0ttVZFZltq5m+4qVXaNmhiUqrOP7wGUyMGUc8dRFw5CKtIlsTPFKj8q+dkdOMJSW9tbaqeq2HqfFltqpzAqEJSq4zrF8mutn7EO+mqiAsFEM+V53T1wz+eQGgZF+DDwBYtjqTJrgPcWPHdX4NcWx1IYFQhK1XG9CMwHAtwJBCWZg1Ke1xBH9ywC5hQ8d5K9YVSeTRR/n1baG0Z3aJijUnVcC4THEYdWFzQd9dOrhH4aSaiDoqKUiAoEpcqMQvKlu2Qe8IKjvvannqV4bWLKF1FXB1ZFqQRqYlCqjA8b83zcfS+GIK/xEUf99SImR846O7AqSshM7DosvpH1QBUISpXxIRDm4dYzvokKBBPNhMfHUM/8GIrSyczWj3NUIChVxnUEw1rgWaQAkCuawA0O++s1khwV1f9AqTtTKE8YjMhykAoEpcq49lJ/EolgcOWDAOqomMYBxKdc1ggGpe68Bfc+WH1QgaBUGdeLwGOt366iGEAFQhrDkN2Cxzoe1xwISl1Zhrusw+tMT6pAUKrKSGAPx30+0fq9FkmW5MIXYQwSzldmPYte52D6CwQ1MSh1ZT3FcyjkotFoGMslaJijUlV8bCE/EflbzQzVIS7U0WaI4xqLbSlKbdAdBKWq+Ihxnxf5+3nc3aU2gV856ssVAdCw1FanQNgSe7tLy4ANyI6VothiKFKg0AXPAf9TRsMqEJSq4logbACeify/1GHfTYd9uWIRsJeltpod/++Lvd3Px4G9LbWlJNMADvc9CIeMAH7pqK8NSLVN6zcZKhCUquLaCe1JJH96iEufAFO2wF7lUewJhB2BnYCXWv/b3NmZhwoEF/wQOA1J+PMQMBgY7nNAJXKBw75GA18BbqMEkaACQakqrncQnur4f4nDvvdC0kqvcthn2TyC3S3WJnBP62+b/inzcLcVPFC5DDgPMeccDbwM/AQRfnXkCsf9/RURCNZFggoEpYr4iGCY3/G/y1BHkF2EPzjus0zmWm7vYNoCwebu0uMW21L6cxFwIbACOA5YCFwFnOlzUCVxBe4rMf4rcDMiDKyLBBUIA4+bEJuVLS5A7M02mWi5vSx07iC4FghN6iUQbKePjpphbJsYlHL4DHApsjN2PCIavwtM9zmoEvFhKnwv4t9xE/Bh4BYsigQVCAOP4y23d7Hl9sB9imXov4PgOi9B3fwQVgAvAjtbai98f4Zgr0jTMtzf8bng7NaPTz6G+B2sA04AHga+BnzB56BqyCDEXAMiEoa1/rciElQgKFXER5a8Jzv+X43c+Yxy1H/TUT8ueRR7AmFfYAskqZStEtl1My9sS3nX0W45jj0D+L/ITuVJyM7YDOAS66NSoC0SAkQkgCWRoAJBqSKuBcJy4u8kl+BuLEk1B3qZR4FjLLU1GHmPbOamr5t5YVrrxycn0r6jPR24F/g4cLm3EQ0MBgHXI0m/rIkEFQhKFXFtYug0L4Q8hzuBsAXxNQd6mUctt3cQEu5oi7oIhBeA2x32lcQU4FZkh+cjSB6AMxBHOqV8htIWBFZEggoEpWqMwG25ZejvoBji2g+hSX0EwirsC4QmUrvCFnUxMTyE/1DNQ4E7kSyX5wI30t5NcJHS/zUHffQCnSJhFBI1UkgkaC0GpWrsi70UvVl5IuFxl7kQoF6OipuR99WmyeRg7O7o1GUHwTdNxJQwHPgScDWym3AL9vxFTKxCFj+Adzjor+qEImEa8lmcG3nsxDwNqUBQqoaPCIanEx5/1uko6ueouJ5k800RmtgLcaxrBINr9gd+i9ypfgtJinQoYvJwkSlxHbLoPYyE+V3Weuw+B31XmaGIuWcKXYgEFQhK1fBRxTFpEVvschDUTyCAXTPDaOwVVaqLecEnE5DkVdsjIY1fAQ5sPeai+NUG4IPAg8iidwOSLv1U4I8O+q86wxGzT2GRoAJBqRquBcJmkoWA6x2E7ckXTtYL2PZDsIWaF7pjd8SssBviPX8+IhjuR4Rc2WxGsjHeBRyJLHoN4Czg1w767xU6RcIMcogEFQhK1XBdg+F5ZCs8jqX0LeDkgjr5IYAKhDqyA/A7YE/gP4BPIOGnsxCR64JPIIvcu4E7kEVvOuL3oPQlKhKuRPxEhgK3BUFgFAkqEJQqsSX2KgBmZaHhuY24d1RsOu6vbGzXZLCFmhiKMRrZJZiI3Kn/PVJ06X7c7X6dD1wHvB34DbIAfhFJzqTEMxwJOz0U8dP4KiISjMmrVCAoVWJf3F+TJoEA6ofQLUuAV3wPIgbdQcjP1ohZ4QDgAaR886jWY+MdjeHrwA8QX4e7W/1/E/ieo/57mfCzGkE7T4IRFQhKlXBtXgBYkPL8YheDiNB03J8LqraLoBEM+RmBRCa8E5iN5F0YiuwiuIo8+h7wDcTX4S7EnPFj5G5YycYopF5DJlQgKFXCRw2GtB0E146KE4CtHPdZNrYrO3aLmhfyMQz4GTAZSeQ1FTG/hYLBBf8C/CPiHPlbxJxxI/APjvofkKhAUKqEjx2EqgmEBpJSuE5UzVFRzQvZGQzcDLwf+a4cieT7vw04wtEYbgbOQ3YMfodkWr0dqVgZOBrDgEQFglIlqigQFrsYRAdND32WiQqE3qSBOAN+EPElmQT8DVmwpzoawx3AR5G8CqFz5P2I/4PrCKMBhwoEpSoMQ8KmXLICKetsIk1AlEHTQ59lMg+JW68KamLIxlVI0aWXEPPCUuDfEMHggtARchht58jZSArhpNBkxSJarEmpCvsi25kueSbDMUuQjG0ucsqHNB325YK1iDPoRN8DaaE7COlchuQVeAU4Gvn8foQkInLBbCSRzyCkwNA7Ef+HY5HrqYp8EvhLCe1egqcy3ioQBh7nYfcLZqvioQ8HxSxj34SYGfYudyh9OAARS3XaQp1LNQSCRjCk8xXgQqQI0vHIZ3cpMne4IBQC64GfI7sXC4GjqPZntwCYg72Ko+uRudpbmLAKhIHHzVTzS+ZDIGRNgrQAtwJhRKs/m4WOfPMI7ramTah5wcz5wD8jBY9OQkpJX9T6ccFCJOPfamSuOgExbUxBTB29wKuW2rkBccT0hgoEpSr4qOKYdffDlx9CnQRCVXIhqHkhmU8CVyAmtVMQH4BzkN0DFyxFHCFXANci/gcrkMgJWzuVrthE8YJRWyIZD72jAkGpClXeQcjiq2CbJvXKK1+VXAgqEOL5MHAN7SJIv0EcFK9y1P9yRBwsQSpDfhQxcRwDPOloDDZZg7yeIowDFlkbSRdoFINSBYYhCYJcU+UdhLoVbVpMesSIC9TE0J8TkXDGQcDHkRwHJyNVGl3wGrJLsAD4FvAZxMTxfuCvjsagxKACQakCPiIYoNoCoemhzzIJEOcz3+gOQl+mIIJgKJKV8HrEQfAW3KwPr7f6m4v4OXwJMXF8gOJb9Iol1MSgVIH9PPU7lWzx+cPLHkgMOwM70TuOWVl4BDjcY/8awdCXdyFlgIcCX0bCGN+HVP1zEdb7BrJ78RBwLuLrEJo47nHQv5KCCgSlCvgSCNd66jcrTeo1Ufp2VFTzQpu3IwWPhgPfRhbndyCZC10I4g3A6UhWxLOQoksgjpK3OehfyYCaGJQq4CPFci/Q9D0Ay/hOuazmBSFaKvlqZGv/QMQxcZSD/jcjToi/QqIlrms9/jkkU6NSEVQgKFXARwRDL1A3R0UVCP6ZgIiD7YGfIsmPoo+54FzgJiQJ083IOnQJcLmj/pWMqEBQfDOUamTYqyJN3wOwzCrcV8eMMtBNDLsj1RB3RfwMPoqUTf5t6zEXfBEp3TyZtnPklcD/cdS/kgMVCIpvJqK+MEnsgx8HyTLxmQ9hIO8g7ADMAsYifi1nANvSLp/sgn8GvockAZqJXNvXAxc46l/JiQoExTdqXkhmEGIbrhO+HBUHcgTDtogz4Hjg90iOg+GIOHC1e/cD4GvI9XwX4uvwC+ATSAisUkFUICi+UQdFM+qHYIeBal4YjSzIYankE1uP34s78Xk9MAPxdfgdsA1i1vgQ9SpIVjt0a1fxjQoEM03fA7CML4EwEM0LI5Ct/LBU8gnAm0i0wjsdjeE2ZJfgLYiJYwfgz0ghqPWOxqAURHcQFN/s43sAFafpewCWeRpJkOOagSYQhiGlkichmUCPRVIa/wxxEHTBXUiNhx0RE8duiA/KVOyWnFdKQncQFJ8MQdIsK8kchAj5LBkfe4FNyGL9dsf9DiQTw2DgVuA4pELikUhGzp8A0xyN4fdIjoPRiDljfOvxUCSUzRWtH1+MQuqPFKEy67LuICg+mYCblK69zEhgL9+DsIwPR0XTDsJrzkZRPg1ECJyElEqejNQcuRpJYeyChxFfh41I+uatkfDWZ5HaC2WyJbAHMKbkfkw8S3flqTe22lhhZzjFqYxSUQYkGsGQjSZS6a4uuA51TItgqIsXfQMpz3wmInqmICad7yMpjF3wGFKFMRRdpzvqN2QS8IDjPjsZ57l/a6hAUHxygO8B9AhN6pWf3rWj4kAxL3wbmE7fCokX4y7PwAYkCdK7HfXX2fevPfQb5T2Us3MxtoQ2M6ECQfGJ7iBko+l7ADlJC11zLRAGgoPi15EshetoV0j8PG4zFA4Ffuiwvyiv4desAPANz/1bR30QFJ+oQMhG0/cAcrIm5fkVwAsuBtKi7gJhMvBPyF30GUjEwKeQrIWKUhjdQRh4/IHykpP8BYl5zoJGMGRnN2A74G++B2KRucAujvqqu4lhdOv3rUiFxFMRp0RF6QoVCAOPMu3+K3McOx6NYMhDE8lCVxceAY5x1FfddxBCQuH/fnR3WLGACgTFF/v5HgBwDvBixmPHIlXnfNGkXgLBVajjQK7BoChdoQJB8UUVUizfSLq9PGQn/AuEOuHKUbHu5gWlGIMRP5g/A4d7HotLfg2sRkyWqeg2lOIL3w6Kr5NdHAC8jN/CMnUr2vQ4khCmbAaKeUHJRpif4Rrk+puKFLEaCDwAnIaIo2tajxmThKlAUHzhewdhac7jA0Qk+GI/YAuP/dtmA/CEg37mO+hD6R1OR6JoTkEyTq5BfGHqLhL+hBTr2ojkVDkKWITUykhEBYLig8H4j2AoEmaXV1TYZAj+RZVtXJgZ1MSgRJmPZJhcgWScDEXC8UgWyDoyG3l9oTiYhsxlxzQajSWmE1UgKD7YC/93w0UEwkvWR5GPpuf+beNCINR10leKM5e+IuEq4JXWY3W7Xh5DinatoV2saymSkjo1fbsKBMUHVbgTLrIb4HMHAernh1B2JMNLyMSvKJ1ERcKnEJGwovVYXcxS85DXswoRB6eTQxyACgTFD1UQCFnDG6PoDoJdyi7apOYFxURUJEwHfgwsB44GFnoclw0WIjsHK4AbkJ2SXOIAVCAoftjH9wAothuwzPoo8tH03L9tllHuHX7dtosV+8wFjkTuss8BLgOWIAtpr4qE55HxL0V2Rj5MAXEAKhAUP1ShimMRH4Qiuw42GQXs6XkMtinTD0F3EJQsPIpEMqwCLqQtEibj36yYl6XIrkgoDqYj0VeTKFAyXgWC4ppB+I9ggGICwWWBoSSavgdgmTLNDCoQlKw8RF+R8A363on3AisQ88gC4PuIOFiBhDTmFgegAkFxzzhguO9B0JsmBlBHxTyoiUHJQ1QkfBW4CFlYJ1F9kfA3ZOfgCWQHZAZtp8vC3zEVCIprqmBeyJtFMcS3kyLoDkJWNIJBKUJUJFxKWySEDn9VZBVSoGsuIg4uxII4ABUIint8p1iG4ncD6/E/STQ992+bx4HNJbWrKEUIRcLriEg4H9mNCiMeqsQ64FhkzF/GojgALdakuKcKAqEbX4KXgO1tDaQAewBjqE+FwrXIHdpEy+0OZPPCH30PwANrLbf3EHAicCdwBXJzcDWy8H7ecl/dcAPwX8hOxzexKA5ABYLiniqYGLoRCMvwn8ehCczyPAabPIp9gTCQdxD+X+tH6Y77kfoFdyIRASAi4WxfA0rgC8hOxyrESdGaX48KBMUlDaoRwdCNw5HvUEcQR8VZvgdhkUeR4jk2GYgC4T3A9b4H4ZmdLbfXKRLeB7xpuY9uGAGcioiDY4A5NhtXgaC4ZA+qEcHQzSJfhUiGpu8BWKaMXAgD0cQwvvWj2CUqEs7wPJY4QnHwkO2GG0EQxD/RaGRqIOn8GHZE1I4v1uN/ch8FbOt5DGXyBubFdwtgF0djMbGCYlEMIPb/MdZGUoy097kT19fdZuC5HMcPA3a1PIbFOY7dtTUGV6zCboTFCGR+VdqsxL6fzg7AVpbbtMFqJMwxN41Gw7iGuxQIiqIoiqJUhDSBoGGOiqIoiqL0QwWCoiiKoij9UIGgKIqiKEo/VCAoiqIoitIPDXNUqs4WwNbAJsT7e5Pf4cSyJTLGDYhHcRXHqPRlCPKZDUY+syrFtitKtwwDRrb+XotEPuUmk0AIgmAs8LGMbS4EfppjDE3gpAzH/QaY3fp7CFJtK40XgWtaf48jfwasW4D5yAJwUYbjnwZuivx/dqvfNK6gHZJzUau/JFYj+bdXI6Fkc4DXDMdPJ1/ykMW0k62cQXxio02t/kEuvDVI6OAC5PPvNrTlvch7Nxl5/8KQmo3I53EvcC3JyXCSxm3iCvKFRU0BzkIqve0ReXwT8j48QDsNahyTWj9JXNz6bfr8FtP+rMZhvr7DazmtTZAc9OuQz3UpkpktS1jlMcC7MhwHfb/PWTB9piuRzy+NCcCnkcI7+9Ke/wLkvQw/s9/HnHs22b7LScxvnW/6bqcxq/XTzXc6iXFkmx//hHz/Qj6PCC0TbyBFhKIMBr6WoT+QEPVvxTx+HHBYzOObkZuJ8NwwDHAR8CTJtT9Mc+8cYGbr78NafXeyEUl3HJ3/ktqcSTupUd75aiXx1/uRyJz0PmROioYiLkW+b78Afoa8L+kEQRD703HMaUF25ie1mfBzdsZ2L4ucs2fGc+ZEzpmU8ZwoJ7XOHZPx+EeCvq9tfsbzxkXOWZlzjJuDILg3CIK3BfHv75yc7c2KnDsz57lBEATPBkHw8YSxpP1sl6PPzUEQfD8IgiEx7RQZd/QzMP3sHgTB73K0e3sQBDvFtHNxynlZPr/oZ5V2fZ8UZGszib8EQTA1ML83N+VoL/p9zvJj+kwXp5w7OAiC7wRBsDHj2O4M5FqMtjEr8yuLZ2aQ/7vdycVB99/ppJ+s8+MtkXOGBNne05Ux/Y3NPvwgCGQO7mzjipxtBEEQLAuC4PwgCBox7Zk+n+sjx80wHHdYxjbPjhyTd77qvN53CILg7hznLwqCYErQWucDw3WR1QchT3auvSjHdLF35O89S2jfBhM6/h/noM8Gkn/7z8BUB/2lMRbJA//tnOeNQe6O/i7j8Q3gAuBW3PnSjEV2BKbkOOdE4D+B3UoZkTvejtz1n2s4Zq8c7e3T3XAy00B2T76I3LVm4f3ItTi6pDH1MtHPbXeyv6ed5LlWoO/83w27IHffV1tqrxPbKcPTGA7ch1R0zMo44G5kx8FI1ok1z4I8lL5brraILr7jSmjfBiNoLwS7IPZzV2wB3IzfSoNR/hExFWTlCooVcjoZOKfAeXlpIOajIgv9eOqTI/8HSC2IOPLcSHSK6bI4h2KT9gHIa1X6YmsezisQbNdw+TSSPtk2HyihTRMzgIMKnDeUDNd3VoHg+8OEvhdmVXcQoD1OH2McA3zCQ79JTM943HjEdpZE6HeRxFeRC75MjkOK4SSxkrbdM46jgLfZHJAnBiM7N52MRFLRZmUi5e/8DMbsq/QmZv+dj2DvzrUujKTt/5B3XYiS99wyBKVpN6woewGHlNBuEqcantuE+IYl8dYgCHY3NV6WQCjjSxW9O6+yQAhf+7gS2n4E+BGwxHDM0SX0G8ebwA+BpwzHHJGxrRPp61ATZQMiIN5tOH9n4PCMfRXFdBf6AnJt7oJ5wTnK6ojK4SVkN8dUQCnOlJV3jhhGOTuNUQ7DXPtjGlKHIUnYNXB/R9gL2Jjj8s7hRUxSV2IufTyJ5HmnG1xdM4Mx7x5MReZGU2XT/UwdpPoKBEEwBLG95qEs1T0B8cYcV0LbPwT+p+Oxzv+zEF7IZYiYOcA/IDbVPyYck2f35kn6exdnLQL0BvBZxKTxMvFftN0QYbc2pa23poxxOenFbfYh3vu8k78h9dM7MSntsP0k5tB+jfNI9uQ3vc6q8CKyQ7At8rnG2Zh3BLYBXo08VuRucm/Es7wsjJMf4k+yFok6SbrrC79Pl9HXTHQI8l1M4tu0o0ZAIo5+Rt+iUCdh9rk5j77fnTmGY0O6+U5nZQLwB9yaGCYW6GMGsuPxMvFVZIcjc5TphqsIp5I9QiONuPkqLDS3M8k+IOuA37b+nkvy3GMs8pXFmXCsYRCrkEpxnZRhYgC5SB6knMX3ftphLN3gwsQwx/BcnmqJL9K9bXwFcteZFHa1HekCYRvDc+Hd3SZElCSFIW2X0kfIGoq9ZpNvR/QOdIPhuCpUsszKK8jinbS1uxN9BYLpel9NfCjcPvQNmbON6bqCdqjuasMx4XV1d8fjKzELhLsRR0cT4zALhJvJX5HQxnc6DRs3QUkCIWlNKXrTuQYRZ0kCf3vsC4R9kDVwftqBGTDNV6aQ2WguFlMOBKNpNouJwaT0kuKYy3JAmog449kuDWuT8LWPK7EP04LbwH2GTFOSmSxezmMMz0UXXFM/ZZczNn0Zo1/AlYbjsoqYqvC64bnO96PIPFG2fX+MhTY0kqE/4edWVCBsRfKd618SHh9J8UigQkmCusTkG2ALU76ZkVgoAd6tQHg44fGxxG/pdMsEyrdbdkvofDWuxD7SJq2kRCBlMSz9ECM2wmK7HUMaNhaKsh0pbTPG8Fzn5JQ0T7xGsp9KkW3jPGxVcvsDlQnI963ojZppTXnI8FxRQekymizEhR9Cmtk1dND9ATKeuJ/7TQ1kmZhNKvHPhucmIk51NplI/MK7EX9powP62t+HIWPsFDJvYu9CHWl47gVLfWRlEObtd9v2T1+U4cxkotn6XYbQzoopQ97zHf8nTfqLSL4GXOVC6IYxvgdQQcJ5uPM7sYFsIti0pjyG7JCOiHlub9LNNnGYomteLtBeFt5GvrDfIqwk2SQDYgLbDYkmi/WnazQahAmT4siyqCa9yI1JnbaYQPcCYQV9F58JxJsvnqO7kBuQuOeVHY/NynDe8/R34jyC/u/tM6Q7TaWxNfAO4O8Nx8zK0d4Y+qf7XUA2m9wg4H8hKjRpUlhEtu29pAs8D1nb2JL+r3kJ8rqrxF899TsMmdyOINls8wh9714amAVC0iQ8FhHNWgfBHmMo/p1O4iXE5yRkS+JznDxLNvOyaa5e2OovTkTk9W07BEn/nWTae5Vyb6hs7CKkzVf3IblgkjgZ+S5/AUkjnisNfhaBkPRhPot8kEnYcFR8ir4CYRiSZzrKCsxORln5RsxjWe4aF9BfIMTl6bYhEE7GfDEsBr6co72DkfzzUS4gW177rUk2MYXMzDgOGz4TWdvYif6v+UrE41mRa9Qk/FcBn+l4bDeSTTzPIFEocQxCFpR5eQaoGOnmO53E0/QVCBAfsvsM3QuERcj1EicQ8vq2/XfK8zPpvm6MCRtZFdPmqx9iXhNABNJ1wP9G6m08m7XzbnwQFjUajY0kh4fZcECKs112xvn7vvOL81SNS8X7TIljmIck/dgfEQm+2QzcSLaCWnXjU8jkFvdzvMdxdcsLyOe5N/1DbE1bxiYTA5Tvh6B0T9w83Jna9wXMycyiJK0pryO7TUmC0pZJKgBuJz7hl00OxWwOtsEs4N8zHjsJ2f3L7EBpFAhBEIwhOVQoVCFJWzQ2vvhxi3/ntmeZC28WltM/0UqnTf410h1KumF/RB1mTUxUJvOR0K2PkB7eWEdeRkRa3M8yLyOywy7INTaN/jtrpjvCxZgFgmYqrD5PxzzWuS4szNFekqB8rvV7acLz4+ne1+wZpHriSZiTmtmiaK2KPJwN/FvGY0cj+Tgy3byl7SCYvvihMEj6MG2oPVOWvhDfAgHSdzFcjPFQpJiOKTbbBfsCdyAx3L4cR5Vy2BspxHVNx+Np80TSHAG94ag40HmRdnKeJPLMcUnXS+gnkXTTOYTuo9j2Qgq8/Qq/DsA2WQ98HPgo2c3t30AS3RlJEwimrcPwS5/k/LIt3cemx92dd5JHuZZFnMKOYksgPIx8sHMMx1yKm9jtNxAVmhTJ8iHy+UMo1WAZ8HXaWdji+BR9Mw+aBMJS5Fp5NeF5NTH0BrZugnYlOafICx2/48jj2/Zlkp22pwHfytFWFnzvmF6P+KD8IePx3w6CwJi8Le0Oz/TFD7dLTXcHE5F0pt3wNFJqNglbi+9lmGNwTTyZ8rwtEfM4MnnfQPIXdiukjOcvMrQ3j/5bTabc5VHeBL6JlE39W8IxnwUuydieK5YjC1wUmyJzT5IF2jrSr5WQ0AP6ctxWL12OiNAhiFksKdRxGm1nxqR5YgPtCIZlxJsrVSDYpZvvtImnaYfexvEM2YqRmW46wzWlM4Q2Sh6T1KXI92cV8ZFW04EvYS+R0nIkEi6p2mnRNvPMV4sQX4PPIfOzKT/MlkhE3HeTDuhGIIR2RZNddR+6FwhP4kYgPETxVMtp6nohdrM/puUWyKqyV9B9eulXEFte3KK4HbLApG17bUp5PgtZ21iLnZTaSVxOcvrcRzBPslFmtn5f3N1wCrMRuc6SBEI0IidpnniRtpf4UsRXppMdkWvHhT14IGDjOx1HmrDNOg+n7TaBXZ+VN5Adibh6QlsivjU264HcgV2BUGS+2gx8D7gH+Dnm9+xIDAIhzcRgSvRwXxAEK5EJMQkbDkimxfdNzDsYrnBlYggxpcCF8tMOd5Ill33R822MQSmGacs0FITDSa7DsRtyR7WS+MiekCo7KrrOSlpVbJkYTALhO8i1MstwTJHweZP/hG1z7K8tt5fGSkSEx/2sRiqamsKIjT5A3Tgpbo28uXEZrzJ1nhHThfkM5caxZsW1QEjDtXOgjR2AqrPeQhtpwq6XCB28THPEIGSOGI35mqyyo2KaD9RAwTQPryN7wiGTiWE4cq2YMngWEZOmAmq2mU16ZViXvILkTUjC6IOQKBCCIBhM9x6jNuyLpkiGKkQwgNjgk5ywNtEO31Hiybr4mgRt2dn4su5QmNJp+ygaUzbdZjCF8vwQbAgy3UEQbM3D3V4vb6Ha0QebcbuLkGXufMzwnDH9v2nC3Z3u70Qn0H0Oe9OFWYUIhpCkcT6H2HNtMsZye75JElfQ1+PZdGdhasMGSY6Y0HeMpsmr18wgYzIcU2WBsDLjcaY5KmsbdSd0wIvDpUCA6ju2uhQIWXx3siaw6odJANj4IEcgQsPklZrGq8g2SZxd3eYOwjT6e4svB27KeP7TSC6CTsrY5Tgw5fmsd9O7E59i+Dbs10g3YUoiFYqCtMp8pgXcBs8hdTDiGJ3wdydV8JfJyvaYy+uGW+9VmPBH0f86fpD05GRbIbsMpmI+ZV9XtinzO70Aqb/SSdY5bguKl2yOYqPOT5ncg70CgnHXNsC9SFSbSSCEkRumudNofulGIHwauWveEUk8kcREuhMI4Gbx/VjMY4+QXSAk2ehsjvFdiEfr5JTjst5NjyfeyXQObgWCyYlmL0QcHmI4BuyEcpl4FPhgwnOH0Ladxnnqhzxue1Al8BYk09p7MM8P4W6IaZ5YDpzW+vsU4LyE47oVCNvQ/zq+gPQIqsOQ7VfTa+i1OhFlfqefojuBMC7l+Stpe+zfRrKDs406P2WyCslFkDZPZyHu2gZJivQ4soueFOV3ZOv5jxjaN960mEwMaQLhnkajMQu4M+U4G9tBSU6AVfFBgOQx2jSD7I2E0KVVLvRdnyIvvyTZDLMlUhTsHsP5z5NeOKpb7jM8tyMS77+I5MqWAenflSqwLZKr3ei8RNuklhbXPqv1Y/p8RmborwizMfv/3Nd6PskOu4lyQ2J7jW5vgtLKH/+Z9vViKgRY5aiXkDsc9dNZFyXK1Yh54dOGY0yF2boSCGEClLWYna/KdFSskg9CUpywaxGzEdle7SWW0j99b5QhmK/Viyk/kuJPyIKTxDDMd9zXkqOKWg/wu9Zv0zwRLfOcVIAnpAy78mbgKynHmBLJXEs1ip9VhW5v1NLWlOg1YjLtVN0HAdz5Ifw7Zt8m0/UN8FPTk0UFwtpGoxF1fDB9mDbUXtyFuYxqeYW7MDFk4cekT8ZV5EKKJdX6CdkLlXTLWRQLYXoAON/yWHxyP/CfyF2/ySkz64QP5d0V3gj8S4HzHkay0Sltur0JMu02Qd9dA9McVuWw2JCncLOTuwKZl4qEct7YaDRmmg4oKhA6M129HHuUYOPDjBMIVTIvgDiLxC0ernY5ViOpRb/gqD/brEVsZteTLbfFG8DXkEpmrngSOBz4fcbjNyDJX47Df552G2xA0nyfjHxGaXeE0Qk/TSCUaVc+B9lJyHpD8VPgKOqVt8IGcQtenhu1tOslOn+arhcbdX5c4MqkOBO5XrMUNwS5ri9CqrMaMW2JftPwXKe6+xbiPRtHWojfbJLrcocX5PyYY6JvxneJ90SOjnOBoZ8kwvPXGc6N3vXO6BjHRtqhQXeTHCYU9bb+EimxqYgTzCZElKxH7KjziX+vk94bE+H7fi3JWc2ikRKXkOwXkafM9VrE+eY7rd+TkYUjrKn+CuKYczeya5CUnMU07m4T3yxAymq/D3HAexfiVR1GW6xsjfE+4DqSt6hN10MU0+cXdTpLu76jTpxZrok1yPW0CrnGliHXWFTovJjSZ/S7sSTl2LRUvqbPNI6omS1A5qjrkEnxWOAg2ovMWuS1PYAIoCwOr3Mxv54sd49p10BSeFo332nT80mvJzStvYpUi42uG1ERmPQZhXPFLZjNn9H5+ibMTr2DEN+lxYZjQkzvV9RJzzT3RsfyIPHvVefccg3JZsWouTLvtd15PshNy1uBExEB/w5kxyY0MbyAXLN3IbtqmXZC/z+aZScz3u6BOgAAAABJRU5ErkJggg=="/>
                </svg>
            </div>
            <div class="loader">
                <div class="loader-inner line-scale">
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                    <div></div>
                </div>
            </div>

        </div>

    </div>

  </section>
  <input type="hidden" name="" value="{{$slug}}">
  <input type="hidden" name="" id="amcno">
  <form id="form-auth" name="" action="" style="margin: 0px 0px 0px 0px" method="post">
  <input type="hidden" name="submitCtrl" value="">
  <input type="hidden" name="action"></form>
  <!-- start header -->
  @yield('header')
  <header class="header">
    <!-- start menu && menu-login -->
    @yield('menu')
    <!-- include resources/views/parts/frontend/menu.blade.php -->
    @yield('menu-login')
    <!-- include resources/views/parts/login/menu-login.blade.php -->
    <!-- end menu -->
    <div class="header__menu">
      <div class="container">
        <div class="top">
          <div class="row row-custom">
            <div class="col-6 col-custom">
              <div class="item1 member-bg" style="background-image:url('/mypage/images/bg-menu.png'); background-position: top; overflow: hidden;">
                <span class="year fan-type-css rank-name-eng"></span>
                <div class="content">
                  <p class="t fan-type-name"></p>
                  <div class="img" id="qr-code-menu">
                    <!-- <img src={{secure_asset("mypage/images/qr.png")}} alt=""> -->
                  </div>
                  <p class="id">マリーンズID<br><span class="amc-no"></span></p>
                </div>
              </div>
            </div>
            <div class="col-6 col-custom">
              <div class="item2">
                <h3>現在のステージ</h3>
                <div class="content">
                  <div class="circle" style="border:none;">
                    <svg viewBox="0 0 36 36" class="circular-chart green" style="width:90px;height:90px;margin:0;">
                    <path fill="red" class="circle-bg" d="M18 2.0845
                      a 15.9155 15.9155 0 0 1 0 31.831
                      a 15.9155 15.9155 0 0 1 0 -31.831" />
                    <path class="circle circle-rank-color" d="M18 2.0845
                      a 15.9155 15.9155 0 0 1 0 31.831
                      a 15.9155 15.9155 0 0 1 0 -31.831" />
                    <text x="18" y="20.35" class="percentage"></text>
                    </svg>
                    <div class="hi" style="position:absolute;">
                      <h4 class="fc-rank-name"></h4>
                      <span>ステージ</span>
                    </div>
                  </div>
                  <div class="m4 check-rank"><span class="next-fc-rank-name next-fc-rank-color"></span> ステージ</div>
                  <div class="m4_2 check-rank">まであと</div>
                  <div class="mpt check-rank"><span class="necessary-point"></span> <span>Mpt</span></div>
                  <p>ステージランクの判定は翌日以降になる場合があります。<br><a class="text-dark" href="https://www.marines.co.jp/fanclub/point/stage.html?_gl=1*go8blv*_ga*OTA3NTE4NDQxLjE2NjI1Mjg3NTA.*_ga_VDEHFZZJD4*MTY3Mzg1NzYwOS42Ny4xLjE2NzM4NTc3MDcuMzIuMC4w" target="_blank">詳しくはこちら</a>をご覧ください</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="menu">
        <ul>
          <li>
            <a href="{{ route_path('mypage.mission.monthly') }}">ミッション</a>
          </li>
          <li>
            <a href="{{ route_path('mypage.movie.index') }}">MARINES PLUS</a>
          </li>
        </ul>
        <ul>
          <li>
            <a href="{{ route_path('mypage.marines') }}">デジタル会員証</a>
          </li>
          <li>
            <a href="{{ route_path('mypage.coupon') }}">WEB引換コード</a>
          </li>
          <li><a href="/mix/FmaMemberPointExchange">Mポイント交換</a></li>
          <li><a href="/mix/FmaMemberPointTicketReg">Mポイント受取（補助券）</a></li>
        </ul>
        <ul>
          <li class="childer">
            <a class="js-dropdown-menu" href="javascript:void(0)">会員情報</a>
            <ul class="sub-menu-pc">
              <li><a href="{{ route_path('mypage.profile.customer.index') }}">基本情報</a></li>
              <li><a href="{{ route_path('mypage.profile.favorite.index') }}">お気に入り選手登録</a></li>
              <li><a href="{{ route_path('mypage.profile.uniform.index') }}">マイユニホーム</a></li>
            </ul>
          </li>
          <li class="childer">
            <a class="js-dropdown-menu" href="javascript:void(0)">会員履歴</a>
            <ul class="sub-menu-pc">
              <li><a href="{{ route_path('mypage.history.point') }}">Mポイント実績</a></li>
              <li><a href="{{ route_path('mypage.history.visit') }}">来場履歴</a></li>
              <li><a href="{{ route_path('mypage.history.ticket') }}">チケット購入履歴</a></li>
              <li><a href="{{ route_path('mypage.history.privilege') }}">来場特典配布</a></li>
            </ul>
          </li>
          <li>
            <a href="{{ route_path('mypage.event.index') }}">イベント応募</a>
          </li>
        </ul>
        <ul>
          <li><a href="/mix/CrmMemberVoteList">アンケート</a></li>
          <li><a href="{{ route_path('mypage.guidebook') }}">ガイドブック</a></li>
        </ul>
        <ul>
          <li><a href="/mix/FmaMemberContinueFanType?action=info">{{ App\Models\Membership::first()->membership_year }}年度有料継続入会<br>(自動継続対象外の方)</a></li>
          <li><a href="/mix/FmaMemberInfo?action=init&acu=true">{{ App\Models\Membership::first()->membership_year }}年度自動継続情報更新<br>(自動継続対象の方)</a></li>
        </ul>
      </div>
      <div class="icon-menu">
        <div class="container">
          <div class="row row-custom">
            <div class="col-3 col-custom">
              <div class="item">
                <a target="_blank" href="https://www.marines.co.jp/?_gl=1*9mceih*_ga*OTA3NTE4NDQxLjE2NjI1Mjg3NTA.*_ga_VDEHFZZJD4*MTY3MTY5MzU1NC40OS4xLjE2NzE2OTM1ODYuMjguMC4w">
                  <img src={{secure_asset("images/nu.png")}} alt="">
                  <span>公式サイト</span>
                </a>
              </div>
            </div>
            <div class="col-3 col-custom">
              <div class="item">
                <a href="/mix/FmaMemberOutSiteLink.do?code=0" target="_blank">
                  <img src="/mypage/images/nu1.png" alt="">
                  <span>チケット購入</span>
                </a>
              </div>
            </div>
            <div class="col-3 col-custom">
              <div class="item">
                <a href="/mix/FmaMemberOutSiteLink?code=6" target="_blank">
                  <img src="/mypage/images/nu2.png" alt="">
                  <span>MYチケット</span>
                </a>
              </div>
            </div>
            <div class="col-3 col-custom">
              <div class="item">
                <a href="/mix/FmaMemberOutSiteLink.do?code={{ $code }}" target="_blank">
                  <img src="/mypage/images/nu3.png" alt="">
                  <span>ショップ</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="out js-out" onclick="doActionLogout()">
        <div class="container">
          <div class="d-flex align-items-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="svg-icon"
              style="width: 1em; height: 1em;vertical-align: middle;fill: currentColor;overflow: hidden;"
              viewBox="0 0 1024 1024" version="1.1">
              <path
                d="M768 106V184c97.2 76 160 194.8 160 328 0 229.6-186.4 416-416 416S96 741.6 96 512c0-133.2 62.8-251.6 160-328V106C121.6 190.8 32 341.2 32 512c0 265.2 214.8 480 480 480s480-214.8 480-480c0-170.8-89.6-321.2-224-406z"
                fill="" />
              <path d="M512 32c-17.6 0-32 14.4-32 32v448c0 17.6 14.4 32 32 32s32-14.4 32-32V64c0-17.6-14.4-32-32-32z"
                fill="" />
            </svg>
            <span>ログアウト</span>
          </div>
        </div>
      </div>
    </div>
  </header>
  <!-- End header -->
  @yield('login-js')
  <!-- include resources/views/parts/login/login-js.blade.php -->
  <!-- Start main -->
  <main class="{{ (request()->is('mypage/profile/uniform*')) || (request()->is('mypage/profile/favorite*')) ? 'site-uniform-font' : '' }}">
    @yield("site-top")
    @yield("site-date")
    @yield("site-notification")
    @yield("site-banner-web")
    @yield("site-qa")
    @yield("site-ex-point")
    @yield("site-mtp-top")
    @yield("site-tab-infor")
    @yield("site-tab")
    @yield("site-infor-event")
    @yield("site-infor-event-single")
    @yield("site-history-member")
    @yield("site-res-page")
    @yield("site-information-page")
    @yield("site-member")
    @yield("site-title-points")
    @yield("site-select-items")
    @yield("site-select-items--payment")
    @yield("site-code")
    @yield("site-message")
    @yield("site-login")
    @yield("site-banner")
    @yield("site-link-member")
    @yield("site-album")
    @yield("site-banner-konami")
    @yield("site-web")
    @yield("site-news")
    @yield("site-banner-2")
    @yield("site-banner-mid")
    @yield("site-mission")
    @yield("site-mission-page")
    @yield("site-good")
    @yield("site-album--slider")
    @yield("site-marines")
    @yield("site-marines--video")
    @yield("site-marines--video--news")
    @yield("site-search")
    @yield("site-logo-pn")
    @yield("pp-ads")
    @yield("pp-message")
    @yield("pp-message-2")
    @yield("site-banner-bot")
<section class="pp-misstion pp-miss-pp1">
  <div class="content">
    <h3 class="hd"><span>?</span>月間ミッションについて</h3>
    <div class="the_content">
      <p id="detail-miss-month">ミッションの詳細はこちら</p>
    </div>
    <div class="js-close-mis"><i class="fa-solid fa-xmark"></i><span>CLOSE</span></div>
  </div>
</section>

<section class="pp-misstion pp-miss-pp2">
  <div class="content">
    <h3 class="hd"><span>?</span>SPミッションについて</h3>
    <div class="the_content">
      <p id="detail-miss-special">SPミッションの説明が入る予定</p>
    </div>
    <div class="js-close-mis"><i class="fa-solid fa-xmark"></i><span>CLOSE</span></div>
  </div>
</section>
  </main>
  <!-- End main -->
  <!-- start footer -->
  <footer class="footer">
    <div class="container">
      <p>千葉ロッテマリーンズ公式アプリ</p>
      <div class="app">
        <div class="row row-custom">
          <div class="col-6 col-custom">
            <a target="_blank" href="https://apps.apple.com/us/app/marines-app/id1099673155?itsct=apps_box_link&itscg=30200">
              <img class="w-100 d-block" src="/mypage/images/app1.png" alt="">
            </a>
          </div>
          <div class="col-6 col-custom">
            <a target="_blank" href="https://play.google.com/store/apps/details?id=jp.co.marines.official.app">
              <img class="w-100 d-block" src="/mypage/images/app2.png" alt="">
            </a>
          </div>
        </div>
      </div>
    </div>
    <img class="w-100 d-block" src="/mypage/images/bg2.png" alt="">
    <div class="coppyright">Copyright © Chiba Lotte Marines All Rights Reserved.</div>
  </footer>
  <div class="footer-fix">
    <ul>
      <li class="{{ (request()->is('mypage')) ? 'active' : '' }}">
        <a href="{{ route_path('mypage.index') . '/' }}"><img src="/mypage/images/icon1.png" alt=""> <span>ホーム</span></a>
      </li>
      <li>
        <a href="/mix/FmaMemberOutSiteLink.do?code=0" target="_blank"><img src="/mypage/images/icon2.png" alt=""> <span>チケット購入</span></a>
      </li>
      <li>
        <a href="/mix/FmaMemberOutSiteLink?code=6" target="_blank"><img src="/mypage/images/icon3.png" alt=""> <span>MYチケット</span></a>
      </li>
      <li class="{{ (request()->is('mypage/marines')) ? 'active' : '' }}">
        <a href="{{ route_path('mypage.marines') }}"><img src="/mypage/images/icon5.png" alt=""> <span>会員証</span></a>
      </li>
      <li>
        <a href="/mix/FmaMemberOutSiteLink.do?code={{ $code }}"><img src="/mypage/images/icon4.png" alt=""> <span>ショップ</span></a>
      </li>
    </ul>
  </div>
  <!-- End footer -->

  <script type="text/javascript" src="/mypage/js/bootstrap.min.js"></script>
  <!-- <script type="text/javascript" src="/mypage/js/main.js"></script> -->
  <script type="text/javascript" src="/mypage/js/qrcode.min.js"></script>
  <!-- Start script -->
  @yield('script')
  @yield('script_extend')
  <script type="text/javascript" src="/mypage/js/sp/customer-js-footer.js?ver={{ \App\Enums\Version::LAST }}"></script>
  </body>
</html>
