<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- CSRF Token -->
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>{{ config('app.name', 'Laravel') }}</title>
  <!-- Scripts -->
  <script src="{{secure_asset('js/app.js') }}" defer></script>
  <link href="{{secure_asset('css/app.css') }}" rel="stylesheet">
  <style type="text/css">
    .shimmer {
      font-family: "Lato";
      font-weight: 300;
      font-size: 2em;
      margin: 0 auto;
      padding: 0 40px 0 0;
      display: inline;
      margin-bottom: 0;
      text-align: center;
      color: rgb(116 53 53 / 10%);
    background: -webkit-gradient(linear, left top, right top, from(#0a1be9), to(#763636), color-stop(0.9, #fff));
      background: -moz-gradient(linear, left top, right top, from(#0a1be9), to(#763636), color-stop(0.9, #fff));
      background: gradient(linear, left top, right top, from(#2220a1be9), to(#763636), color-stop(0.9, #fff));
      -webkit-background-size: 125px 100%;
      -moz-background-size: 125px 100%;
      background-size: 125px 100%;
      -webkit-background-clip: text;
      -moz-background-clip: text;
      background-clip: text;
      -webkit-animation-name: shimmer;
      -moz-animation-name: shimmer;
      animation-name: shimmer;
      -webkit-animation-duration: 2s;
      -moz-animation-duration: 2s;
      animation-duration: 2s;
      -webkit-animation-iteration-count: infinite;
      -moz-animation-iteration-count: infinite;
      animation-iteration-count: infinite;
      background-repeat: no-repeat;
      background-position: 0 0;
      background-color: #222;
    }
    @-moz-keyframes shimmer {
      0% {
        background-position: top left;
      }
      100% {
        background-position: top right;
      }
    }
    @-webkit-keyframes shimmer {
      0% {
        background-position: top left;
      }
      100% {
        background-position: top right;
      }
    }
    @-o-keyframes shimmer {
      0% {
        background-position: top left;
      }
      100% {
        background-position: top right;
      }
    }
    @keyframes shimmer {
      0% {
        background-position: top left;
      }
      100% {
        background-position: top right;
      }
    }
  </style>
</head>
<body>
  <div id="app">
    <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
      <div class="container">
        <a class="navbar-brand shimmer" href="{{ url('/') }}">
          {{ config('app.name', 'Laravel') }}
        </a>
        <span class="btn btn-outline-white border rounded-4 px-4">環境名</span>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <!-- Left Side Of Navbar -->
          <ul class="navbar-nav me-auto">
          </ul>
          <!-- Right Side Of Navbar -->
          <ul class="navbar-nav ms-auto">
            <!-- Authentication Links -->
            @guest
            @if (Route::has('login'))
            <li class="nav-item">
              <a class="nav-link" href="{{ route_path('login') }}">{{ __('ログイン') }}</a>
            </li>
            @endif
            @if (Route::has('register'))
            <li class="nav-item">
              <a class="nav-link" href="{{ route_path('register') }}">{{ __('登録') }}</a>
            </li>
            @endif
            @else
            <li class="nav-item dropdown">
              <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                {{ Auth::user()->name }}
              </a>
              <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="{{ route_path('logout') }}" onclick="event.preventDefault();
                                                      document.getElementById('logout-form').submit();">
                  {{ __('Logout') }}
                </a>
                <form id="logout-form" action="{{ route_path('logout') }}" method="POST" class="d-none">
                  @csrf
                </form>
              </div>
            </li>
            @endguest
          </ul>
        </div>
      </div>
    </nav>
    <main class="main py-4">
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <nav class="navbar bg-dark text-white">
              <div class="container-fluid justify-content-center">
                <a class="navbar-brand text-white" href="#">管理者ログイン</a>
              </div>
            </nav>
          </div>
        </div>
      </div>
      @yield('content')
      <div class="container">
        <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <nav class="navbar bg-secondary bg-gradient bg-opacity-75 text-white">
              <div class="container-fluid justify-content-center">
                <a class="navbar-brand text-dark" href="#">Copyright © Chiba Lotte Marines All Rights Reserved.</a>
              </div>
            </nav>
          </div>
        </div>
      </div>
    </main>
  </div>
</body>
</html>
