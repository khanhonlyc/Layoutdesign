# Ansible Playbook for RHEL8.6
## ポイント
- team26の環境は外部通信にproxyが必要
- deployer最新版はcomposer経由でのインストール

## 事前準備@各サーバ
```
/etc/dnf/dnf.conf に以下追記
proxy=http://10.200.101.18:8080
```

- ansibleのインストール
```
sudo subscription-manager repos --enable ansible-2.9-for-rhel-8-x86_64-rpms
sudo yum install ansible
```
---
## レシピ実行コマンド＠各サーバ
hotfactoryユーザにて
- STG
```
ansible-playbook -i /home/hotfactory/provision/inventory/staging_web /home/hotfactory/provision/playbook.yml --connection=local -v --ask-become-pass
```
- PROD
  - inventory/production_web, nginx default.confのserver_name は適宜書き換える
```
ansible-playbook -i /home/hotfactory/provision/inventory/production_web /home/hotfactory/provision/playbook.yml --connection=local -v --ask-become-pass
```

---
## WEB のレシピ実行結果
- php8.1 + fpm
```
$ php -v
PHP 8.1.11 (cli) (built: Sep 28 2022 09:08:05) (NTS gcc x86_64)
Copyright (c) The PHP Group
Zend Engine v4.1.11, Copyright (c) Zend Technologies
    with Zend OPcache v8.1.11, Copyright (c), by Zend Technologies
```
```
$ ps aux | grep nginx
root       98575  0.0  0.0  27196  3444 ?        Ss   10月12   0:00 nginx: master process /usr/sbin/nginx -c /etc/nginx/nginx.conf
nginx     105599  0.0  0.1  59380  5256 ?        S    12:27   0:00 nginx: worker process
nginx     109429  0.0  0.4 556172 18744 ?        S    15:23   0:00 php-fpm: pool www
nginx     109430  0.0  0.4 556172 18744 ?        S    15:23   0:00 php-fpm: pool www
nginx     109431  0.0  0.4 556172 18744 ?        S    15:23   0:00 php-fpm: pool www
nginx     109432  0.0  0.4 556172 18744 ?        S    15:23   0:00 php-fpm: pool www
nginx     109433  0.0  0.4 556172 18744 ?        S    15:23   0:00 php-fpm: pool www
hotfact+  110487  0.0  0.0  10316  1188 pts/0    S+   15:59   0:00 grep --color=auto nginx
```
- nginx 1.23
```
$ nginx -v
nginx version: nginx/1.23.1
```
- deployer 7系
```
$ dep -V
Deployer 7.0.2
```

---
## DB のレシピ実行結果
```
[hotfactory@dev-m2cdvsv01 ~]$ mysql --version
mysql  Ver 15.1 Distrib 10.6.10-MariaDB, for Linux (x86_64) using readline 5.1
```

### インストール後の作業
- 文字コードの変更
```
# defaultだとutf8mb3
MariaDB [(none)]> show variables like "%char%";
+--------------------------+----------------------------+
| Variable_name            | Value                      |
+--------------------------+----------------------------+
| character_set_client     | utf8mb3                    |
| character_set_connection | utf8mb3                    |
| character_set_database   | latin1                     |
| character_set_filesystem | binary                     |
| character_set_results    | utf8mb3                    |
| character_set_server     | latin1                     |
| character_set_system     | utf8mb3                    |
| character_sets_dir       | /usr/share/mysql/charsets/ |
+--------------------------+----------------------------+
8 rows in set (0.002 sec)

MariaDB [(none)]> show variables like "%coll%";
+----------------------+--------------------+
| Variable_name        | Value              |
+----------------------+--------------------+
| collation_connection | utf8mb4_general_ci |
| collation_database   | utf8mb4_general_ci |
| collation_server     | utf8mb4_general_ci |
+----------------------+--------------------+
3 rows in set (0.001 sec)
```
```
# 設定ファイルバックアップ
cd /etc/my.cnf.d/
sudo cp server.cnf server.cnf.org
```
```
以下変更
# This group is only read by MariaDB servers, not by MySQL.
# If you use the same .cnf file for MySQL and MariaDB,
# you can put MariaDB-only options here
[mariadb]
character-set-server = utf8mb4 # 追加
collation-server = utf8mb4_bin # 追加
[client-mariadb] # 追加
default-character-set = utf8mb4 # 追加
```

```
# 再起動
sudo systemctl restart mariadb
```

```
# 確認
MariaDB [(none)]> show variables like "%char%";
+--------------------------+----------------------------+
| Variable_name            | Value                      |
+--------------------------+----------------------------+
| character_set_client     | utf8mb4                    |
| character_set_connection | utf8mb4                    |
| character_set_database   | utf8mb4                    |
| character_set_filesystem | binary                     |
| character_set_results    | utf8mb4                    |
| character_set_server     | utf8mb4                    |
| character_set_system     | utf8mb3                    |
| character_sets_dir       | /usr/share/mysql/charsets/ |
+--------------------------+----------------------------+
8 rows in set (0.001 sec)

MariaDB [(none)]> show variables like "%coll%";
+----------------------+--------------------+
| Variable_name        | Value              |
+----------------------+--------------------+
| collation_connection | utf8mb4_general_ci |
| collation_database   | utf8mb4_bin        |
| collation_server     | utf8mb4_bin        |
+----------------------+--------------------+
3 rows in set (0.001 sec)
```


### 初期設定
```
[hotfactory@dev-m2cdvsv01 ~]$ sudo mariadb-secure-installation
[sudo] hotfactory のパスワード:

NOTE: RUNNING ALL PARTS OF THIS SCRIPT IS RECOMMENDED FOR ALL MariaDB
      SERVERS IN PRODUCTION USE!  PLEASE READ EACH STEP CAREFULLY!

In order to log into MariaDB to secure it, we'll need the current
password for the root user. If you've just installed MariaDB, and
haven't set the root password yet, you should just press enter here.

Enter current password for root (enter for none):
OK, successfully used password, moving on...

Setting the root password or using the unix_socket ensures that nobody
can log into the MariaDB root user without the proper authorisation.

You already have your root account protected, so you can safely answer 'n'.

Switch to unix_socket authentication [Y/n] n
 ... skipping.

You already have your root account protected, so you can safely answer 'n'.

Change the root password? [Y/n] Y
New password:
Re-enter new password:
Password updated successfully!
Reloading privilege tables..
 ... Success!


By default, a MariaDB installation has an anonymous user, allowing anyone
to log into MariaDB without having to have a user account created for
them.  This is intended only for testing, and to make the installation
go a bit smoother.  You should remove them before moving into a
production environment.

Remove anonymous users? [Y/n] Y
 ... Success!

Normally, root should only be allowed to connect from 'localhost'.  This
ensures that someone cannot guess at the root password from the network.

Disallow root login remotely? [Y/n] Y
 ... Success!

By default, MariaDB comes with a database named 'test' that anyone can
access.  This is also intended only for testing, and should be removed
before moving into a production environment.

Remove test database and access to it? [Y/n] Y
 - Dropping test database...
 ... Success!
 - Removing privileges on test database...
 ... Success!

Reloading the privilege tables will ensure that all changes made so far
will take effect immediately.

Reload privilege tables now? [Y/n] Y
 ... Success!

Cleaning up...

All done!  If you've completed all of the above steps, your MariaDB
installation should now be secure.

Thanks for using MariaDB!
```

### App用ユーザ・DB作成
```
CREATE USER 'team26_stg_user'@'%' IDENTIFIED BY '{wiki参照}';
CREATE DATABASE team26_stg;
GRANT ALL PRIVILEGES ON team26_stg.* TO 'team26_stg_user'@'%';
```

```
MariaDB [(none)]> show grants for team26_stg_user@'%';
+----------------------------------------------------------------------------------------------------------------+
| Grants for team26_stg_user@%                                                                                   |
+----------------------------------------------------------------------------------------------------------------+
| GRANT USAGE ON *.* TO `team26_stg_user`@`%` IDENTIFIED BY PASSWORD '*3C2F9B9BC3A4BB2CB1423257AEFF66B2A7FDFF85' |
| GRANT ALL PRIVILEGES ON `team26_stg`.* TO `team26_stg_user`@`%`                                                |
+----------------------------------------------------------------------------------------------------------------+
2 rows in set (0.000 sec)

MariaDB [(none)]> SHOW CREATE SCHEMA team26_stg;
+------------+--------------------------------------------------------------------------------------------+
| Database   | Create Database                                                                            |
+------------+--------------------------------------------------------------------------------------------+
| team26_stg | CREATE DATABASE `team26_stg` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */ |
+------------+--------------------------------------------------------------------------------------------+
1 row in set (0.000 sec)
```
